import { useCallback, useEffect, useState } from 'react';
import type { ProcessStep } from '../data/types';
import type { ZoneStatus } from '../components/FaceGuide';

/**
 * ⚠️ SIMULACIÓN — NO HAY VISIÓN COMPUTACIONAL.
 *
 * Esta máquina de estados representa cómo funcionaría el feedback de DERMIS en el producto final,
 * pero NO analiza la imagen de la cámara. Las indicaciones son guiones predefinidos por paso
 * (ver `m` en src/data/makeupSteps.ts y browSteps.ts) que avanzan cuando la persona presiona
 * "Volver a analizar".
 *
 *   scanning ──(2 s)──▶ needs-product ──[Volver a analizar]──▶ needs-blending ──[Volver a analizar]──▶ complete
 */
export type FeedbackState = 'scanning' | 'needs-product' | 'needs-blending' | 'complete';

const ORDER: FeedbackState[] = ['scanning', 'needs-product', 'needs-blending', 'complete'];
const FIRST_DELAY = 2000;
const REANALYZE_DELAY = 1500;

interface Sim { phase: FeedbackState; pending: FeedbackState | null; delay: number }

export function useFeedbackSimulation(opts: { running: boolean; paused: boolean; stepKey: string }) {
  const { running, paused, stepKey } = opts;
  const [sim, setSim] = useState<Sim>({ phase: 'scanning', pending: 'needs-product', delay: FIRST_DELAY });

  // Nuevo paso → vuelve a empezar el análisis simulado
  useEffect(() => {
    setSim({ phase: 'scanning', pending: 'needs-product', delay: FIRST_DELAY });
  }, [stepKey]);

  // Aplica la transición pendiente (se congela mientras está en pausa o sin cámara)
  useEffect(() => {
    if (!running || paused || !sim.pending) return;
    const t = window.setTimeout(() => setSim(s => (s.pending ? { phase: s.pending, pending: null, delay: 0 } : s)), sim.delay);
    return () => window.clearTimeout(t);
  }, [running, paused, sim.pending, sim.delay]);

  const reanalyze = useCallback(() => {
    setSim(s => {
      if (s.pending || s.phase === 'complete') return s;
      const next = ORDER[ORDER.indexOf(s.phase) + 1];
      return { phase: s.phase, pending: next, delay: REANALYZE_DELAY };
    });
  }, []);

  /** Atajo de presentación: completa el paso de inmediato. */
  const forceComplete = useCallback(() => setSim({ phase: 'complete', pending: null, delay: 0 }), []);

  return {
    phase: sim.phase,
    analyzing: sim.pending != null,
    index: ORDER.indexOf(sim.phase), // 0..3
    reanalyze,
    forceComplete,
  };
}

/** Estado de cada zona del overlay según la etapa del feedback simulado. */
export function zoneStatuses(step: ProcessStep, zonesCount: number, index: number, keep: (i: number) => boolean): ZoneStatus[] {
  const msgs = index > 0 ? step.m[index - 1] : [];
  const focus = new Set(msgs.filter(x => x.k !== 'ok').map(x => x.z));
  return Array.from({ length: zonesCount }, (_, i) => {
    if (keep(i) || index === 0) return 'todo';
    if (index === 1) return focus.has(i) ? 'focus' : 'todo';
    if (index === 2) return focus.has(i) ? 'focus' : 'ok';
    return 'ok';
  });
}
