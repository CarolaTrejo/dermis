/** Utilidades de imagen 100 % locales (nada se sube a un servidor). */

/**
 * Toma el cuadro actual del video y lo dibuja en un canvas con recorte tipo "object-fit: cover".
 * `mirrored` reproduce lo que la persona ve en pantalla (modo espejo).
 */
export function captureFrame(video: HTMLVideoElement, opts: { width: number; height: number; mirrored: boolean; quality?: number }): string | null {
  const vw = video.videoWidth, vh = video.videoHeight;
  if (!vw || !vh) return null;
  const { width, height, mirrored } = opts;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;
  const scale = Math.max(width / vw, height / vh);
  const sw = width / scale, sh = height / scale;
  const sx = (vw - sw) / 2, sy = (vh - sh) / 2;
  if (mirrored) {
    ctx.translate(width, 0);
    ctx.scale(-1, 1);
  }
  ctx.drawImage(video, sx, sy, sw, sh, 0, 0, width, height);
  try {
    return canvas.toDataURL('image/jpeg', opts.quality ?? 0.82);
  } catch {
    return null;
  }
}

/** Lee un archivo de imagen, lo reduce (lado mayor = maxSide) y devuelve un data URL JPEG liviano. */
export function fileToDataUrl(file: File, maxSide = 900): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith('image/')) {
      reject(new Error('El archivo seleccionado no es una imagen.'));
      return;
    }
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const k = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
      const w = Math.max(1, Math.round(img.naturalWidth * k));
      const h = Math.max(1, Math.round(img.naturalHeight * k));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      const ctx = canvas.getContext('2d');
      URL.revokeObjectURL(url);
      if (!ctx) { reject(new Error('No se pudo procesar la imagen.')); return; }
      ctx.drawImage(img, 0, 0, w, h);
      resolve(canvas.toDataURL('image/jpeg', 0.85));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('No se pudo leer la imagen.'));
    };
    img.src = url;
  });
}

export const todayLabel = () => {
  const months = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  const d = new Date();
  return `${d.getDate()} ${months[d.getMonth()]}`;
};
