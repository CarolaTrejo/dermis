/**
 * Imágenes del diseño (src/assets/img). Se importan desde el código para que Vite las procese:
 * en el build normal son archivos con hash; en el build "archivo único" quedan incrustadas (data URI).
 */
const files = import.meta.glob('../assets/img/*', { eager: true, query: '?url', import: 'default' }) as Record<string, string>;

const byName: Record<string, string> = {};
for (const [path, url] of Object.entries(files)) byName[path.split('/').pop()!] = url;

/** URL de una imagen del diseño por nombre de archivo, ej. asset('look1.jpg'). */
export function asset(name: string): string {
  const url = byName[name];
  if (!url && import.meta.env.DEV) console.warn(`[DERMIS] Imagen inexistente: ${name}`);
  return url ?? '';
}

// Para guardar en localStorage se reemplazan las URLs de imágenes del diseño por un token corto
// ("asset:look1.jpg"): así no se guardan data URIs pesados y los datos sobreviven a nuevos builds.
const entries = Object.entries(byName);
const TOKEN = (n: string) => `asset:${n}`;

export function encodeAssets(json: string): string {
  let out = json;
  for (const [name, url] of entries) if (url) out = out.split(JSON.stringify(url)).join(JSON.stringify(TOKEN(name)));
  return out;
}

export function decodeAssets(json: string): string {
  return json.replace(/"asset:([^"]+)"/g, (m, name: string) => (byName[name] ? JSON.stringify(byName[name]) : m));
}
