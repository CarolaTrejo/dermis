/**
 * Persistencia local (localStorage) con manejo de errores.
 * Si el navegador bloquea el almacenamiento o se excede la cuota (imágenes grandes),
 * la app sigue funcionando con el estado en memoria.
 */
import { decodeAssets, encodeAssets } from './assets';

const PREFIX = 'dermis.v3.';

export function load<T>(key: string, fallback: T): T {
  try {
    const raw = window.localStorage.getItem(PREFIX + key);
    if (raw == null) return fallback;
    return JSON.parse(decodeAssets(raw)) as T;
  } catch {
    return fallback;
  }
}

export function save(key: string, value: unknown): boolean {
  try {
    if (value === undefined) window.localStorage.removeItem(PREFIX + key);
    else window.localStorage.setItem(PREFIX + key, encodeAssets(JSON.stringify(value)));
    return true;
  } catch {
    return false;
  }
}

export function clearAll(): void {
  try {
    Object.keys(window.localStorage)
      .filter(k => k.startsWith(PREFIX))
      .forEach(k => window.localStorage.removeItem(k));
  } catch {
    /* almacenamiento no disponible */
  }
}
