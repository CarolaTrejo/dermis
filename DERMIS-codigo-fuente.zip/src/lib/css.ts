import type { CSSProperties } from 'react';

/**
 * Convierte un string CSS (como los estilos inline del diseño original de Claude Design)
 * en un objeto de estilos de React. Permite conservar literalmente los estilos del diseño.
 *   css('padding:11px 18px;border-radius:12px') → { padding: '11px 18px', borderRadius: '12px' }
 */
const cache = new Map<string, CSSProperties>();

function camel(prop: string): string {
  if (prop.startsWith('--')) return prop;
  const p = prop.startsWith('-webkit-') ? 'Webkit-' + prop.slice(8) : prop;
  return p.replace(/-([a-z])/g, (_, c: string) => c.toUpperCase());
}

export function css(src: string): CSSProperties {
  const hit = cache.get(src);
  if (hit) return hit;
  const out: Record<string, string> = {};
  for (const decl of src.split(';')) {
    const i = decl.indexOf(':');
    if (i < 0) continue;
    const k = decl.slice(0, i).trim();
    const v = decl.slice(i + 1).trim();
    if (k && v) out[camel(k)] = v;
  }
  if (cache.size > 2000) cache.clear();
  cache.set(src, out as CSSProperties);
  return out as CSSProperties;
}

export const pad2 = (n: number) => String(n).padStart(2, '0');
export const clock = (s: number) => pad2(Math.floor(s / 60)) + ':' + pad2(s % 60);
