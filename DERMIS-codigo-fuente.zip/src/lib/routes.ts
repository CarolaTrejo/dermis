import type { Mode } from '../data/types';

/** Rutas centralizadas de la app. */
export const base = (mode: Mode) => (mode === 'makeup' ? '/makeup' : '/brows');
export const routes = {
  home: '/',
  module: (mode: Mode) => base(mode),
  newRef: (mode: Mode, source?: 'camera' | 'gallery') => base(mode) + '/new' + (source ? `?source=${source}` : ''),
  scan: (mode: Mode) => base(mode) + '/scan',
  session: (mode: Mode) => base(mode) + '/session',
  tutorial: (mode: Mode, stepId: string) => `${base(mode)}/tutorial/${stepId}`,
  camera: (mode: Mode, stepId: string) => `${base(mode)}/camera/${stepId}`,
  result: (mode: Mode) => base(mode) + '/result',
  outfit: '/makeup/outfit',
  collection: '/collection',
  looks: '/looks',
  aftercare: '/aftercare',
};
