import type { FeedbackMsg, ProcessStep } from './types';

const m = (k: FeedbackMsg['k'], t: string, z: number, s: FeedbackMsg['s'], l?: string): FeedbackMsg => ({ k, t, z, s, l });
import { asset } from '../lib/assets';
const VB = '490 110 510 316';

/** Los 4 pasos del diseño de cejas. */
export const BROW_STEPS: ProcessStep[] = [
  {
    id: 'tweeze', name: 'Depilación', sub: 'Define la forma de tus cejas', img: asset('tool1.jpg'), guide: 'brow-tweeze', realTutorial: true,
    orient: 'Retirá los vellos que estén fuera de la forma de tus cejas para definir su contorno y lograr un acabado limpio y natural.', areas: ['Debajo del arco', 'Entrecejo', 'Extremos'], vb: VB,
    how: 'Ver cómo depilar', success: 'Depilación completada.', scanLabel: 'Analizando forma…',
    tt: 'Depilación', tx: 'Retirá suavemente los vellos que estén fuera de la forma de tus cejas con una pinza. Hacelo de a poco, siguiendo el crecimiento del vello, hasta conseguir un contorno limpio y natural.',
    tip: 'Depilá un vello a la vez y revisá la forma de tus cejas mientras avanzás. Evitá retirar demasiados pelos de una misma zona para mantener su forma natural.',
    ph: ['Identificá los vellos', 'Depilá con pinza', 'Revisá la forma', 'Resultado'], tcat: 'Depilación',
    m: [[m('add', 'Retirá algunos vellos debajo del arco.', 2, 'l', 'Retirá vello')], [m('ok', 'Esta zona ya está lista.', 2, 'l'), m('blend', 'Revisá el extremo de la ceja.', 6, 'r', 'Revisá')], [m('ok', 'Ambas cejas están equilibradas.', 1, 'r')]],
  },
  {
    id: 'shape', name: 'Forma', sub: 'Marca la forma ideal', img: asset('tool4.jpg'), guide: 'brow-shape',
    orient: 'Marcá el inicio, el arco y el final de tus cejas según la forma objetivo.', areas: ['Inicio', 'Arco', 'Final'], vb: VB,
    how: 'Ver cómo hacerlo', success: '¡Listo! Forma definida.', scanLabel: 'Analizando forma…',
    tt: 'Forma', tx: 'Con un lápiz, marcá tres puntos: el inicio alineado con la aleta de la nariz, el arco a la altura del iris y el final en la diagonal hacia el ojo. Uní los puntos con trazos suaves.',
    tip: 'Usá un lápiz un tono más claro que tu vello para marcar la guía. Así podés corregir fácilmente antes de rellenar.',
    ph: ['Marcá el inicio', 'Ubicá el arco', 'Definí el final', 'Resultado'], tcat: 'Relleno',
    m: [[m('add', 'Alineá el inicio con la aleta de la nariz.', 0, 'l', 'Marcá')], [m('blend', 'Elevá apenas el arco de esta ceja.', 1, 'r', 'Ajustá'), m('ok', 'Esta ceja ya está lista.', 0, 'l')], [m('ok', 'Ambas cejas están equilibradas.', 1, 'r')]],
  },
  {
    id: 'fill', name: 'Relleno', sub: 'Unifica y da volumen', img: asset('prod10.jpg'), guide: 'brow-fill',
    orient: 'Completá los espacios dentro de la forma para dar volumen.', areas: ['Cola', 'Inicio'], vb: VB,
    how: 'Ver cómo hacerlo', success: '¡Listo! Relleno completo.', scanLabel: 'Analizando relleno…',
    tt: 'Relleno', tx: 'Rellená con trazos cortos que imiten el vello, siguiendo su dirección. Concentrá el producto en la cola y dejá el inicio más suave.',
    tip: 'Peiná el vello antes de rellenar para ver dónde hay huecos reales. Trabajá con poco producto y sumá de a poco.',
    ph: ['Peiná', 'Trazá', 'Difuminá', 'Resultado'], tcat: 'Relleno',
    m: [[m('add', 'Rellená los huecos de la cola.', 3, 'r', 'Completá')], [m('blend', 'Difuminá el inicio con el cepillo.', 4, 'l'), m('ok', 'Esta zona ya está lista.', 3, 'r')], [m('ok', 'Relleno uniforme en ambas cejas.', 1, 'r')]],
  },
  {
    id: 'set', name: 'Fijación', sub: 'Mantiene la forma', img: asset('tool5.jpg'), guide: 'brow-set',
    orient: 'Peiná y fijá el vello hacia arriba para mantener la forma.', areas: ['Todo el largo de la ceja'], vb: VB,
    how: 'Ver cómo hacerlo', success: '¡Listo! Tus cejas están fijadas.', scanLabel: 'Analizando fijación…',
    tt: 'Fijación', tx: 'Pasá el gel fijador desde el inicio hacia la cola, peinando el vello hacia arriba y después hacia afuera. Dejá secar unos segundos sin tocar.',
    tip: 'Retirá el exceso de producto del cepillo antes de aplicar para que el gel no deje restos blancos.',
    ph: ['Peiná hacia arriba', 'Fijá', 'Definí la cola', 'Resultado'], tcat: 'Fijación',
    m: [[m('add', 'Peiná los vellos hacia arriba.', 0, 'l', 'Peiná')], [m('blend', 'Fijá el extremo hacia afuera.', 1, 'r', 'Fijá'), m('ok', 'Esta ceja ya está lista.', 0, 'l')], [m('ok', 'Tus cejas quedaron fijadas.', 1, 'r')]],
  },
];
