/**
 * Geometría de las guías faciales (overlays SVG).
 *
 * Todas las coordenadas viven en un único "espacio de rostro" de 1440×770 heredado del diseño
 * original: el rostro está centrado en x = 745 y ocupa aproximadamente y = 42 (frente) → 714 (mentón).
 * Las zonas espejadas (pares izquierda/derecha) se reflejan sobre el eje x = 745.
 *
 * IMPORTANTE: el prototipo NO detecta el rostro. Las guías se ubican proporcionalmente dentro del
 * cuadro de la cámara y la persona alinea su cara con el óvalo guía (igual que en el mockup de escaneo).
 */

export type Ellipse = [cx: number, cy: number, rx: number, ry: number, rot: number];

export interface Zone {
  e?: Ellipse;          // zona elíptica
  d?: string;           // zona con path libre
  c?: [number, number]; // centro (para paths)
  ax?: number;          // ángulo del eje principal (para flechas de tutorial)
  len?: number;         // largo aproximado (para puntos de tutorial)
  mir?: boolean;        // zona reflejada (lado derecho de la pantalla)
  line?: boolean;       // solo contorno, sin relleno (forma objetivo de la ceja)
  keep?: boolean;       // zona de referencia que no cambia de estado
  rm?: boolean;         // zona "a retirar" (rayado), usada en depilación
}

export interface GuideStyle {
  stroke: string;
  fill: string;
  fo: number;           // opacidad de relleno
  dot: string;
  blend?: 'multiply' | 'screen' | 'normal';
}

export type Decor = 'prep' | 'base' | 'forma' | 'fij';

export type GuideType =
  | 'moisturizer' | 'foundation' | 'concealer' | 'contour' | 'blush' | 'highlighter' | 'eyes' | 'lips'
  | 'brow-tweeze' | 'brow-shape' | 'brow-fill' | 'brow-set';

export interface GuideDef {
  type: GuideType;
  sty: GuideStyle;
  zones: Zone[];
  decor?: Decor;
  /** El producto "se aplica" (se usa para simular el resultado en la ilustración final). */
  applies: boolean;
  /** Las zonas son solo anclas: se ven únicamente cuando el feedback las resalta (prep/base usan flechas). */
  ghostZones?: boolean;
}

// Contorno del rostro y formas base (del diseño original)
export const FACE_PATH = 'M745,42 C905,42 992,150 996,318 C1000,470 952,600 872,664 C822,702 782,714 745,714 C708,714 668,702 618,664 C538,600 490,470 494,318 C498,150 585,42 745,42Z';
const BROW_D = 'M700,190 C688,172 655,160 612,158 C575,158 548,172 527,193 C552,190 585,186 614,187 C650,188 682,196 701,209Z';
const UNDER_D = 'M578,290 Q625,314 684,290 Q668,346 622,350 Q586,346 578,290Z';
const LID_D = 'M566,266 C582,230 642,222 690,257 C660,246 612,245 566,266Z';
const UPPER_LIP = 'M655,543 C690,520 715,500 735,505 C742,508 748,508 755,505 C775,500 800,520 835,543 C790,549 700,549 655,543Z';
const LOWER_LIP = 'M655,546 C700,552 790,552 835,546 C810,580 780,593 745,593 C710,593 680,580 655,546Z';

export const MIRROR_X = 1490; // 2 × 745
const pair = (z: Zone): Zone[] => [z, { ...z, mir: true }];
const BROW_OUTLINE: Zone = { d: BROW_D, c: [614, 182], ax: -5, len: 80, line: true };

export const FACE_GUIDES: Record<GuideType, GuideDef> = {
  moisturizer: {
    type: 'moisturizer', applies: false, decor: 'prep', ghostZones: true,
    sty: { stroke: '#FFFFFF', fill: '#FFFFFF', fo: 0.10, dot: '#FFFFFF', blend: 'screen' },
    zones: [{ e: [745, 100, 112, 34, 0] }, ...pair({ e: [596, 425, 48, 80, -22] }), { e: [745, 652, 56, 26, 0] }],
  },
  foundation: {
    type: 'foundation', applies: true, decor: 'base', ghostZones: true,
    sty: { stroke: '#F6A55B', fill: '#E8B48C', fo: 0.14, dot: '#E3AE86' },
    zones: [{ e: [745, 105, 140, 46, 0] }, ...pair({ e: [590, 430, 62, 100, -12] }), { e: [745, 655, 64, 30, 0] }],
  },
  concealer: {
    type: 'concealer', applies: true,
    sty: { stroke: '#F7C46A', fill: '#F6D6A8', fo: 0.30, dot: '#F2D1A0' },
    zones: [...pair({ d: UNDER_D, c: [630, 320], ax: 0, len: 46 }), { e: [782, 628, 11, 10, 0] }],
  },
  contour: {
    type: 'contour', applies: true,
    sty: { stroke: '#FFFFFF', fill: '#9A5F3F', fo: 0.55, dot: '#8A5236', blend: 'multiply' },
    // laterales de la frente · debajo de los pómulos · mandíbula
    zones: [...pair({ e: [579, 108, 58, 16, -52] }), ...pair({ e: [566, 388, 70, 18, 42] }), ...pair({ e: [592, 612, 60, 14, 46] })],
  },
  blush: {
    type: 'blush', applies: true,
    sty: { stroke: '#FFD1DC', fill: '#E86F8C', fo: 0.38, dot: '#E06A86', blend: 'multiply' },
    zones: pair({ e: [598, 372, 56, 32, -18] }),
  },
  highlighter: {
    type: 'highlighter', applies: true,
    sty: { stroke: '#FFF4D6', fill: '#FFF1CF', fo: 0.45, dot: '#FFF1CF', blend: 'screen' },
    zones: [...pair({ e: [574, 326, 46, 12, -24] }), { e: [745, 330, 8, 58, 0] }, { e: [745, 414, 10, 9, 0] }, { e: [745, 496, 13, 5, 0] }],
  },
  eyes: {
    type: 'eyes', applies: true,
    sty: { stroke: '#E3D9FF', fill: '#A48BE8', fo: 0.5, dot: '#9C82E6', blend: 'multiply' },
    zones: pair({ d: LID_D, c: [626, 248], ax: -8, len: 50 }),
  },
  lips: {
    type: 'lips', applies: true,
    sty: { stroke: '#FFD6DD', fill: '#D9607A', fo: 0.42, dot: '#C8506A', blend: 'multiply' },
    zones: [{ d: UPPER_LIP, c: [745, 526], ax: 0, len: 70 }, { d: LOWER_LIP, c: [745, 572], ax: 0, len: 70 }],
  },
  'brow-tweeze': {
    type: 'brow-tweeze', applies: false,
    sty: { stroke: '#FFFFFF', fill: '#FFFFFF', fo: 0.9, dot: '#FFFFFF' },
    // forma objetivo (solo contorno) + zonas a retirar: debajo del arco, entrecejo y extremos
    zones: [...pair({ ...BROW_OUTLINE, keep: true }), ...pair({ e: [612, 198, 32, 5, -2], rm: true }), { e: [745, 200, 16, 12, 0], rm: true }, ...pair({ e: [548, 176, 12, 5, -35], rm: true })],
  },
  'brow-shape': {
    type: 'brow-shape', applies: false, decor: 'forma',
    sty: { stroke: '#FFFFFF', fill: '#FFFFFF', fo: 0, dot: '#FFFFFF' },
    zones: pair(BROW_OUTLINE),
  },
  'brow-fill': {
    type: 'brow-fill', applies: true,
    sty: { stroke: '#FFFFFF', fill: '#4A2E22', fo: 0.45, dot: '#4A2E22', blend: 'multiply' },
    zones: [...pair({ ...BROW_OUTLINE, keep: true }), ...pair({ e: [555, 186, 26, 7, -25] }), ...pair({ e: [688, 198, 14, 9, 15] })],
  },
  'brow-set': {
    type: 'brow-set', applies: false, decor: 'fij',
    sty: { stroke: '#FFFFFF', fill: '#FFFFFF', fo: 0.06, dot: '#FFFFFF' },
    zones: pair({ e: [614, 180, 88, 18, -4] }),
  },
};

/** Centro de una zona en el espacio de rostro (ya reflejado si corresponde). */
export function zoneCenter(z: Zone): [number, number] {
  const c = z.e ? [z.e[0], z.e[1]] : (z.c ?? [745, 380]);
  return z.mir ? [MIRROR_X - c[0], c[1]] : [c[0], c[1]];
}

/**
 * Encuadre de la cámara dentro del espacio de rostro. El contenedor de cámara mide 1440×900
 * (mismo aspecto 1,6 que este viewBox), así el óvalo del rostro ocupa ~70 % de la altura:
 * una distancia cómoda frente a una webcam de notebook o un espejo.
 */
export const CAMERA_VIEW = { x: -23, y: -90, w: 1536, h: 960 } as const;
export const CAMERA_VIEWBOX = `${CAMERA_VIEW.x} ${CAMERA_VIEW.y} ${CAMERA_VIEW.w} ${CAMERA_VIEW.h}`;
/** Convierte coordenadas del espacio de rostro a píxeles del contenedor de cámara (1440×900). */
export function toCameraPx(x: number, y: number): [number, number] {
  const k = 900 / CAMERA_VIEW.h;
  return [(x - CAMERA_VIEW.x) * k, (y - CAMERA_VIEW.y) * k];
}

/** Encuadres usados por la vista de orientación ("Recreando tu look"). */
export const ORIENT_VIEWBOX = '421 0 649 770';
