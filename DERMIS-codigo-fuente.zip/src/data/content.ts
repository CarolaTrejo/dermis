import { asset } from '../lib/assets';

/**
 * Resultados del "análisis" inicial. SON DATOS DE DEMOSTRACIÓN predefinidos:
 * el prototipo no mide el rostro; solo representa cómo se vería el resultado en el producto final.
 */
export const MOCK_FACE_ANALYSIS = {
  makeup: {
    title: 'Analizando tu rostro…',
    items: ['Forma del rostro', 'Proporciones y zonas', 'Tipo de piel', 'Adaptando tu look'],
    results: [
      { label: 'Forma del rostro', value: 'Ovalado' },
      { label: 'Subtono', value: 'Cálido' },
      { label: 'Piel', value: 'Seca' },
    ],
    features: 'Pómulos altos · mirada almendrada',
    line: 'Creamos 8 pasos personalizados para recrear tu look.',
    preparing: 'Preparando tu look',
  },
  brows: {
    title: 'Analizando tus cejas…',
    items: ['Forma actual de tus cejas', 'Simetría', 'Proporción con tu rostro', 'Adaptando el estilo'],
    results: [
      { label: 'Forma', value: 'Arco suave' },
      { label: 'Simetría', value: 'Leve asimetría' },
      { label: 'Vello', value: 'Denso' },
    ],
    features: 'Inicio alineado con la aleta de la nariz',
    line: 'Creamos 4 pasos para tu diseño de cejas.',
    preparing: 'Preparando tu diseño',
  },
} as const;

export const SKIN_PROFILE = ['Piel seca', 'Subtono cálido', 'Rostro ovalado'];

export interface AftercareStep {
  title: string;
  text: string;
  img: string;
  product: string;
  how: string[];
  tip: string;
}

export const AFTERCARE: AftercareStep[] = [
  {
    title: 'Desmaquillar', text: 'Retirá el maquillaje con agua micelar, apoyando el disco unos segundos antes de deslizarlo.', img: asset('prod17.jpg'), product: 'Agua Micelar · Garnier',
    how: ['Embebé un disco de algodón con agua micelar.', 'Apoyalo sobre los ojos 10 segundos para disolver la sombra y la máscara.', 'Deslizá hacia afuera sin frotar.', 'Repetí en el resto del rostro hasta que el disco salga limpio.'],
    tip: 'Usá un disco por zona: así no volvés a arrastrar el pigmento sobre la piel.',
  },
  {
    title: 'Limpiar', text: 'Lavá el rostro con un limpiador suave y agua tibia para retirar los restos de producto.', img: asset('prod14.jpg'), product: 'Limpiador suave en gel',
    how: ['Humedecé el rostro con agua tibia.', 'Masajeá una pequeña cantidad de limpiador durante 30 segundos.', 'Enjuagá bien, especialmente en la línea del cabello y la mandíbula.', 'Secá a toques con una toalla limpia.'],
    tip: 'El agua muy caliente reseca más la piel: mantenela tibia.',
  },
  {
    title: 'Hidratar', text: 'Aplicá una capa generosa de hidratante para recuperar la piel después del maquillaje.', img: asset('prod18.jpg'), product: 'Hydro Boost Gel Cream · Neutrogena',
    how: ['Con la piel apenas húmeda, tomá una cantidad del tamaño de una almendra.', 'Distribuí en frente, mejillas y mentón.', 'Extendé con movimientos ascendentes y hacia afuera.', 'Dejá absorber antes de apoyar la cara en la almohada.'],
    tip: 'Aplicá la crema con la piel apenas húmeda para retener la hidratación.',
  },
];

export const ASSETS = {
  avatar: asset('avatar.jpg'),
  lookCurrent: asset('look-current.jpg'),
  browCurrent: asset('brow-current.jpg'),
  /** Fotografía ilustrativa del mockup. Solo se usa en tutoriales y como respaldo cuando todavía no hay una captura de tu cámara. NUNCA reemplaza a la webcam. */
  illustrationFace: asset('camface.jpg'),
  tutMain: asset('tut-main.jpg'),
  tut: [asset('tut1.jpg'), asset('tut2.jpg'), asset('tut3.jpg'), asset('tut4.jpg')],
};
