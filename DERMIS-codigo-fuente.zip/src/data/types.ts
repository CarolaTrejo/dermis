import type { GuideType } from './faceGuides';

export type Mode = 'makeup' | 'brows';

/** Tipo de indicación del feedback simulado. */
export type FeedbackKind = 'add' | 'blend' | 'ok';

export interface FeedbackMsg {
  k: FeedbackKind;
  t: string;      // texto
  z: number;      // índice de la zona a la que apunta
  s: 'l' | 'r';   // lado de la pantalla donde aparece la burbuja
  l?: string;     // etiqueta opcional (por defecto según el tipo)
}

export interface ProcessStep {
  id: string;
  name: string;
  sub: string;
  img: string;            // miniatura de la lista de pasos
  guide: GuideType;       // overlay que corresponde a este paso
  orient: string;         // descripción breve ("¿qué tengo que hacer?")
  areas: string[];        // zonas marcadas
  vb: string;             // encuadre de la ilustración del tutorial
  tt: string;             // título del tutorial
  tx: string;             // explicación ("¿cómo lo hago?")
  tip: string;            // consejo para tu piel / tip
  ph: [string, string, string, string]; // fases (miniaturas del tutorial)
  /** Mensajes del feedback simulado: [falta producto], [difuminá], [completo] */
  m: [FeedbackMsg[], FeedbackMsg[], FeedbackMsg[]];
  success: string;        // título al completar el paso
  scanLabel: string;      // texto mientras "analiza"
  // maquillaje
  cat?: string;
  tools?: number[];
  // cejas
  how?: string;
  tcat?: string;
  realTutorial?: boolean; // usa fotos reales de tutorial en vez de ilustración
}
