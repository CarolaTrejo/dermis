import { asset } from '../lib/assets';

export interface Product {
  id: string;
  img: string | null;
  name: string;
  brand: string;
  cat: string;
  fin: string | null;   // acabado: Mate | Satinado | Jugoso
  price: string | null;
  fav: boolean;
  isNew?: boolean;
  /** id numérico original (para las herramientas sugeridas en cada paso) */
  ref?: number;
}

const RAW: [number, string, string, string, string | null, string][] = [
  [1, 'Flawless Filter Foundation', 'Charlotte Tilbury', 'Base', 'Jugoso', '$58.000'],
  [2, 'Radiant Creamy Concealer', 'NARS', 'Corrector', 'Satinado', '$42.000'],
  [3, 'Studio Fix Powder', 'MAC', 'Base', 'Mate', '$39.000'],
  [4, 'Soft Pinch Blush', 'Rare Beauty', 'Rubor', 'Jugoso', '$36.000'],
  [5, 'Hoola Bronzer', 'Benefit', 'Contorno', 'Mate', '$44.000'],
  [6, 'Extra Dimension Skinfinish', 'MAC', 'Iluminador', 'Satinado', '$41.000'],
  [7, 'Nude Obsessions Palette', 'Huda Beauty', 'Ojos', 'Mate', '$52.000'],
  [8, 'Epic Ink Liner', 'MAC', 'Ojos', 'Mate', '$25.000'],
  [9, 'Lash Sensational Mascara', 'Maybelline', 'Ojos', null, '$17.000'],
  [10, 'Gimme Brow+', 'Benefit', 'Cejas', 'Satinado', '$34.000'],
  [11, 'Matte Lipstick Mehr', 'MAC', 'Labios', 'Mate', '$32.000'],
  [12, 'Gloss Bomb Fenty Glow', 'Fenty Beauty', 'Labios', 'Jugoso', '$30.000'],
  [13, 'Brocha para Base', 'Real Techniques', 'Herramientas', null, '$14.000'],
  [14, 'Beauty Blender Original', 'Beauty Blender', 'Herramientas', null, '$28.000'],
  [15, 'Rizador de Pestañas', 'Tweezerman', 'Herramientas', null, '$22.000'],
  [16, 'All Nighter Setting Spray', 'Urban Decay', 'Preparación', 'Mate', '$40.000'],
  [17, 'Agua Micelar', 'Garnier', 'Preparación', null, '$9.000'],
  [18, 'Hydro Boost Gel Cream', 'Neutrogena', 'Preparación', 'Jugoso', '$21.000'],
];

export const INITIAL_PRODUCTS: Product[] = RAW.map(p => ({
  id: 'p' + p[0], ref: p[0], img: asset('prod' + p[0] + '.jpg'), name: p[1], brand: p[2], cat: p[3], fin: p[4], price: p[5],
  fav: [2, 10, 13].includes(p[0]),
}));

export const COLLECTION_CATEGORIES = ['Todos', 'Preparación', 'Base', 'Corrector', 'Contorno', 'Rubor', 'Iluminador', 'Ojos', 'Labios', 'Cejas', 'Herramientas'];
export const FINISHES = ['Mate', 'Satinado', 'Jugoso'];

/** Herramientas y productos para cejas (cards del tutorial de cejas). */
export interface BrowTool { id: string; img: string; brand: string; name: string; cat: 'Depilación' | 'Relleno' | 'Fijación'; price: string }
export const BROW_TOOLS: BrowTool[] = [
  { id: 'tool1', img: asset('tool1.jpg'), brand: 'Tweezerman', name: 'Pinza de cejas clásica', cat: 'Depilación', price: '$32.000' },
  { id: 'tool2', img: asset('tool2.jpg'), brand: 'Schick', name: 'Rastrillo facial', cat: 'Depilación', price: '$18.000' },
  { id: 'tool3', img: asset('tool3.jpg'), brand: 'Beter', name: 'Tijera para cejas', cat: 'Depilación', price: '$24.000' },
  { id: 'tool4', img: asset('tool4.jpg'), brand: 'Anastasia Beverly Hills', name: 'Brow Wiz (lápiz + spoolie)', cat: 'Relleno', price: '$45.000' },
  { id: 'prod10', img: asset('prod10.jpg'), brand: 'Benefit', name: 'Gimme Brow+ gel con fibras', cat: 'Relleno', price: '$34.000' },
  { id: 'tool5', img: asset('tool5.jpg'), brand: 'Benefit', name: '24-HR Brow Setter', cat: 'Fijación', price: '$38.000' },
];
