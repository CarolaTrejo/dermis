import { MAKEUP_STEPS } from './makeupSteps';
import { BROW_STEPS } from './browSteps';
import type { Mode, ProcessStep } from './types';

export const stepsFor = (mode: Mode): ProcessStep[] => (mode === 'makeup' ? MAKEUP_STEPS : BROW_STEPS);
