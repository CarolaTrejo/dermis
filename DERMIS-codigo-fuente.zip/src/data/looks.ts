import type { Mode } from './types';

import { asset } from '../lib/assets';

export interface SavedLook {
  id: string;
  kind: Mode;           // 'makeup' = look de maquillaje · 'brows' = diseño de cejas
  img: string;          // resultado (o imagen representativa)
  ref: string;          // imagen de referencia
  date: string;
  name: string;
  fav: boolean;
  minutes?: number;
}

export const INITIAL_LOOKS: SavedLook[] = [
  { id: 'l1', kind: 'makeup', img: asset('look1.jpg'), ref: asset('look3.jpg'), date: '12 May', name: 'Dorado cálido', fav: true, minutes: 24 },
  { id: 'l2', kind: 'makeup', img: asset('look2.jpg'), ref: asset('look4.jpg'), date: '8 May', name: 'Lavanda glow', fav: false, minutes: 27 },
  { id: 'l3', kind: 'makeup', img: asset('look3.jpg'), ref: asset('look1.jpg'), date: '3 May', name: 'Glam clásico', fav: false, minutes: 31 },
  { id: 'l4', kind: 'makeup', img: asset('look4.jpg'), ref: asset('look2.jpg'), date: '28 Abr', name: 'Rosado fresco', fav: true, minutes: 22 },
  { id: 'b1', kind: 'brows', img: asset('brow1.jpg'), ref: asset('brow1.jpg'), date: '12 May', name: 'Cejas tupidas', fav: false, minutes: 14 },
  { id: 'b2', kind: 'brows', img: asset('brow2.jpg'), ref: asset('brow2.jpg'), date: '22 Abr', name: 'Cejas rectas', fav: true, minutes: 12 },
  { id: 'b3', kind: 'brows', img: asset('brow3.jpg'), ref: asset('brow3.jpg'), date: '9 Mar', name: 'Cejas arqueadas', fav: false, minutes: 15 },
  { id: 'b4', kind: 'brows', img: asset('brow4.jpg'), ref: asset('brow4.jpg'), date: '17 Ene', name: 'Cejas ascendentes', fav: false, minutes: 11 },
];

/** Looks de inspiración que se pueden elegir como referencia en "Nuevo look". */
export const REFERENCE_PRESETS = [
  { img: asset('look1.jpg'), name: 'Dorado cálido' },
  { img: asset('look2.jpg'), name: 'Lavanda glow' },
  { img: asset('look3.jpg'), name: 'Glam clásico' },
  { img: asset('look4.jpg'), name: 'Rosado fresco' },
];

/** Estilos de cejas (Home de cejas y selección de "Nuevo diseño"). */
export const BROW_STYLES = [
  { id: 'naturales', img: asset('browstyle1.jpg'), name: 'Naturales', sub: 'Un acabado sutil y equilibrado' },
  { id: 'definidas', img: asset('browstyle2.jpg'), name: 'Definidas', sub: 'Una curva continua y marcada' },
  { id: 'laminadas', img: asset('browstyle4.jpg'), name: 'Laminadas', sub: 'Un look natural y delicado' },
  { id: 'suaves', img: asset('browstyle3.jpg'), name: 'Suaves', sub: 'Un acabado difuminado' },
];

/** Looks sugeridos para la recomendación por outfit (resultado simulado). */
export const OUTFIT_LOOKS = [
  { img: asset('look2.jpg'), name: 'Lavanda glow', why: 'Repite el lila del vestido en los ojos y suma brillo para la noche.' },
  { img: asset('look4.jpg'), name: 'Rosado fresco', why: 'Rubor rosado y labios jugosos que suavizan los tonos plateados.' },
  { img: asset('look1.jpg'), name: 'Dorado cálido', why: 'Contrasta con el outfit frío y resalta tu subtono cálido.' },
];

export const USED_PRODUCTS = ['Flawless Filter', 'Radiant Creamy Concealer', 'Hoola Bronzer', 'Soft Pinch Blush', 'Nude Obsessions'];
