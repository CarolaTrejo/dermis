import type { FeedbackMsg, ProcessStep } from './types';

const m = (k: FeedbackMsg['k'], t: string, z: number, s: FeedbackMsg['s'], l?: string): FeedbackMsg => ({ k, t, z, s, l });
import { asset } from '../lib/assets';

const SUCCESS = '¡Muy bien! Este paso está completo.';
const SCAN = 'Analizando aplicación…';

/** Los 8 pasos del maquillaje. Todo el flujo (orientación, tutorial y cámara) se renderiza desde acá. */
export const MAKEUP_STEPS: ProcessStep[] = [
  {
    id: 'prep', name: 'Preparación', sub: 'Hidrata y prepara tu piel', cat: 'Preparación', tools: [], img: asset('step1.jpg'), guide: 'moisturizer',
    orient: 'Hidratá y prepará tu piel.', areas: ['Frente', 'Mejillas', 'Mentón'], vb: '470 50 560 344',
    tt: 'Crema hidratante', tx: 'Aplicá una pequeña cantidad de crema sobre el rostro y distribuila suavemente con movimientos circulares. Masajeá hasta que se absorba y la piel quede hidratada, suave y uniforme.',
    tip: 'Como tu piel tiende a resecarse, aplicá una capa fina de hidratante y dejá que se absorba antes de maquillarte. Así la piel quedará más suave y el maquillaje se verá más uniforme.',
    ph: ['Aplicá', 'Distribuí', 'Masajeá', 'Resultado'],
    m: [[m('add', 'Aplicá un poco más de crema en la frente.', 0, 'r')], [m('blend', 'Distribuí con movimientos circulares.', 1, 'l'), m('ok', 'Esta zona ya está lista.', 2, 'r')], [m('ok', 'Tu piel está hidratada y lista.', 2, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
  {
    id: 'foundation', name: 'Base', sub: 'Unifica el tono de tu piel', cat: 'Base', tools: [13, 14], img: asset('step2.jpg'), guide: 'foundation',
    orient: 'Aplicá la base en todo el rostro, desde el centro hacia afuera.', areas: ['Todo el rostro', 'Centro hacia afuera'], vb: '470 50 560 344',
    tt: 'Base', tx: 'Colocá pequeñas cantidades de base en el centro del rostro y extendela hacia afuera con la brocha o la esponja húmeda. Construí la cobertura en capas finas hasta unificar el tono.',
    tip: 'Como tu piel tiende a resecarse, elegí una base de acabado jugoso y aplicala sobre la hidratante ya absorbida. Evitá el exceso de polvo sobre las mejillas.',
    ph: ['Aplicá', 'Extendé', 'Integrá', 'Resultado'],
    m: [[m('add', 'Falta base en el mentón.', 3, 'r')], [m('blend', 'Integrá un poco más este borde.', 1, 'l'), m('ok', 'Esta zona ya está lista.', 0, 'r')], [m('ok', 'El tono quedó unificado.', 2, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
  {
    id: 'concealer', name: 'Corrector', sub: 'Corrige e ilumina', cat: 'Corrector', tools: [14], img: asset('step3.jpg'), guide: 'concealer',
    orient: 'Aplicá el corrector a toques en la ojera y en las pequeñas zonas a corregir.', areas: ['Ojeras', 'Mentón'], vb: '540 220 410 254',
    tt: 'Corrector', tx: 'Aplicá el corrector debajo del ojo, desde el lagrimal hacia afuera, y en las pequeñas zonas que quieras disimular. Difuminá a toques con la yema del dedo o la esponja, sin arrastrar.',
    tip: 'La piel de la ojera es más fina y se reseca con facilidad. Hidratá la zona antes y usá una capa fina de corrector cremoso para que no marque líneas.',
    ph: ['Aplicá', 'Difuminá', 'Integrá', 'Resultado'],
    m: [[m('add', 'Aplicá un poco más debajo de este ojo.', 1, 'r')], [m('blend', 'Difuminá a toques hacia afuera.', 0, 'l'), m('ok', 'Esta zona ya está lista.', 1, 'r')], [m('ok', 'No hace falta agregar más producto.', 1, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
  {
    id: 'contour', name: 'Contorno', sub: 'Define tu rostro', cat: 'Contorno', tools: [13, 14], img: asset('step4.jpg'), guide: 'contour',
    orient: 'Aplicá el contorno en las zonas marcadas para definir suavemente el rostro.', areas: ['Laterales de la frente', 'Debajo de los pómulos', 'Mandíbula'], vb: '470 250 520 322',
    tt: 'Contorno', tx: 'Aplicá pequeñas cantidades de contorno debajo de los pómulos, en los laterales de la frente y sobre las zonas que quieras definir. Difuminá suavemente hasta lograr un acabado natural.',
    tip: 'Como tu piel tiende a resecarse, elegí un contorno en crema y aplicalo en pequeñas cantidades. Así será más fácil de difuminar y el acabado se verá más suave y uniforme.',
    ph: ['Aplicá', 'Difuminá', 'Integrá', 'Resultado'],
    m: [[m('add', 'Aplicá un poco más en esta zona.', 2, 'l')], [m('blend', 'Difuminá suavemente esta zona.', 3, 'r'), m('ok', 'Esta zona ya está lista.', 0, 'l')], [m('ok', 'No hace falta agregar más producto.', 5, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
  {
    id: 'blush', name: 'Rubor', sub: 'Aporta color al rostro', cat: 'Rubor', tools: [14], img: asset('step5.jpg'), guide: 'blush',
    orient: 'Aplicá el rubor en la parte alta de las mejillas.', areas: ['Parte alta de las mejillas'], vb: '480 250 500 310',
    tt: 'Rubor', tx: 'Sonreí suavemente y aplicá el rubor sobre la parte alta del pómulo, llevándolo en diagonal hacia la sien. Empezá con poco producto y sumá de a capas.',
    tip: 'Un rubor líquido o en crema se funde mejor sobre la piel seca y aporta un acabado fresco. Aplicalo antes de cualquier polvo.',
    ph: ['Aplicá', 'Difuminá', 'Integrá', 'Resultado'],
    m: [[m('add', 'Aplicá un toque en la parte alta del pómulo.', 1, 'r')], [m('blend', 'Integrá un poco más este borde.', 0, 'l'), m('ok', 'Esta zona ya está lista.', 1, 'r')], [m('ok', 'El color quedó parejo en ambas mejillas.', 1, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
  {
    id: 'highlighter', name: 'Iluminador', sub: 'Dale luz', cat: 'Iluminador', tools: [], img: asset('step6.jpg'), guide: 'highlighter',
    orient: 'Iluminá la parte alta de los pómulos y el puente de la nariz.', areas: ['Pómulos', 'Puente y punta de la nariz', 'Arco de cupido'], vb: '520 220 450 280',
    tt: 'Iluminador', tx: 'Aplicá el iluminador donde la luz cae naturalmente: parte alta del pómulo, puente y punta de la nariz y arco de cupido. Difuminá los bordes con un pincel suave.',
    tip: 'Elegí un iluminador satinado: en piel seca los brillos muy metalizados pueden marcar textura. Aplicalo con toques ligeros.',
    ph: ['Aplicá', 'Difuminá', 'Integrá', 'Resultado'],
    m: [[m('add', 'Sumá un toque en el puente de la nariz.', 2, 'r')], [m('blend', 'Difuminá el borde del pómulo.', 0, 'l'), m('ok', 'Esta zona ya está lista.', 1, 'r')], [m('ok', 'El brillo quedó equilibrado.', 1, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
  {
    id: 'eyes', name: 'Ojos', sub: 'Sombras y definición', cat: 'Ojos', tools: [15], img: asset('step7.jpg'), guide: 'eyes',
    orient: 'Aplicá la sombra en el párpado móvil y difuminá hacia la cola del ojo.', areas: ['Párpado móvil', 'Cola del ojo'], vb: '530 170 430 266',
    tt: 'Ojos', tx: 'Colocá la sombra lavanda en el párpado móvil y difuminá hacia el pliegue con movimientos de limpiaparabrisas. Intensificá la cola del ojo para alargar la mirada, como en tu referencia.',
    tip: 'Prepará el párpado con un poco de corrector para que la sombra se adhiera mejor y no se acumule en los pliegues.',
    ph: ['Aplicá', 'Difuminá', 'Intensificá', 'Resultado'],
    m: [[m('add', 'Aplicá más sombra en el pliegue.', 0, 'l')], [m('blend', 'Difuminá hacia la cola del ojo.', 1, 'r'), m('ok', 'Este párpado ya está listo.', 0, 'l')], [m('ok', 'Ambos ojos quedaron simétricos.', 1, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
  {
    id: 'lips', name: 'Labios', sub: 'Finaliza tu look', cat: 'Labios', tools: [], img: asset('step8.jpg'), guide: 'lips',
    orient: 'Delineá el contorno y completá la superficie de los labios.', areas: ['Contorno', 'Superficie'], vb: '600 450 290 180',
    tt: 'Labios', tx: 'Delineá primero el contorno siguiendo tu forma natural y después completá el interior con el labial. Terminá con un toque de gloss en el centro del labio inferior.',
    tip: 'Exfoliá e hidratá los labios antes de empezar. Así el color se desliza mejor y el acabado no marca pielcitas.',
    ph: ['Delineá', 'Completá', 'Unificá', 'Resultado'],
    m: [[m('add', 'Completá el contorno del labio superior.', 0, 'r')], [m('blend', 'Unificá el color en el centro.', 1, 'l'), m('ok', 'Esta zona ya está lista.', 0, 'r')], [m('ok', 'Labios completos.', 1, 'r')]],
    success: SUCCESS, scanLabel: SCAN,
  },
];
