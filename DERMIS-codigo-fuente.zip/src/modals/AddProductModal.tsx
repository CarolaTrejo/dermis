import { useEffect, useRef, useState } from 'react';
import { css } from '../lib/css';
import { Modal, ModalHeader } from '../components/Modal';
import { ImageUploader, type ImagePickerHandle } from '../components/ImageUploader';
import { CameraCapture } from '../camera/CameraCapture';
import { FilterChips } from '../components/FilterChips';
import { Camera, Gallery, Pencil } from '../components/Icons';
import { COLLECTION_CATEGORIES, FINISHES, type Product } from '../data/products';
import { useStore } from '../state/AppStore';

type Stage = 'options' | 'camera' | 'processing' | 'form' | 'saving';
interface Form { brand: string; name: string; cat: string; fin: string; suggested: boolean }
const EMPTY: Form = { brand: '', name: '', cat: 'Base', fin: 'Mate', suggested: false };
/** ⚠️ SIMULADO: el prototipo no reconoce productos; propone esta sugerencia editable para la demo. */
const DEMO_SUGGESTION: Form = { brand: 'Rare Beauty', name: 'Positive Light Liquid Luminizer', cat: 'Iluminador', fin: 'Satinado', suggested: true };

export function AddProductModal({ open, onClose, onAdded }: { open: boolean; onClose: () => void; onAdded: () => void }) {
  const { addProduct, showToast } = useStore();
  const picker = useRef<ImagePickerHandle>(null);
  const [stage, setStage] = useState<Stage>('options');
  const [label, setLabel] = useState('');
  const [photo, setPhoto] = useState<string | null>(null);
  const [form, setForm] = useState<Form>(EMPTY);
  const timer = useRef<number>();

  useEffect(() => {
    if (open) { setStage('options'); setPhoto(null); setForm(EMPTY); }
    return () => window.clearTimeout(timer.current);
  }, [open]);

  const process = (url: string, text: string) => {
    setPhoto(url);
    setLabel(text);
    setStage('processing');
    timer.current = window.setTimeout(() => { setForm(DEMO_SUGGESTION); setStage('form'); }, 1500);
  };
  const valid = form.brand.trim() && form.name.trim();
  const submit = () => {
    if (!valid) return;
    setStage('saving');
    timer.current = window.setTimeout(() => {
      const p: Product = { id: 'n' + Date.now(), img: photo, name: form.name.trim(), brand: form.brand.trim(), cat: form.cat, fin: form.fin, price: null, fav: false, isNew: true };
      addProduct(p);
      onAdded();
      onClose();
      showToast('Producto agregado. DERMIS lo va a priorizar en tus recomendaciones.');
    }, 700);
  };

  const opts = [
    { icon: <Camera size={22} />, title: 'Tomar foto', sub: 'Usá tu cámara para fotografiar el producto', go: () => setStage('camera') },
    { icon: <Gallery size={22} />, title: 'Subir desde galería', sub: 'Usá una foto que ya tengas', go: () => picker.current?.open() },
    { icon: <Pencil />, title: 'Agregar manualmente', sub: 'Completá marca, nombre, categoría y acabado', go: () => { setPhoto(null); setForm(EMPTY); setStage('form'); } },
  ];

  return (
    <Modal open={open} onClose={onClose} width={760} labelledBy="add-title">
      <ImageUploader ref={picker} maxSide={500} onPick={url => (stage === 'form' ? setPhoto(url) : process(url, 'Analizando foto…'))} onError={showToast} />
      <ModalHeader id="add-title" title="Agregar producto" sub="DERMIS va a priorizar tus productos al recomendarte cómo aplicar cada paso." onClose={onClose} />

      {stage === 'options' && (
        <div className="fade-in" style={css('display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:22px')}>
          {opts.map((o, j) => (
            <button key={o.title} type="button" onClick={o.go} className="hv-card"
              style={css(`display:flex;gap:16px;align-items:center;padding:20px;border-radius:20px;border:1.5px solid #ECE8F6;background:#FFFFFF;cursor:pointer;text-align:left;${j === 2 ? 'grid-column:1/-1' : ''}`)}>
              <div style={css('width:52px;height:52px;border-radius:16px;background:#F1EEFF;color:#6C5EF0;display:flex;align-items:center;justify-content:center;flex-shrink:0')}>{o.icon}</div>
              <div><div style={css('font-size:17px;font-weight:600;color:#1D1B2C')}>{o.title}</div><div style={css('font-size:14px;color:#8A8798;margin-top:3px')}>{o.sub}</div></div>
            </button>
          ))}
        </div>
      )}

      {stage === 'camera' && (
        <>
          <CameraCapture height={320} hint="Encuadrá el producto dentro del recuadro" outW={600} outH={600} frameInset="30px 220px"
            onUse={url => process(url, 'Reconociendo producto…')} />
          <div style={css('display:flex;justify-content:flex-end;margin-top:16px')}>
            <button type="button" onClick={() => setStage('options')} style={css('height:46px;padding:0 18px;border:none;background:none;color:#6F6C80;font-size:16px;cursor:pointer')}>Volver</button>
          </div>
        </>
      )}

      {(stage === 'processing' || stage === 'saving') && (
        <div role="status" style={css('position:relative;margin-top:22px;height:300px;border-radius:20px;background:repeating-linear-gradient(45deg,#F4F1FC 0 10px,#FBFAFE 10px 20px);overflow:hidden;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px')}>
          {photo && <img src={photo} alt="Foto del producto" style={css('height:170px;max-width:60%;object-fit:contain;border-radius:14px')} />}
          <div style={css('position:absolute;left:0;right:0;top:0;height:120px;background:linear-gradient(to bottom,rgba(123,110,246,0),rgba(123,110,246,.25),rgba(123,110,246,0));animation:dmScan 1.8s linear infinite')} />
          <div style={css('font-size:17px;color:#4A475C;display:flex;gap:10px;align-items:center')}>
            <span style={css('width:18px;height:18px;border-radius:50%;border:2.5px solid #E1DBFB;border-top-color:#7B6EF6;animation:dmSpin .9s linear infinite')} />
            {stage === 'saving' ? 'Guardando producto…' : label}
          </div>
        </div>
      )}

      {stage === 'form' && (
        <div className="fade-in">
          <div style={css('display:grid;grid-template-columns:200px 1fr;gap:24px;margin-top:22px')}>
            <button type="button" onClick={() => picker.current?.open()} aria-label={photo ? 'Cambiar foto del producto' : 'Agregar foto del producto'} className="hv-lav"
              style={css('height:250px;border-radius:18px;border:none;background:repeating-linear-gradient(45deg,#F4F1FC 0 8px,#FBFAFE 8px 16px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;font-family:ui-monospace,monospace;font-size:11px;color:#9C97B5;text-align:center;cursor:pointer;position:relative;overflow:hidden;padding:0')}>
              {photo ? <img src={photo} alt="" style={css('position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#FFFFFF')} /> : <>foto del producto<span style={css("font-family:Satoshi,sans-serif;font-size:13px;color:#7B6EF6")}>+ Agregar foto</span></>}
              {form.suggested && <span style={css('position:absolute;bottom:10px;font-family:Satoshi,sans-serif;font-size:13px;color:#6C5EF0;background:#FFFFFF;border-radius:10px;padding:4px 10px;box-shadow:0 2px 8px rgba(40,30,80,.12)')}>Sugerencia de DERMIS</span>}
            </button>
            <div style={css('display:flex;flex-direction:column;gap:14px')}>
              {form.suggested && <div style={css('font-size:13.5px;color:#6C5EF0;background:#F3F0FF;border-radius:12px;padding:8px 12px')}>Completamos los datos automáticamente. Revisalos antes de guardar.</div>}
              <label style={css('display:flex;flex-direction:column;gap:6px;font-size:13.5px;color:#6F6C80')}>Marca
                <input value={form.brand} onChange={e => { const brand = e.target.value; setForm(f => ({ ...f, brand })); }} placeholder="Ej. Rare Beauty" autoFocus
                  style={css('height:46px;border:1.5px solid #E6E2F2;border-radius:12px;padding:0 14px;font-size:16px;color:#1D1B2C;outline:none')} />
              </label>
              <label style={css('display:flex;flex-direction:column;gap:6px;font-size:13.5px;color:#6F6C80')}>Nombre
                <input value={form.name} onChange={e => { const name = e.target.value; setForm(f => ({ ...f, name })); }} placeholder="Nombre del producto"
                  onKeyDown={e => { if (e.key === 'Enter') submit(); }}
                  style={css('height:46px;border:1.5px solid #E6E2F2;border-radius:12px;padding:0 14px;font-size:16px;color:#1D1B2C;outline:none')} />
              </label>
              <div style={css('font-size:13.5px;color:#6F6C80')}>Categoría</div>
              <div style={css('margin-top:-6px')}><FilterChips variant="small" label="Categoría" options={COLLECTION_CATEGORIES.slice(1)} value={form.cat} onChange={cat => setForm(f => ({ ...f, cat }))} /></div>
              <div style={css('font-size:13.5px;color:#6F6C80')}>Acabado</div>
              <div style={css('margin-top:-6px')}><FilterChips variant="small" label="Acabado" options={FINISHES} value={form.fin} onChange={fin => setForm(f => ({ ...f, fin }))} /></div>
            </div>
          </div>
          <div style={css('display:flex;justify-content:flex-end;gap:12px;margin-top:22px')}>
            <button type="button" onClick={() => setStage('options')} style={css('height:52px;padding:0 22px;border:none;background:none;color:#6F6C80;font-size:16px;cursor:pointer')}>Volver</button>
            <button type="button" onClick={submit} disabled={!valid} className="hv-primary"
              style={css(`height:52px;padding:0 26px;border-radius:16px;border:none;background:${valid ? '#7B6EF6' : '#C9C2F5'};color:#FFFFFF;font-size:16.5px;font-weight:600;cursor:pointer`)}>Agregar a mi colección</button>
          </div>
        </div>
      )}
    </Modal>
  );
}
