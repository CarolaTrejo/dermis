import { useState } from 'react';
import { css } from '../lib/css';
import { Modal, ModalHeader } from '../components/Modal';
import { useStore } from '../state/AppStore';
import { ASSETS, SKIN_PROFILE } from '../data/content';
import { Info } from '../components/Icons';

export function ProfileModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { looks, products, prefs, setPrefs, resetDemo } = useStore();
  const [confirm, setConfirm] = useState(false);
  const stats = [
    ['Looks guardados', looks.filter(l => l.kind === 'makeup').length],
    ['Diseños de cejas', looks.filter(l => l.kind === 'brows').length],
    ['Productos', products.length],
    ['Favoritos', products.filter(p => p.fav).length + looks.filter(l => l.fav).length],
  ] as const;

  return (
    <Modal open={open} onClose={() => { setConfirm(false); onClose(); }} width={640} labelledBy="profile-title">
      <ModalHeader id="profile-title" title="Tu perfil" sub="DERMIS adapta cada paso a tu piel y a tu rostro." onClose={onClose} />
      <div style={css('display:flex;gap:18px;align-items:center;margin-top:22px')}>
        <img src={ASSETS.avatar} alt="Foto de perfil de Sofía" style={css('width:72px;height:72px;border-radius:50%;object-fit:cover;border:3px solid #E9E4FF')} />
        <div>
          <div style={css('font-size:22px;font-weight:700')}>Sofía</div>
          <div style={css('display:flex;gap:8px;margin-top:8px;flex-wrap:wrap')}>
            {SKIN_PROFILE.map(s => <span key={s} style={css('background:#F1EEFF;color:#5A4CE0;border-radius:12px;padding:5px 12px;font-size:13.5px')}>{s}</span>)}
          </div>
        </div>
      </div>
      <div style={css('display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:22px')}>
        {stats.map(([l, v]) => (
          <div key={l} style={css('background:#FCFBFE;border:1px solid #EEEAF7;border-radius:16px;padding:14px')}>
            <div style={css('font-size:24px;font-weight:700;color:#6C5EF0')}>{v}</div>
            <div style={css('font-size:13px;color:#8A8798;margin-top:2px')}>{l}</div>
          </div>
        ))}
      </div>
      <label style={css('display:flex;justify-content:space-between;align-items:center;margin-top:22px;padding:14px 16px;border:1px solid #EEEAF7;border-radius:16px;cursor:pointer')}>
        <span><span style={css('font-size:15.5px;font-weight:600;display:block')}>Modo espejo</span><span style={css('font-size:13.5px;color:#8A8798')}>La cámara se ve reflejada, como un espejo.</span></span>
        <input type="checkbox" checked={prefs.mirror} onChange={e => setPrefs({ mirror: e.target.checked })} style={{ width: 20, height: 20, accentColor: '#7B6EF6' }} />
      </label>
      <div style={css('display:flex;gap:10px;align-items:flex-start;margin-top:16px;font-size:13.5px;color:#6F6C80;line-height:1.5;background:#F6F4FC;border-radius:14px;padding:12px 14px')}>
        <span style={css('color:#7B6EF6;margin-top:2px')}><Info /></span>
        Prototipo de tesis: la cámara es real, pero el análisis facial y el feedback de aplicación están simulados con datos de demostración.
      </div>
      <div style={css('display:flex;justify-content:space-between;align-items:center;margin-top:22px')}>
        {confirm ? (
          <div style={css('display:flex;gap:10px;align-items:center')}>
            <span style={css('font-size:14.5px;color:#4A475C')}>¿Restablecer progreso, favoritos y colección?</span>
            <button type="button" onClick={() => { resetDemo(); setConfirm(false); onClose(); }}
              style={css('height:42px;padding:0 16px;border-radius:12px;border:none;background:#D2557A;color:#FFFFFF;font-size:14.5px;font-weight:600;cursor:pointer')}>Sí, restablecer</button>
            <button type="button" onClick={() => setConfirm(false)} style={css('height:42px;padding:0 12px;border:none;background:none;color:#6F6C80;font-size:14.5px;cursor:pointer')}>Cancelar</button>
          </div>
        ) : (
          <button type="button" onClick={() => setConfirm(true)} className="hv-del"
            style={css('height:42px;padding:0;border:none;background:none;color:#8A8798;font-size:14.5px;cursor:pointer')}>Restablecer datos de la demo</button>
        )}
        <button type="button" onClick={onClose} className="hv-primary"
          style={css('height:48px;padding:0 24px;border-radius:14px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:16px;font-weight:600;cursor:pointer')}>Listo</button>
      </div>
    </Modal>
  );
}
