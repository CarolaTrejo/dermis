import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { css } from '../lib/css';
import { Modal, ModalHeader } from '../components/Modal';
import { useStore } from '../state/AppStore';
import { USED_PRODUCTS, type SavedLook } from '../data/looks';
import { BROW_TOOLS } from '../data/products';
import { routes } from '../lib/routes';

interface Props { look: SavedLook | null; tab?: 'ver' | 'cmp'; onClose: () => void }

/** Ver un look / diseño guardado: Resultado · Comparar · Recrear. */
export function LookModal({ look, tab = 'ver', onClose }: Props) {
  const navigate = useNavigate();
  const { startSession } = useStore();
  const [t, setT] = useState(tab);
  useEffect(() => setT(tab), [tab, look]);
  if (!look) return null;
  const brows = look.kind === 'brows';
  const recreate = () => { startSession(look.kind, look.img, look.name); navigate(routes.scan(look.kind)); };
  const seg = (k: 'ver' | 'cmp', label: string) => (
    <button type="button" role="tab" aria-selected={t === k} onClick={() => setT(k)}
      style={css(`height:36px;padding:0 18px;border-radius:11px;border:none;background:${t === k ? '#FFFFFF' : 'transparent'};color:#1D1B2C;font-size:14.5px;cursor:pointer`)}>{label}</button>
  );

  return (
    <Modal open onClose={onClose} width={860} labelledBy="look-title">
      <ModalHeader id="look-title" onClose={onClose}
        title={<><div style={css('font-size:14px;color:#8A8798;font-weight:400')}>{look.date}</div><div style={css('margin-top:2px')}>{look.name}</div></>}
        right={<div role="tablist" style={css('display:inline-flex;background:#F4F2F9;border-radius:14px;padding:4px')}>{seg('ver', 'Resultado')}{seg('cmp', 'Comparar')}</div>} />
      {t === 'ver' ? (
        <div className="fade-in" style={css('display:grid;grid-template-columns:360px 1fr;gap:28px;margin-top:22px')}>
          <img src={look.img} alt={`Resultado: ${look.name}`} style={css('width:360px;height:440px;object-fit:cover;border-radius:20px')} />
          <div style={css('display:flex;flex-direction:column;gap:14px')}>
            <div style={css('font-size:13px;letter-spacing:.12em;color:#9A97A6;font-weight:600')}>PASOS</div>
            <div style={css('font-size:16px;color:#3D3A4E')}>{brows ? '4 de 4' : '8 de 8'} completados · {look.minutes ?? 20} min</div>
            <div style={css('font-size:13px;letter-spacing:.12em;color:#9A97A6;font-weight:600;margin-top:8px')}>{brows ? 'HERRAMIENTAS UTILIZADAS' : 'PRODUCTOS UTILIZADOS'}</div>
            <div style={css('display:flex;flex-wrap:wrap;gap:8px')}>
              {(brows ? BROW_TOOLS.slice(0, 4).map(b => b.name) : USED_PRODUCTS).map(p =>
                <span key={p} style={css('background:#F1EEFF;color:#5A4CE0;border-radius:12px;padding:6px 12px;font-size:14px')}>{p}</span>)}
            </div>
            <button type="button" onClick={recreate} className="hv-primary"
              style={css('margin-top:auto;height:54px;border-radius:16px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:17px;font-weight:600;cursor:pointer')}>
              {brows ? 'Recrear este diseño →' : 'Recrear este look →'}
            </button>
          </div>
        </div>
      ) : (
        <div className="fade-in" style={css('display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:22px')}>
          <div><div style={css('font-size:14px;color:#6F6C80;margin-bottom:8px')}>Referencia</div><img src={look.ref} alt="Imagen de referencia" style={css('width:100%;height:440px;object-fit:cover;border-radius:20px;display:block')} /></div>
          <div><div style={css('font-size:14px;color:#6F6C80;margin-bottom:8px')}>Tu resultado</div><img src={look.img} alt="Tu resultado" style={css('width:100%;height:440px;object-fit:cover;border-radius:20px;display:block')} /></div>
        </div>
      )}
    </Modal>
  );
}
