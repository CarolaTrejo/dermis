import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { css } from '../lib/css';
import { Modal, ModalHeader } from '../components/Modal';
import { ImageUploader, type ImagePickerHandle } from '../components/ImageUploader';
import { CameraCapture } from '../camera/CameraCapture';
import { Check, Gallery, Plus, Trash } from '../components/Icons';
import { BROW_STYLES, REFERENCE_PRESETS } from '../data/looks';
import { useStore } from '../state/AppStore';
import { routes } from '../lib/routes';
import type { Mode } from '../data/types';

interface Props {
  mode: Mode;
  open: boolean;
  onClose: () => void;
  initialSource?: 'gallery' | 'camera';
  initialPick?: string;
  initialStyle?: string;
}

type Sel = 'custom' | number | null;

/**
 * "Nuevo look" / "Nuevo diseño de cejas": elegir la IMAGEN DE REFERENCIA
 * (galería real del dispositivo, cámara real o una inspiración de DERMIS).
 */
export function UploadReferenceModal({ mode, open, onClose, initialSource, initialPick, initialStyle }: Props) {
  const navigate = useNavigate();
  const { startSession, showToast } = useStore();
  const picker = useRef<ImagePickerHandle>(null);
  const brows = mode === 'brows';
  const presets = brows ? BROW_STYLES.map(s => ({ img: s.img, name: s.name })) : REFERENCE_PRESETS;

  const [tab, setTab] = useState<'galeria' | 'camara'>(initialSource === 'camera' ? 'camara' : 'galeria');
  const [custom, setCustom] = useState<string | null>(initialPick ?? null);
  const [sel, setSel] = useState<Sel>(initialPick ? 'custom' : null);

  useEffect(() => {
    if (!open) return;
    setTab(initialSource === 'camera' ? 'camara' : 'galeria');
    setCustom(initialPick ?? null);
    const styleIdx = initialStyle ? BROW_STYLES.findIndex(s => s.id === initialStyle) : -1;
    setSel(initialPick ? 'custom' : styleIdx >= 0 ? styleIdx : null);
  }, [open, initialSource, initialPick, initialStyle]);

  const confirm = () => {
    if (sel == null) return;
    const ref = sel === 'custom' ? custom! : presets[sel].img;
    const name = sel === 'custom' ? (brows ? 'Mi diseño' : 'Mi look') : presets[sel].name;
    startSession(mode, ref, name);
    navigate(routes.scan(mode));
  };

  const tabBtn = (k: 'galeria' | 'camara', label: string) => (
    <button type="button" role="tab" aria-selected={tab === k} onClick={() => setTab(k)}
      style={css(`height:38px;padding:0 20px;border-radius:11px;border:none;background:${tab === k ? '#FFFFFF' : 'transparent'};color:#1D1B2C;font-size:15px;cursor:pointer;box-shadow:${tab === k ? '0 2px 6px rgba(40,30,80,.08)' : 'none'}`)}>
      {label}
    </button>
  );

  return (
    <Modal open={open} onClose={onClose} width={820} labelledBy="upload-title">
      <ImageUploader ref={picker} onPick={url => { setCustom(url); setSel('custom'); setTab('galeria'); }} onError={showToast} />
      <ModalHeader id="upload-title" title={brows ? 'Nuevo diseño de cejas' : 'Nuevo look'} onClose={onClose}
        sub={brows ? 'Elegí el estilo de cejas que querés lograr o subí tu propia referencia.' : 'Elegí la imagen de referencia que querés recrear.'} />
      <div role="tablist" aria-label="Origen de la imagen" style={css('display:inline-flex;background:#F4F2F9;border-radius:14px;padding:4px;margin-top:20px')}>
        {tabBtn('galeria', brows ? 'Estilos y galería' : 'Galería')}
        {tabBtn('camara', 'Cámara')}
      </div>

      {tab === 'galeria' && (
        <div className="fade-in" style={css('display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:14px;margin-top:18px')}>
          {custom ? (
            <div style={css(`position:relative;border:3px solid ${sel === 'custom' ? '#7B6EF6' : 'transparent'};border-radius:18px;overflow:hidden;height:230px;background:#EEE;box-sizing:border-box`)}>
              <button type="button" onClick={() => setSel('custom')} aria-pressed={sel === 'custom'} aria-label="Usar mi imagen como referencia"
                style={css('position:absolute;inset:0;padding:0;border:none;background:none;cursor:pointer')}>
                <img src={custom} alt="Tu imagen de referencia" style={css('width:100%;height:100%;object-fit:cover;display:block')} />
              </button>
              {sel === 'custom' && <SelBadge />}
              <div style={css('position:absolute;left:8px;right:8px;bottom:8px;display:flex;gap:6px')}>
                <button type="button" onClick={() => picker.current?.open()}
                  style={css('flex:1;height:32px;border-radius:10px;border:none;background:rgba(255,255,255,.94);color:#6C5EF0;font-size:13px;font-weight:600;cursor:pointer')}>Cambiar</button>
                <button type="button" aria-label="Eliminar imagen" onClick={() => { setCustom(null); if (sel === 'custom') setSel(null); }} className="hv-del"
                  style={css('width:32px;height:32px;border-radius:10px;border:none;background:rgba(255,255,255,.94);color:#6F6C80;cursor:pointer;display:flex;align-items:center;justify-content:center')}><Trash size={16} /></button>
              </div>
            </div>
          ) : (
            <button type="button" onClick={() => picker.current?.open()} className="hv-lav"
              style={css('height:230px;border:1.5px dashed #D9D3F5;border-radius:18px;background:#FCFBFF;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;cursor:pointer;color:#7A7789;font-size:14px;padding:0 10px;text-align:center')}>
              <span style={css('width:46px;height:46px;border-radius:50%;background:#F1EEFF;display:flex;align-items:center;justify-content:center;color:#7B6EF6')}><Gallery size={20} /></span>
              Subir desde tu galería
            </button>
          )}
          {presets.map((p, j) => (
            <button key={p.img} type="button" onClick={() => setSel(j)} aria-pressed={sel === j} aria-label={`Elegir ${p.name}`}
              style={css(`position:relative;padding:0;border:3px solid ${sel === j ? '#7B6EF6' : 'transparent'};border-radius:18px;overflow:hidden;cursor:pointer;height:230px;background:#EEE`)}>
              <img src={p.img} alt="" style={css('width:100%;height:100%;object-fit:cover;display:block')} />
              {sel === j && <SelBadge />}
              {brows && <span style={css('position:absolute;left:0;right:0;bottom:0;padding:22px 10px 10px;background:linear-gradient(to top,rgba(0,0,0,.55),rgba(0,0,0,0));color:#FFFFFF;font-size:14.5px;font-weight:600;text-align:left')}>{p.name}</span>}
            </button>
          ))}
        </div>
      )}

      {tab === 'camara' && (
        <CameraCapture height={290} hint={brows ? 'Mostrá la ceja o imagen de referencia' : 'Apuntá la cámara a la imagen de referencia'}
          onUse={url => { setCustom(url); setSel('custom'); setTab('galeria'); showToast('Imagen capturada'); }} />
      )}

      <div style={css('display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:22px')}>
        <button type="button" onClick={() => picker.current?.open()} className="hv-txt"
          style={css('height:52px;padding:0;border:none;background:none;color:#7B6EF6;font-size:15.5px;cursor:pointer;display:flex;gap:8px;align-items:center')}>
          <Plus size={16} />Subir otra imagen
        </button>
        <div style={css('display:flex;gap:12px')}>
          <button type="button" onClick={onClose} style={css('height:52px;padding:0 22px;border:none;background:none;color:#6F6C80;font-size:16px;cursor:pointer')}>Cancelar</button>
          <button type="button" onClick={confirm} disabled={sel == null} className="hv-primary"
            style={css(`height:52px;padding:0 26px;border-radius:16px;border:none;background:${sel == null ? '#C9C2F5' : '#7B6EF6'};color:#FFFFFF;font-size:16.5px;font-weight:600;cursor:pointer`)}>
            {brows ? 'Analizar mis cejas →' : 'Analizar mi rostro →'}
          </button>
        </div>
      </div>
    </Modal>
  );
}

function SelBadge() {
  return (
    <span className="pop-in" style={css('position:absolute;top:10px;right:10px;width:28px;height:28px;border-radius:50%;background:#7B6EF6;display:flex;align-items:center;justify-content:center;color:#FFFFFF')}>
      <Check size={15} strokeWidth={3} />
    </span>
  );
}
