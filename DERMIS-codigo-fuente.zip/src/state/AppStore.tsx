import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import { load, save, clearAll } from '../lib/storage';
import { INITIAL_PRODUCTS, type Product } from '../data/products';
import { INITIAL_LOOKS, type SavedLook } from '../data/looks';
import { stepsFor } from '../data/steps';
import type { Mode } from '../data/types';

/** Sesión de un proceso guiado (maquillaje o cejas). */
export interface Session {
  active: boolean;
  ref: string;        // imagen de referencia (ruta de asset o data URL local)
  refName: string;
  current: number;    // índice del paso actual
  done: boolean[];    // pasos completados
  elapsed: number;    // segundos transcurridos
}

export interface Prefs { mirror: boolean; showOval: boolean }

import { asset } from '../lib/assets';

// Estado inicial de la demo: replica el diseño original (maquillaje en "Paso 3 de 8 — Corrector").
const SEED_MAKEUP: Session = { active: true, ref: asset('look2.jpg'), refName: 'Lavanda glow', current: 2, done: [true, true, false, false, false, false, false, false], elapsed: 324 };
const SEED_BROWS: Session = { active: true, ref: asset('browstyle1.jpg'), refName: 'Naturales', current: 0, done: [false, false, false, false], elapsed: 15 };



function usePersistent<T>(key: string, initial: T) {
  const [value, setValue] = useState<T>(() => load(key, initial));
  const first = useRef(true);
  useEffect(() => {
    if (first.current) { first.current = false; return; }
    if (!save(key, value)) console.info(`[DERMIS] No se pudo guardar "${key}" en localStorage (se mantiene en memoria).`);
  }, [key, value]);
  return [value, setValue] as const;
}

interface Toast { id: number; msg: string }

interface AppStore {
  products: Product[];
  looks: SavedLook[];
  makeup: Session;
  brows: Session;
  toolFav: Record<string, boolean>;
  routine: boolean[];
  snapshots: Partial<Record<Mode, string>>;
  results: Partial<Record<Mode, string>>;
  prefs: Prefs;
  toast: Toast | null;

  session: (mode: Mode) => Session;
  showToast: (msg: string) => void;
  startSession: (mode: Mode, ref: string, refName: string) => void;
  setCurrent: (mode: Mode, index: number) => void;
  completeStep: (mode: Mode, index: number) => number; // devuelve el próximo paso pendiente o -1
  tick: (mode: Mode) => void;
  endSession: (mode: Mode) => void;
  toggleProductFav: (id: string) => void;
  addProduct: (p: Product) => void;
  toggleLookFav: (id: string) => void;
  removeLook: (id: string) => void;
  addLook: (look: SavedLook) => void;
  toggleToolFav: (id: string) => void;
  toggleRoutine: (i: number) => void;
  setSnapshot: (mode: Mode, url: string | undefined) => void;
  setResult: (mode: Mode, url: string | undefined) => void;
  setPrefs: (p: Partial<Prefs>) => void;
  resetDemo: () => void;
}

const Ctx = createContext<AppStore | null>(null);

export function AppStoreProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = usePersistent<Product[]>('products', INITIAL_PRODUCTS);
  const [looks, setLooks] = usePersistent<SavedLook[]>('looks', INITIAL_LOOKS);
  const [makeup, setMakeup] = usePersistent<Session>('session.makeup', SEED_MAKEUP);
  const [brows, setBrows] = usePersistent<Session>('session.brows', SEED_BROWS);
  const [toolFav, setToolFav] = usePersistent<Record<string, boolean>>('toolFav', {});
  const [routine, setRoutine] = usePersistent<boolean[]>('routine', [false, false, false]);
  const [snapshots, setSnapshots] = usePersistent<Partial<Record<Mode, string>>>('snapshots', {});
  const [results, setResults] = usePersistent<Partial<Record<Mode, string>>>('results', {});
  const [prefs, setPrefsState] = usePersistent<Prefs>('prefs', { mirror: true, showOval: true });
  const [toast, setToast] = useState<Toast | null>(null);
  const toastTimer = useRef<number>();

  const setSession = useCallback((mode: Mode, fn: (s: Session) => Session) => {
    (mode === 'makeup' ? setMakeup : setBrows)(fn);
  }, [setMakeup, setBrows]);

  const showToast = useCallback((msg: string) => {
    window.clearTimeout(toastTimer.current);
    setToast({ id: Date.now(), msg });
    toastTimer.current = window.setTimeout(() => setToast(null), 2800);
  }, []);

  const store = useMemo<AppStore>(() => ({
    products, looks, makeup, brows, toolFav, routine, snapshots, results, prefs, toast,
    session: mode => (mode === 'makeup' ? makeup : brows),
    showToast,
    startSession: (mode, ref, refName) => {
      const n = stepsFor(mode).length;
      setSession(mode, () => ({ active: true, ref, refName, current: 0, done: Array(n).fill(false), elapsed: 0 }));
      setResults(r => ({ ...r, [mode]: undefined }));
    },
    setCurrent: (mode, index) => setSession(mode, s => ({ ...s, active: true, current: index })),
    completeStep: (mode, index) => {
      const s = mode === 'makeup' ? makeup : brows;
      const done = [...s.done];
      done[index] = true;
      let next = done.findIndex((d, j) => !d && j > index);
      if (next < 0) next = done.findIndex(d => !d);
      setSession(mode, cur => ({ ...cur, done, current: next < 0 ? index : next }));
      return next;
    },
    tick: mode => setSession(mode, s => ({ ...s, elapsed: s.elapsed + 1 })),
    endSession: mode => setSession(mode, s => ({ ...s, active: false })),
    toggleProductFav: id => setProducts(ps => ps.map(p => (p.id === id ? { ...p, fav: !p.fav } : p))),
    addProduct: p => setProducts(ps => [p, ...ps]),
    toggleLookFav: id => setLooks(ls => ls.map(l => (l.id === id ? { ...l, fav: !l.fav } : l))),
    removeLook: id => setLooks(ls => ls.filter(l => l.id !== id)),
    addLook: look => setLooks(ls => [look, ...ls]),
    toggleToolFav: id => setToolFav(f => ({ ...f, [id]: !f[id] })),
    toggleRoutine: i => setRoutine(r => r.map((v, j) => (j === i ? !v : v))),
    setSnapshot: (mode, url) => setSnapshots(s => ({ ...s, [mode]: url })),
    setResult: (mode, url) => setResults(r => ({ ...r, [mode]: url })),
    setPrefs: p => setPrefsState(cur => ({ ...cur, ...p })),
    resetDemo: () => {
      clearAll();
      setProducts(INITIAL_PRODUCTS); setLooks(INITIAL_LOOKS); setMakeup(SEED_MAKEUP); setBrows(SEED_BROWS);
      setToolFav({}); setRoutine([false, false, false]); setSnapshots({}); setResults({}); setPrefsState({ mirror: true, showOval: true });
      showToast('Datos de la demo restablecidos');
    },
  }), [products, looks, makeup, brows, toolFav, routine, snapshots, results, prefs, toast, showToast, setSession,
    setProducts, setLooks, setMakeup, setBrows, setToolFav, setRoutine, setSnapshots, setResults, setPrefsState]);

  return <Ctx.Provider value={store}>{children}</Ctx.Provider>;
}

export function useStore(): AppStore {
  const s = useContext(Ctx);
  if (!s) throw new Error('useStore debe usarse dentro de AppStoreProvider');
  return s;
}
