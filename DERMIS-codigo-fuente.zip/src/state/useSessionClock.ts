import { useEffect } from 'react';
import { useStore } from './AppStore';
import type { Mode } from '../data/types';

/** Cronómetro de la sesión (se guarda en localStorage junto con el progreso). */
export function useSessionClock(mode: Mode, running: boolean) {
  const { tick } = useStore();
  useEffect(() => {
    if (!running) return;
    const t = window.setInterval(() => tick(mode), 1000);
    return () => window.clearInterval(t);
  }, [mode, running, tick]);
}
