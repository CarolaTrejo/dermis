import { useCallback, useRef, useState } from 'react';
import { css } from '../lib/css';
import { captureFrame } from '../lib/image';
import { CameraView } from './CameraView';
import type { CameraStatus } from './useCamera';
import { Retry, Check } from '../components/Icons';

interface Props {
  height: number;
  hint: string;
  /** Se llama con la foto confirmada ("Usar foto"). */
  onUse: (dataUrl: string) => void;
  /** Ancho/alto de la foto generada. */
  outW?: number;
  outH?: number;
  /** Encuadre punteado de ayuda */
  frameInset?: string;
}

/**
 * Cámara en vivo + "Capturar" → preview → "Usar foto" / "Repetir".
 * La captura se hace dibujando el frame del <video> en un <canvas> (sin servidor).
 */
export function CameraCapture({ height, hint, onUse, outW = 720, outH = 900, frameInset = '36px 200px' }: Props) {
  const video = useRef<HTMLVideoElement | null>(null);
  const [status, setStatus] = useState<CameraStatus>('idle');
  const [shot, setShot] = useState<string | null>(null);
  const [flash, setFlash] = useState(false);
  const onVideo = useCallback((v: HTMLVideoElement | null) => { video.current = v; }, []);

  const capture = () => {
    if (!video.current) return;
    // La foto se guarda sin espejar (la imagen real), aunque la vista previa sea un espejo.
    const url = captureFrame(video.current, { width: outW, height: outH, mirrored: false });
    if (!url) return;
    setFlash(true);
    window.setTimeout(() => setFlash(false), 180);
    setShot(url);
  };

  return (
    <div style={{ ...css('position:relative;margin-top:18px;border-radius:20px;background:#2A211C;overflow:hidden;color:#FFFFFF'), height }}>
      {/* La cámara se apaga mientras se revisa la captura */}
      <CameraView enabled={!shot} compact onStatus={setStatus} onVideo={onVideo}>
        <div style={{ ...css('position:absolute;border:2px dashed rgba(255,255,255,.4);border-radius:18px;pointer-events:none'), inset: frameInset }} />
      </CameraView>
      {shot && <img src={shot} alt="Foto capturada" className="fade-in" style={css('position:absolute;inset:0;width:100%;height:100%;object-fit:contain;background:#1E1714')} />}
      {flash && <div style={css('position:absolute;inset:0;background:#FFFFFF;opacity:.7;animation:dmFade .18s reverse')} />}

      {!shot && status === 'live' && (
        <div style={css('position:absolute;left:0;right:0;bottom:18px;display:flex;flex-direction:column;align-items:center;gap:10px')}>
          <div style={css('font-size:15px;opacity:.9;text-shadow:0 1px 4px rgba(0,0,0,.5)')}>{hint}</div>
          <button type="button" onClick={capture} aria-label="Capturar"
            style={css('width:64px;height:64px;border-radius:50%;border:4px solid #FFFFFF;background:#7B6EF6;cursor:pointer;box-shadow:0 6px 18px rgba(0,0,0,.3)')} />
          <div style={css('font-size:12px;opacity:.8')}>Capturar</div>
        </div>
      )}
      {shot && (
        <div style={css('position:absolute;left:0;right:0;bottom:18px;display:flex;justify-content:center;gap:12px')}>
          <button type="button" onClick={() => setShot(null)}
            style={css('height:46px;padding:0 20px;border-radius:14px;border:1.5px solid rgba(255,255,255,.5);background:rgba(30,22,20,.5);backdrop-filter:blur(8px);color:#FFFFFF;font-size:15px;cursor:pointer;display:flex;gap:8px;align-items:center')}>
            <Retry size={16} />Repetir
          </button>
          <button type="button" onClick={() => onUse(shot)} className="hv-primary"
            style={css('height:46px;padding:0 22px;border-radius:14px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:15px;font-weight:600;cursor:pointer;display:flex;gap:8px;align-items:center')}>
            <Check size={16} />Usar foto
          </button>
        </div>
      )}
    </div>
  );
}
