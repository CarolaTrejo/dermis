import { css } from '../lib/css';
import type { CameraStatus } from './useCamera';
import { CameraOff, Retry, Camera } from '../components/Icons';

const COPY: Record<CameraStatus, { title: string; sub: string; retry: boolean; loading: boolean }> = {
  idle: { title: 'Preparando cámara…', sub: '', retry: false, loading: true },
  requesting: { title: 'Solicitando acceso a la cámara…', sub: 'Aceptá el permiso en la ventana de tu navegador.', retry: false, loading: true },
  live: { title: '', sub: '', retry: false, loading: false },
  denied: { title: 'No pudimos acceder a tu cámara.', sub: 'Habilitá el permiso desde el ícono de cámara en la barra de direcciones y volvé a intentarlo.', retry: true, loading: false },
  unavailable: { title: 'Este dispositivo no tiene una cámara disponible.', sub: 'Conectá una webcam y volvé a intentarlo.', retry: true, loading: false },
  insecure: { title: 'La cámara necesita una conexión segura.', sub: 'Abrí DERMIS desde localhost o con HTTPS para usar la cámara.', retry: true, loading: false },
  error: { title: 'Ocurrió un problema con la cámara.', sub: 'Podés volver a intentarlo en unos segundos.', retry: true, loading: false },
};

interface Props {
  status: CameraStatus;
  detail?: string;
  onRetry: () => void;
  compact?: boolean;
  fallbackAction?: { label: string; onClick: () => void };
}

/** Estados de permiso / error de la cámara, con fallback elegante (la app nunca se rompe). */
export function CameraPermissionState({ status, detail, onRetry, compact, fallbackAction }: Props) {
  const c = COPY[status];
  return (
    <div role="status" aria-live="polite" className="fade-in"
      style={css(`position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:${compact ? 10 : 16}px;color:#FFFFFF;text-align:center;padding:0 24px;background:radial-gradient(ellipse at center,#3A2E2A 0%,#2A211C 70%)`)}>
      <div style={css(`width:${compact ? 46 : 64}px;height:${compact ? 46 : 64}px;border-radius:50%;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);display:flex;align-items:center;justify-content:center;color:#C9C0FF`)}>
        {c.loading
          ? <span style={css(`width:${compact ? 20 : 26}px;height:${compact ? 20 : 26}px;border-radius:50%;border:3px solid rgba(255,255,255,.25);border-top-color:#9D92FF;animation:dmSpin .9s linear infinite`)} />
          : (status === 'insecure' ? <Camera size={compact ? 20 : 26} /> : <CameraOff size={compact ? 20 : 26} />)}
      </div>
      <div style={css(`font-size:${compact ? 16 : 24}px;font-weight:600;max-width:520px`)}>{c.title}</div>
      {(c.sub || detail) && <div style={css(`font-size:${compact ? 13 : 15.5}px;opacity:.75;max-width:460px;line-height:1.45`)}>{detail || c.sub}</div>}
      {(c.retry || fallbackAction) && (
        <div style={css('display:flex;gap:12px;margin-top:6px;flex-wrap:wrap;justify-content:center')}>
          {c.retry && (
            <button type="button" onClick={onRetry} className="hv-primary"
              style={css(`height:${compact ? 42 : 52}px;padding:0 ${compact ? 18 : 26}px;border-radius:14px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:${compact ? 14.5 : 16.5}px;font-weight:600;cursor:pointer;display:flex;gap:8px;align-items:center`)}>
              <Retry size={compact ? 16 : 18} />Intentar nuevamente
            </button>
          )}
          {fallbackAction && (
            <button type="button" onClick={fallbackAction.onClick}
              style={css(`height:${compact ? 42 : 52}px;padding:0 ${compact ? 16 : 22}px;border-radius:14px;border:1.5px solid rgba(255,255,255,.3);background:transparent;color:#FFFFFF;font-size:${compact ? 14.5 : 16}px;cursor:pointer`)}>
              {fallbackAction.label}
            </button>
          )}
        </div>
      )}
    </div>
  );
}
