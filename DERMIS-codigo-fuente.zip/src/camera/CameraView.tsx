import { useEffect, useRef, useState, type ReactNode } from 'react';
import { css } from '../lib/css';
import { useCamera, type CameraStatus } from './useCamera';
import { CameraPermissionState } from './CameraPermissionState';

interface Props {
  /** true = solicita la cámara al montar; false = la apaga. */
  enabled?: boolean;
  /** Modo espejo (la cámara frontal se ve como un espejo). Los overlays NO se espejan: se dibujan en coordenadas de pantalla. */
  mirrored?: boolean;
  /** Overlays que se dibujan encima del video (solo cuando la cámara está en vivo). */
  children?: ReactNode;
  compact?: boolean;
  onStatus?: (s: CameraStatus) => void;
  onVideo?: (v: HTMLVideoElement | null) => void;
  /** Acción secundaria en los estados de error (por ejemplo "Volver a los pasos"). */
  fallbackAction?: { label: string; onClick: () => void };
  /** Pausa la imagen (congela el video) sin apagar la cámara. */
  frozen?: boolean;
}

export function CameraView({ enabled = true, mirrored = true, children, compact, onStatus, onVideo, fallbackAction, frozen }: Props) {
  const { status, stream, detail, retry } = useCamera(enabled);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);

  const cbs = useRef({ onStatus, onVideo });
  cbs.current = { onStatus, onVideo };

  useEffect(() => { cbs.current.onStatus?.(status); }, [status]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    setPlaying(false);
    v.srcObject = stream;
    if (stream) v.play().catch(() => { /* autoplay bloqueado: se reintenta al interactuar */ });
    cbs.current.onVideo?.(stream ? v : null);
  }, [stream]);

  useEffect(() => {
    const v = videoRef.current;
    if (!v || !stream) return;
    if (frozen) v.pause(); else v.play().catch(() => {});
  }, [frozen, stream]);

  const live = status === 'live';
  return (
    <div style={css('position:absolute;inset:0;background:#2A211C;overflow:hidden')}>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        aria-label="Vista en vivo de tu cámara"
        onPlaying={() => setPlaying(true)}
        style={{
          ...css('position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;transition:opacity .5s ease'),
          transform: mirrored ? 'scaleX(-1)' : 'none',
          opacity: live && playing ? 1 : 0,
        }}
      />
      {live && playing && children}
      {(!live || !playing) && (
        <CameraPermissionState status={live ? 'idle' : status} detail={detail} onRetry={retry} compact={compact} fallbackAction={fallbackAction} />
      )}
    </div>
  );
}
