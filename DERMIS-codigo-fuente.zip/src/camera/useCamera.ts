import { useCallback, useEffect, useRef, useState } from 'react';

/**
 * Acceso REAL a la webcam con navigator.mediaDevices.getUserMedia().
 * Estados: idle → requesting → live | denied | unavailable | insecure | error.
 * Los MediaStream tracks se detienen siempre al desmontar el componente o al deshabilitar la cámara.
 */
export type CameraStatus = 'idle' | 'requesting' | 'live' | 'denied' | 'unavailable' | 'insecure' | 'error';

// Registro de streams activos (útil para verificar que la cámara se apaga al salir).
const activeStreams = new Set<MediaStream>();
declare global {
  interface Window { __dermisCamera?: { activeTracks: () => number } }
}
if (typeof window !== 'undefined') {
  window.__dermisCamera = {
    activeTracks: () => [...activeStreams].reduce((n, s) => n + s.getTracks().filter(t => t.readyState === 'live').length, 0),
  };
}

function stopStream(stream: MediaStream | null) {
  if (!stream) return;
  stream.getTracks().forEach(t => t.stop());
  activeStreams.delete(stream);
}

export function useCamera(enabled: boolean) {
  const [status, setStatus] = useState<CameraStatus>('idle');
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [detail, setDetail] = useState<string>('');
  const streamRef = useRef<MediaStream | null>(null);
  const requestId = useRef(0);

  const stop = useCallback(() => {
    requestId.current++;
    stopStream(streamRef.current);
    streamRef.current = null;
    setStream(null);
  }, []);

  const start = useCallback(async () => {
    stop();
    const id = ++requestId.current;
    if (!window.isSecureContext) { setStatus('insecure'); return; }
    if (!navigator.mediaDevices?.getUserMedia) { setStatus('unavailable'); return; }
    setStatus('requesting');
    setDetail('');
    try {
      const s = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      if (id !== requestId.current) { s.getTracks().forEach(t => t.stop()); return; } // se salió mientras se pedía permiso
      activeStreams.add(s);
      streamRef.current = s;
      s.getVideoTracks().forEach(t => t.addEventListener('ended', () => {
        if (streamRef.current === s) { setStatus('error'); setDetail('La cámara se desconectó.'); }
      }));
      setStream(s);
      setStatus('live');
    } catch (err) {
      if (id !== requestId.current) return;
      const name = (err as DOMException)?.name ?? '';
      if (name === 'NotAllowedError' || name === 'SecurityError' || name === 'PermissionDeniedError') setStatus('denied');
      else if (name === 'NotFoundError' || name === 'DevicesNotFoundError' || name === 'OverconstrainedError') setStatus('unavailable');
      else if (name === 'NotReadableError' || name === 'TrackStartError') { setStatus('error'); setDetail('Puede que otra aplicación esté usando la cámara.'); }
      else { setStatus('error'); setDetail((err as Error)?.message ?? ''); }
    }
  }, [stop]);

  useEffect(() => {
    if (enabled) void start();
    else { stop(); setStatus('idle'); }
    return () => stop();
  }, [enabled, start, stop]);

  return { status, stream, detail, retry: start, stop };
}
