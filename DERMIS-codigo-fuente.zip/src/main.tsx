import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import App from './App';
import { AppStoreProvider } from './state/AppStore';
import './styles/global.css';

// HashRouter (#/makeup, #/brows…) funciona en cualquier lugar: localhost, un hosting estático
// o abriendo el archivo único DERMIS.html directamente desde la computadora.
createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <HashRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
      <AppStoreProvider>
        <App />
      </AppStoreProvider>
    </HashRouter>
  </StrictMode>,
);
