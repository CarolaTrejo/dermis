import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { Stage } from './components/Stage';
import { SidebarLayout } from './components/Sidebar';
import { Toast } from './components/Toast';
import { ModulePage } from './pages/ModulePage';
import { SessionPage } from './pages/SessionPage';
import { TutorialPage } from './pages/TutorialPage';
import { CameraPage } from './pages/CameraPage';
import { ScanPage } from './pages/ScanPage';
import { ResultPage } from './pages/ResultPage';
import { CollectionPage } from './pages/CollectionPage';
import { LooksPage } from './pages/LooksPage';
import { AftercarePage } from './pages/AftercarePage';
import { OutfitPage } from './pages/OutfitPage';
import type { Mode } from './data/types';

const MODES: Mode[] = ['makeup', 'brows'];

export default function App() {
  const { pathname } = useLocation();
  const dark = /\/(scan|camera)/.test(pathname);
  return (
    <Stage dark={dark}>
      <Routes>
        <Route element={<SidebarLayout />}>
          <Route index element={<ModulePage kind="home" />} />
          <Route path="/makeup" element={<ModulePage kind="makeup" />} />
          <Route path="/makeup/new" element={<ModulePage kind="makeup" />} />
          <Route path="/makeup/outfit" element={<OutfitPage />} />
          <Route path="/brows" element={<ModulePage kind="brows" />} />
          <Route path="/brows/new" element={<ModulePage kind="brows" />} />
          <Route path="/collection" element={<CollectionPage />} />
          <Route path="/looks" element={<LooksPage />} />
          <Route path="/aftercare" element={<AftercarePage />} />
        </Route>
        {MODES.map(m => {
          const b = m === 'makeup' ? '/makeup' : '/brows';
          return [
            <Route key={m + 's'} path={`${b}/scan`} element={<ScanPage key={m} mode={m} />} />,
            <Route key={m + 'o'} path={`${b}/session`} element={<SessionPage key={m} mode={m} />} />,
            <Route key={m + 't'} path={`${b}/tutorial/:step`} element={<TutorialPage key={m} mode={m} />} />,
            <Route key={m + 'c'} path={`${b}/camera/:step`} element={<CameraPage key={m} mode={m} />} />,
            <Route key={m + 'r'} path={`${b}/result`} element={<ResultPage key={m} mode={m} />} />,
          ];
        })}
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
      <Toast />
    </Stage>
  );
}
