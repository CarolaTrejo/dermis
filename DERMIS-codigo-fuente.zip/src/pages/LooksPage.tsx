import { useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { css } from '../lib/css';
import { useStore } from '../state/AppStore';
import { stepsFor } from '../data/steps';
import { LookCard } from '../components/LookCard';
import { FilterChips } from '../components/FilterChips';
import { LookModal } from '../modals/LookModal';
import { routes } from '../lib/routes';
import type { SavedLook } from '../data/looks';
import type { Mode } from '../data/types';

const TABS = ['Todos', 'Favoritos', 'En curso', 'Cejas'];

export function LooksPage() {
  const navigate = useNavigate();
  const [params, setParams] = useSearchParams();
  const store = useStore();
  const tab = TABS.includes(params.get('tab') ?? '') ? params.get('tab')! : 'Todos';
  const [open, setOpen] = useState<{ look: SavedLook; tab: 'ver' | 'cmp' } | null>(null);

  const sessions = (['makeup', 'brows'] as Mode[]).filter(m => store.session(m).active).map(m => ({ mode: m, s: store.session(m), n: stepsFor(m).length }));
  const showSessions = tab === 'Todos' || tab === 'En curso' || (tab === 'Cejas' && sessions.some(x => x.mode === 'brows'));
  const looks = store.looks.filter(l => (tab === 'Todos') || (tab === 'Favoritos' && l.fav) || (tab === 'Cejas' && l.kind === 'brows'));
  const recreate = (l: SavedLook) => { store.startSession(l.kind, l.img, l.name); navigate(routes.scan(l.kind)); };

  return (
    <>
      <h1 style={css('margin:0;font-size:38px;font-weight:700;letter-spacing:-0.02em')}>Looks guardados</h1>
      <p style={css('margin:6px 0 0;font-size:16px;color:#7A7789')}>Tus maquillajes anteriores. Retomá una sesión, recreá un look o compará tu resultado.</p>
      <div style={css('margin-top:22px')}>
        <FilterChips options={TABS} value={tab} onChange={t => setParams(t === 'Todos' ? {} : { tab: t }, { replace: true })} label="Filtrar looks" activeBg="#F3F0FF" />
      </div>
      <div style={css('display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px;margin-top:20px')}>
        {showSessions && sessions.filter(x => tab !== 'Cejas' || x.mode === 'brows').map(({ mode, s, n }) => (
          <LookCard key={'session-' + mode} img={s.ref} refImg={s.ref} date="Hoy" name={s.refName || (mode === 'brows' ? 'Diseño de cejas' : 'Mi look')}
            badge={`En curso · Paso ${s.current + 1} de ${n}`} inProgress
            onOpen={() => navigate(routes.session(mode))} onResume={() => navigate(routes.session(mode))}
            onRemove={() => { store.endSession(mode); store.showToast('Sesión descartada'); }} />
        ))}
        {tab !== 'En curso' && looks.map(l => (
          <LookCard key={l.id} img={l.img} refImg={l.ref} date={l.date} name={l.name} badge={l.kind === 'brows' ? 'Cejas · Completo' : 'Completo'} inProgress={false}
            fav={l.fav} onFav={() => store.toggleLookFav(l.id)}
            onOpen={() => setOpen({ look: l, tab: 'ver' })} onCompare={() => setOpen({ look: l, tab: 'cmp' })} onRecreate={() => recreate(l)}
            onRemove={() => { store.removeLook(l.id); store.showToast(l.kind === 'brows' ? 'Diseño eliminado' : 'Look eliminado'); }} />
        ))}
      </div>
      {((tab === 'En curso' && sessions.length === 0) || (tab !== 'En curso' && looks.length === 0 && !(showSessions && sessions.length))) && (
        <div style={css('padding:36px;border:1.5px dashed #E1DBF5;border-radius:18px;color:#8A8798;font-size:15.5px;text-align:center;margin-top:4px')}>
          {tab === 'Favoritos' ? 'Todavía no marcaste looks como favoritos. Tocá el ♡ de un look para guardarlo acá.' : tab === 'En curso' ? 'No tenés sesiones en curso.' : 'Todavía no hay looks guardados.'}
        </div>
      )}
      {open && <LookModal look={open.look} tab={open.tab} onClose={() => setOpen(null)} />}
    </>
  );
}
