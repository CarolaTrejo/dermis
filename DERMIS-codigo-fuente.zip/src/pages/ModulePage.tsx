import { useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { css } from '../lib/css';
import { asset } from '../lib/assets';
import { Arrow, Camera, Chevron, Gallery, Check } from '../components/Icons';
import { HeartButton } from '../components/ProductCard';
import { ProgressBar } from '../components/ProgressBar';
import { ImageUploader, type ImagePickerHandle } from '../components/ImageUploader';
import { UploadReferenceModal } from '../modals/UploadReferenceModal';
import { LookModal } from '../modals/LookModal';
import { useStore } from '../state/AppStore';
import { stepsFor } from '../data/steps';
import { BROW_STYLES, type SavedLook } from '../data/looks';
import { routes } from '../lib/routes';
import type { Mode } from '../data/types';

type Kind = 'home' | 'makeup' | 'brows';

function greeting() {
  const h = new Date().getHours();
  return h < 13 ? 'Buenos días' : h < 20 ? 'Buenas tardes' : 'Buenas noches';
}

/** Home, Maquillaje y Diseño de cejas comparten esta estructura (diseño original). */
export function ModulePage({ kind }: { kind: Kind }) {
  const navigate = useNavigate();
  const { pathname, state } = useLocation();
  const [params] = useSearchParams();
  const store = useStore();
  const mode: Mode = kind === 'brows' ? 'brows' : 'makeup';
  const session = store.session(mode);
  const steps = stepsFor(mode);
  const picker = useRef<ImagePickerHandle>(null);
  const [lookOpen, setLookOpen] = useState<SavedLook | null>(null);

  const uploadOpen = pathname.endsWith('/new');
  const pick = (state as { pick?: string } | null)?.pick;

  const doneN = session.done.filter(Boolean).length;
  const brows = kind === 'brows';
  const mod = brows
    ? { title: 'Diseño de cejas', sub: 'Diseñá cejas que armonicen con tu rostro.', encTitle: 'Retomar diseño de cejas', newTitle: 'Nuevo diseño de cejas', emptyTitle: 'Empezá un nuevo diseño' }
    : kind === 'makeup'
      ? { title: 'Maquillaje', sub: 'Recreá un look de referencia adaptado a tu rostro.', encTitle: 'Retomar maquillaje', newTitle: 'Nuevo look', emptyTitle: 'Empezá un nuevo look' }
      : { title: `${greeting()}, Sofía`, sub: '¿Qué querés hacer hoy?', encTitle: 'Retomar maquillaje', newTitle: 'Nuevo look', emptyTitle: 'Empezá un nuevo look' };

  const makeupLooks = useMemo(() => store.looks.filter(l => l.kind === 'makeup').slice(0, 4), [store.looks]);
  const browLooks = useMemo(() => store.looks.filter(l => l.kind === 'brows').slice(0, 4), [store.looks]);
  const closeUpload = () => navigate(routes.module(mode), { replace: true });

  return (
    <>
      <ImageUploader ref={picker} onPick={url => navigate(routes.newRef(mode, 'gallery'), { state: { pick: url } })} onError={store.showToast} />
      <h1 style={css('margin:0;font-size:38px;font-weight:700;letter-spacing:-0.02em')}>{mod.title}</h1>
      <p style={css('margin:6px 0 0;font-size:16px;color:#7A7789')}>{mod.sub}</p>

      <div className="dm-module-actions" style={css('display:grid;grid-template-columns:1.5fr 1fr;gap:28px;margin-top:28px')}>
        {/* EN CURSO */}
        <section aria-label="Sesión en curso" style={css('background:#7B6EF6;border-radius:24px;padding:28px 30px;color:#FFFFFF;display:flex;flex-direction:column;height:270px;box-sizing:border-box;box-shadow:0 18px 40px rgba(123,110,246,.28)')}>
          {session.active ? (
            <>
              <div style={css('display:flex;gap:18px;align-items:center')}>
                <img src={session.ref} alt="Tu referencia" style={css('width:62px;height:62px;border-radius:14px;object-fit:cover;box-shadow:0 4px 12px rgba(0,0,0,.12)')} />
                <div><div style={css('font-size:12px;letter-spacing:.14em;opacity:.8;font-weight:500')}>EN CURSO</div><div style={css('font-size:27px;font-weight:700;margin-top:2px')}>{mod.encTitle}</div></div>
              </div>
              <div style={css('margin-top:auto;font-size:16px;opacity:.92')}>Paso {session.current + 1} de {steps.length} — {steps[session.current].name}</div>
              <ProgressBar value={Math.max(brows ? 8 : 6, (doneN / steps.length) * 100)} height={6} track="rgba(255,255,255,.3)" fill="#FFFFFF" label="Progreso de la sesión" style={{ marginTop: 12 }} />
              <button type="button" onClick={() => navigate(routes.session(mode))} className="hv-resume"
                style={css('align-self:flex-start;margin-top:20px;background:#FFFFFF;color:#6C5EF0;border:none;border-radius:14px;padding:13px 26px;font-size:17px;font-weight:600;cursor:pointer;display:flex;gap:8px;align-items:center')}>
                Retomar <Arrow />
              </button>
            </>
          ) : (
            <>
              <div><div style={css('font-size:12px;letter-spacing:.14em;opacity:.8;font-weight:500')}>SIN SESIÓN EN CURSO</div><div style={css('font-size:27px;font-weight:700;margin-top:2px')}>{mod.emptyTitle}</div></div>
              <div style={css('margin-top:auto;font-size:16px;opacity:.92')}>Elegí una referencia y DERMIS te guía paso a paso frente a tu cámara.</div>
              <button type="button" onClick={() => navigate(routes.newRef(mode))} className="hv-resume"
                style={css('align-self:flex-start;margin-top:20px;background:#FFFFFF;color:#6C5EF0;border:none;border-radius:14px;padding:13px 26px;font-size:17px;font-weight:600;cursor:pointer;display:flex;gap:8px;align-items:center')}>
                {mod.newTitle} <Arrow />
              </button>
            </>
          )}
        </section>

        {/* NUEVO */}
        <section aria-labelledby="new-title" style={css('background:#FFFFFF;border:1px solid #EEEAF7;border-radius:24px;padding:24px 26px;display:flex;flex-direction:column;gap:16px;height:270px;box-sizing:border-box')}>
          <div id="new-title" style={css('font-size:22px;font-weight:700')}>{mod.newTitle}</div>
          <button type="button" onClick={() => navigate(routes.newRef(mode))} className="hv-lav"
            style={css('flex:1;border:1.5px dashed #D9D3F5;border-radius:16px;background:#FCFBFF;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;cursor:pointer;color:#7A7789;font-size:15px')}>
            <div style={css('width:50px;height:50px;border-radius:50%;background:#F1EEFF;display:flex;align-items:center;justify-content:center;color:#7B6EF6')}><Camera size={22} /></div>
            Subí tu imagen de referencia
          </button>
          <div style={css('display:grid;grid-template-columns:1fr 1fr;gap:12px')}>
            <button type="button" onClick={() => picker.current?.open()} className="hv-lav"
              style={css('height:46px;border-radius:12px;border:1.5px solid #DCD6F7;background:#FFFFFF;color:#6C5EF0;font-size:15px;font-weight:500;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px')}><Gallery />Desde galería</button>
            <button type="button" onClick={() => navigate(routes.newRef(mode, 'camera'))} className="hv-lav"
              style={css('height:46px;border-radius:12px;border:1.5px solid #DCD6F7;background:#FFFFFF;color:#6C5EF0;font-size:15px;font-weight:500;cursor:pointer;display:flex;align-items:center;justify-content:center;gap:8px')}><Camera size={17} />Abrir cámara</button>
          </div>
        </section>
      </div>

      {kind === 'makeup' && (
        <div className="dm-outfit-banner" style={css('margin-top:28px;background:#F3F0FF;border:1px solid #E6E1FA;border-radius:22px;padding:22px 28px;display:flex;align-items:center;gap:28px')}>
          <div style={css('flex:1')}>
            <div style={css('font-size:12px;letter-spacing:.14em;color:#7B6EF6;font-weight:600')}>RECOMENDACIÓN POR OUTFIT</div>
            <div style={css('font-size:21px;font-weight:700;margin-top:6px')}>¿No sabés qué look hacer? Subí una foto de tu outfit</div>
            <div style={css('font-size:15px;color:#6F6C80;margin-top:4px')}>DERMIS te sugiere 3 looks compatibles con sus colores, su estilo y la ocasión.</div>
          </div>
          <div style={css('display:flex')} aria-hidden="true">
            <img src={asset('look2.jpg')} alt="" style={css('width:58px;height:58px;border-radius:50%;object-fit:cover;border:3px solid #F3F0FF')} />
            <img src={asset('look4.jpg')} alt="" style={css('width:58px;height:58px;border-radius:50%;object-fit:cover;border:3px solid #F3F0FF;margin-left:-14px')} />
            <img src={asset('look1.jpg')} alt="" style={css('width:58px;height:58px;border-radius:50%;object-fit:cover;border:3px solid #F3F0FF;margin-left:-14px')} />
          </div>
          <button type="button" onClick={() => navigate(routes.outfit)} className="hv-primary"
            style={css('height:50px;padding:0 24px;border-radius:14px;background:#7B6EF6;color:#FFFFFF;border:none;font-size:16px;font-weight:600;cursor:pointer;display:flex;gap:8px;align-items:center')}>Subir outfit <Arrow /></button>
        </div>
      )}

      {!brows && (
        <>
          <div style={css('display:flex;justify-content:space-between;align-items:baseline;margin-top:34px')}>
            <h2 style={css('margin:0;font-size:20px;font-weight:700')}>Tus looks recientes</h2>
            <button type="button" onClick={() => navigate(routes.looks)} className="hv-txt"
              style={css('background:none;border:none;color:#7B6EF6;font-size:16px;font-weight:500;cursor:pointer;display:flex;gap:6px;align-items:center')}>Ver todos <Arrow size={16} /></button>
          </div>
          <div className="dm-look-grid" style={css('display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px;margin-top:16px')}>
            {makeupLooks.map(l => (
              <div key={l.id} style={css('position:relative')}>
                <button type="button" onClick={() => setLookOpen(l)} aria-label={`Ver look ${l.name}`} style={css('display:block;width:100%;padding:0;border:none;background:none;cursor:pointer;border-radius:18px')}>
                  <img src={l.img} alt="" className="hv-img" style={css('width:100%;height:290px;object-fit:cover;border-radius:18px;display:block')} />
                </button>
                <HeartButton variant="bubble" on={l.fav} onToggle={() => store.toggleLookFav(l.id)} label={l.name} />
                <div style={css('font-size:14.5px;color:#8A8798;margin-top:10px')}>{l.date}</div>
              </div>
            ))}
            {makeupLooks.length === 0 && <EmptyNote text="Todavía no guardaste looks. Cuando termines uno, aparece acá." />}
          </div>
        </>
      )}

      {brows && (
        <>
          <div style={css('display:flex;justify-content:space-between;align-items:baseline;margin-top:34px')}>
            <h2 style={css('margin:0;font-size:20px;font-weight:700')}>Tus diseños recientes</h2>
            <button type="button" onClick={() => navigate(routes.looks + '?tab=Cejas')} className="hv-txt"
              style={css('background:none;border:none;color:#7B6EF6;font-size:16px;font-weight:500;cursor:pointer')}>Ver todos →</button>
          </div>
          <div className="dm-look-grid" style={css('display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:20px;margin-top:16px')}>
            {browLooks.map(b => (
              <div key={b.id} style={css('position:relative')}>
                <button type="button" onClick={() => setLookOpen(b)} aria-label={`Ver diseño ${b.name}`} style={css('display:block;width:100%;padding:0;border:none;background:none;cursor:pointer;text-align:left;color:inherit;font-size:inherit')}>
                  <img src={b.img} alt="" className="hv-img" style={css('width:100%;height:200px;object-fit:cover;border-radius:18px;display:block')} />
                  <div style={css('font-size:14px;color:#8A8798;margin-top:10px')}>{b.date}</div>
                  <div style={css('font-size:16.5px;margin-top:2px')}>{b.name}</div>
                </button>
                <HeartButton variant="bubble" on={b.fav} onToggle={() => store.toggleLookFav(b.id)} label={b.name} />
              </div>
            ))}
            {browLooks.length === 0 && <EmptyNote text="Todavía no guardaste diseños de cejas." />}
          </div>
          <h2 style={css('margin:34px 0 0;font-size:20px;font-weight:700')}>Explorá estilos de cejas</h2>
          <div className="dm-look-grid" style={css('display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px;margin-top:16px')}>
            {BROW_STYLES.map(s => {
              const current = session.active && session.refName === s.name;
              return (
                <button key={s.id} type="button" onClick={() => navigate(routes.newRef('brows') + `?style=${s.id}`)} className="hv-card" aria-label={`Elegir estilo ${s.name}`}
                  style={css(`position:relative;display:flex;align-items:center;gap:14px;padding:10px 16px 10px 10px;background:${current ? '#FCFBFF' : '#FFFFFF'};border:1.5px solid ${current ? '#B9AEFA' : '#E9E5F8'};border-radius:18px;cursor:pointer;text-align:left`)}>
                  <img src={s.img} alt="" style={css('width:66px;height:66px;border-radius:12px;object-fit:cover')} />
                  <div style={css('flex:1;min-width:0')}><div style={css('font-size:16.5px;color:#1D1B2C')}>{s.name}</div><div style={css('font-size:13px;color:#8A8798;margin-top:2px;line-height:1.35')}>{current ? 'Tu diseño en curso' : s.sub}</div></div>
                  {current ? <span style={css('width:24px;height:24px;border-radius:50%;background:#7B6EF6;color:#fff;display:flex;align-items:center;justify-content:center')}><Check size={13} strokeWidth={3} /></span> : <Chevron />}
                </button>
              );
            })}
          </div>
        </>
      )}

      <UploadReferenceModal mode={mode} open={uploadOpen} onClose={closeUpload}
        initialSource={params.get('source') === 'camera' ? 'camera' : 'gallery'} initialPick={pick} initialStyle={params.get('style') ?? undefined} />
      <LookModal look={lookOpen} onClose={() => setLookOpen(null)} />
    </>
  );
}

function EmptyNote({ text }: { text: string }) {
  return <div style={css('grid-column:1/-1;padding:28px;border:1.5px dashed #E1DBF5;border-radius:18px;color:#8A8798;font-size:15px;text-align:center')}>{text}</div>;
}

