import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { css } from '../lib/css';
import { captureFrame } from '../lib/image';
import { useStore } from '../state/AppStore';
import { CameraView } from '../camera/CameraView';
import type { CameraStatus } from '../camera/useCamera';
import { FaceGuide } from '../components/FaceGuide';
import { CameraTopBar, ReferencePreview } from '../components/CameraChrome';
import { Check } from '../components/Icons';
import { MOCK_FACE_ANALYSIS } from '../data/content';
import { routes } from '../lib/routes';
import type { Mode } from '../data/types';

type Stage = 'position' | 'analyzing' | 'done';
const PHASE_MS = 560; // 5 fases ≈ 2,8 s

/**
 * Escaneo inicial con la webcam REAL.
 * ⚠️ El "análisis" es una animación simulada con resultados de demostración (MOCK_FACE_ANALYSIS).
 * Sí se toma una captura real de la cámara para mostrar las zonas sobre TU rostro en "Recreando tu look".
 */
export function ScanPage({ mode }: { mode: Mode }) {
  const navigate = useNavigate();
  const store = useStore();
  const session = store.session(mode);
  const data = MOCK_FACE_ANALYSIS[mode];
  const [camStatus, setCamStatus] = useState<CameraStatus>('idle');
  const [stage, setStage] = useState<Stage>('position');
  const [phase, setPhase] = useState(0);
  const video = useRef<HTMLVideoElement | null>(null);
  const onVideo = useCallback((v: HTMLVideoElement | null) => { video.current = v; }, []);
  const live = camStatus === 'live';

  useEffect(() => {
    if (stage !== 'analyzing') return;
    const timers = [1, 2, 3, 4, 5].map(k => window.setTimeout(() => {
      setPhase(k);
      if (k === 2 && video.current) {
        const shot = captureFrame(video.current, { width: 960, height: 600, mirrored: store.prefs.mirror, quality: 0.8 });
        if (shot) store.setSnapshot(mode, shot);
      }
      if (k === 5) setStage('done');
    }, k * PHASE_MS));
    return () => timers.forEach(window.clearTimeout);
  }, [stage]); // eslint-disable-line react-hooks/exhaustive-deps

  // Si la cámara se cae durante el análisis, se vuelve al inicio del escaneo
  useEffect(() => { if (!live && stage === 'analyzing') { setStage('position'); setPhase(0); } }, [live, stage]);

  const start = () => { setPhase(0); setStage('analyzing'); };
  const items = data.items.map((label, j) => ({
    label, done: phase > j + 1, active: phase === j + 1 || (phase === 0 && j === 0), op: phase >= j + 1 || j === 0 ? 1 : 0.55,
  }));

  return (
    <div style={css('position:absolute;inset:0;background:#2A211C;overflow:hidden;color:#FFFFFF')}>
      <CameraView mirrored={store.prefs.mirror} onStatus={setCamStatus} onVideo={onVideo}
        fallbackAction={{ label: 'Continuar sin escanear', onClick: () => navigate(routes.session(mode)) }}>
        <FaceGuide showOval ovalOpacity={stage === 'done' ? 0.5 : 0.95} analysisPhase={stage === 'position' ? undefined : phase} label="Guía para posicionar tu rostro" />
        {stage === 'analyzing' && (
          <div style={css('position:absolute;left:0;right:0;top:0;height:160px;background:linear-gradient(to bottom,rgba(185,174,255,0),rgba(185,174,255,.22),rgba(185,174,255,0));animation:dmScan 2.6s linear infinite;pointer-events:none')} />
        )}
        {/* esquinas del encuadre */}
        {[['left:410px;top:112px', 'border-left', 'border-top', '10px 0 0 0'], ['right:410px;top:112px', 'border-right', 'border-top', '0 10px 0 0'],
          ['left:410px;top:690px', 'border-left', 'border-bottom', '0 0 0 10px'], ['right:410px;top:690px', 'border-right', 'border-bottom', '0 0 10px 0']].map(([pos, a, b, r]) => (
          <div key={pos} style={css(`position:absolute;${pos};width:36px;height:36px;${a}:2px solid rgba(255,255,255,.75);${b}:2px solid rgba(255,255,255,.75);border-radius:${r};pointer-events:none`)} />
        ))}
      </CameraView>

      <CameraTopBar onExit={() => navigate(routes.module(mode))} exitLabel="Salir del escaneo" topLabel="Análisis facial" pill={data.preparing} />
      <ReferencePreview src={session.ref} bottom={40} large={false} />

      {live && (
        <div key={stage} style={css('position:absolute;left:50%;bottom:40px;transform:translateX(-50%);width:600px;background:rgba(36,28,30,.55);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border:1px solid rgba(255,255,255,.18);border-radius:26px;padding:24px 28px;box-sizing:border-box;animation:dmPopCenter .4s ease-out')}>
          {stage === 'position' && (
            <div style={css('display:flex;justify-content:space-between;align-items:center;gap:20px')}>
              <div>
                <div style={css('font-size:24px;font-weight:600')}>Posicioná tu rostro dentro de la guía</div>
                <div style={css('font-size:15px;opacity:.8;margin-top:6px')}>Mirá de frente, con buena luz y el rostro despejado.</div>
              </div>
              <button type="button" onClick={start} autoFocus className="hv-primary"
                style={css('flex-shrink:0;height:56px;padding:0 24px;border-radius:16px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:17px;font-weight:600;cursor:pointer;box-shadow:0 8px 24px rgba(123,110,246,.45)')}>Escanear rostro</button>
            </div>
          )}
          {stage === 'analyzing' && (
            <div role="status" aria-live="polite">
              <div style={css('font-size:26px;font-weight:600')}>{data.title}</div>
              <div style={css('display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;margin-top:16px')}>
                {items.map(it => (
                  <div key={it.label} style={{ ...css('display:flex;gap:10px;align-items:center;font-size:16px;transition:opacity .3s'), opacity: it.op }}>
                    {it.done
                      ? <span style={css('width:22px;height:22px;border-radius:50%;background:#7B6EF6;display:flex;align-items:center;justify-content:center')}><Check size={13} strokeWidth={3} color="#fff" /></span>
                      : it.active
                        ? <span style={css('width:18px;height:18px;margin:2px;border-radius:50%;border:2.5px solid rgba(255,255,255,.3);border-top-color:#FFFFFF;animation:dmSpin .9s linear infinite')} />
                        : <span style={css('width:18px;height:18px;margin:2px;border-radius:50%;border:1.5px solid rgba(255,255,255,.4)')} />}
                    {it.label}
                  </div>
                ))}
              </div>
            </div>
          )}
          {stage === 'done' && (
            <div style={css('display:flex;justify-content:space-between;align-items:center;gap:20px')}>
              <div>
                <div style={css('font-size:26px;font-weight:600;display:flex;gap:10px;align-items:center')}>
                  <span style={css('width:28px;height:28px;border-radius:50%;background:#7B6EF6;display:flex;align-items:center;justify-content:center')}><Check size={16} strokeWidth={3} color="#fff" /></span>Análisis completado
                </div>
                <div style={css('display:flex;gap:8px;margin-top:12px;flex-wrap:wrap')}>
                  {data.results.map(r => (
                    <span key={r.label} style={css('background:rgba(255,255,255,.16);border-radius:12px;padding:5px 12px;font-size:14px')}><span style={css('opacity:.7')}>{r.label}:</span> {r.value}</span>
                  ))}
                </div>
                <div style={css('font-size:14px;opacity:.8;margin-top:10px')}>{data.features}</div>
                <div style={css('font-size:15px;opacity:.9;margin-top:4px')}>{data.line}</div>
                <div style={css('font-size:11.5px;opacity:.5;margin-top:8px')}>Perfil de demostración del prototipo</div>
              </div>
              <button type="button" onClick={() => navigate(routes.session(mode))} autoFocus className="hv-primary"
                style={css('flex-shrink:0;height:56px;padding:0 24px;border-radius:16px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:17px;font-weight:600;cursor:pointer;box-shadow:0 8px 24px rgba(123,110,246,.45)')}>Continuar →</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
