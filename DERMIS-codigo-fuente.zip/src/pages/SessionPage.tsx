import { Navigate, useNavigate } from 'react-router-dom';
import { css, clock } from '../lib/css';
import { useStore } from '../state/AppStore';
import { stepsFor } from '../data/steps';
import { useSessionClock } from '../state/useSessionClock';
import { StepSidebar } from '../components/StepSidebar';
import { FaceGuide } from '../components/FaceGuide';
import { Camera, Clock, Close, Play } from '../components/Icons';
import { ORIENT_VIEWBOX } from '../data/faceGuides';
import { ASSETS } from '../data/content';
import { routes } from '../lib/routes';
import type { Mode } from '../data/types';

/**
 * "Recreando tu look" / "Diseñando tus cejas" → responde "¿QUÉ tengo que hacer ahora?".
 * Breve y directo: paso actual, progreso, zonas y dos acciones (tutorial o cámara).
 */
export function SessionPage({ mode }: { mode: Mode }) {
  const navigate = useNavigate();
  const store = useStore();
  const session = store.session(mode);
  const steps = stepsFor(mode);
  useSessionClock(mode, session.active);
  if (!session.active) return <Navigate to={routes.module(mode)} replace />;

  const i = session.current;
  const cur = steps[i];
  const snapshot = store.snapshots[mode];
  const brows = mode === 'brows';

  return (
    <div className="fade-in" style={css('position:absolute;inset:0;background:#F7F6F9;padding:28px 40px;box-sizing:border-box')}>
      <header style={css('display:flex;justify-content:space-between;align-items:center;height:72px')}>
        <div style={css('display:flex;align-items:center;gap:18px')}>
          <img src={session.ref} alt="Tu referencia" style={css('width:64px;height:64px;border-radius:50%;object-fit:cover;border:3px solid #E9E4FF')} />
          <div>
            <h1 style={css('margin:0;font-size:24px;font-weight:600')}>{brows ? 'Diseñando tus cejas' : 'Recreando tu look'}</h1>
            <div style={css('font-size:17px;margin-top:2px;display:flex;gap:12px')}><span style={css('color:#7B6EF6;font-weight:500')}>Paso {i + 1} de {steps.length}</span><span style={css('color:#9A97A6')}>{cur.name}</span></div>
          </div>
        </div>
        <div style={css('display:flex;gap:12px;align-items:center')}>
          <div aria-label="Tiempo de la sesión" style={css('height:44px;padding:0 18px;border-radius:22px;border:1.5px solid #DCD6F7;color:#6C5EF0;display:flex;gap:8px;align-items:center;font-size:16px;font-variant-numeric:tabular-nums')}><Clock />{clock(session.elapsed)}</div>
          <button type="button" onClick={() => navigate(brows ? routes.module('brows') : routes.home)} className="hv-lav"
            style={css('height:44px;padding:0 18px;border-radius:22px;border:1.5px solid #E6E2F2;background:#FFFFFF;color:#4A475C;font-size:15px;cursor:pointer;display:flex;gap:6px;align-items:center')}><Close size={16} />Salir</button>
        </div>
      </header>

      <div style={css('display:grid;grid-template-columns:350px 1fr 360px;gap:30px;margin-top:26px;height:746px')}>
        <StepSidebar steps={steps} current={i} done={session.done} compact={!brows} onSelect={j => store.setCurrent(mode, j)} />

        <div style={css('border-radius:26px;overflow:hidden;background:#D9D2CC;position:relative')}>
          {/* Captura de TU cámara (tomada en el escaneo) o, si todavía no hay, la ilustración del diseño. Solo zonas del paso actual. */}
          <FaceGuide key={cur.id} type={cur.guide} mode="preview" viewBox={ORIENT_VIEWBOX}
            background={snapshot ? { kind: 'snapshot', href: snapshot } : { kind: 'illustration', href: ASSETS.illustrationFace }}
            label={`Zonas de ${cur.name.toLowerCase()} sobre el rostro`} style={{ animation: 'dmFade .4s ease-out' }} />
          <div style={css('position:absolute;left:18px;bottom:18px;background:rgba(255,255,255,.88);backdrop-filter:blur(8px);border-radius:14px;padding:8px 14px;font-size:14px;color:#4A475C;display:flex;gap:8px;align-items:center')}>
            <span style={css('width:8px;height:8px;border-radius:50%;background:#7B6EF6')} />{snapshot ? 'Zonas adaptadas a tu rostro' : 'Vista ilustrativa de las zonas'}
          </div>
        </div>

        <div key={cur.id} className="fade-in" style={css('background:#FCFBFE;border:1.5px solid #ECE8F6;border-radius:26px;padding:40px 32px 32px;display:flex;flex-direction:column')}>
          <h2 style={css('margin:0;font-size:48px;font-weight:700;letter-spacing:-0.02em;line-height:1.05')}>{cur.name}</h2>
          <p style={css('font-size:18px;color:#6F6C80;line-height:1.55;margin:20px 0 0;text-wrap:pretty')}>{cur.orient}</p>
          <div style={css('height:1px;background:#ECE8F6;margin:30px 0 22px')} />
          <div style={css('font-size:12.5px;letter-spacing:.12em;color:#9A97A6;font-weight:600')}>ZONAS MARCADAS</div>
          <div style={css('display:flex;flex-wrap:wrap;gap:8px;margin-top:12px')}>
            {cur.areas.map(a => <span key={a} style={css('background:#F1EEFF;color:#5A4CE0;border-radius:12px;padding:6px 12px;font-size:14.5px')}>{a}</span>)}
          </div>
          <div style={css('margin-top:auto;display:flex;flex-direction:column;gap:14px')}>
            <button type="button" onClick={() => navigate(routes.tutorial(mode, cur.id))} className="hv-primary"
              style={css('height:62px;border-radius:18px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:19px;font-weight:600;cursor:pointer;display:flex;gap:12px;align-items:center;justify-content:center;box-shadow:0 10px 24px rgba(123,110,246,.28)')}>
              <Play />{brows ? cur.how : 'Ver cómo aplicarlo'}
            </button>
            <button type="button" onClick={() => navigate(routes.camera(mode, cur.id))} className="hv-secondary"
              style={css('height:62px;border-radius:18px;border:1.5px solid #B9AEFA;background:#F3F0FF;color:#6C5EF0;font-size:19px;font-weight:600;cursor:pointer;display:flex;gap:12px;align-items:center;justify-content:center')}>
              <Camera size={22} />{brows ? 'Comenzar diseño' : 'Comenzar aplicación'}
            </button>
            <div style={css('font-size:13.5px;color:#9A97A6;text-align:center')}>La cámara te guía en tiempo real mientras aplicás.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
