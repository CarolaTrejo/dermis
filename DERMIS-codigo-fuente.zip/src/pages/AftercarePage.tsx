import { useState } from 'react';
import { css } from '../lib/css';
import { useStore } from '../state/AppStore';
import { AFTERCARE, type AftercareStep } from '../data/content';
import { Check } from '../components/Icons';
import { Modal, ModalHeader } from '../components/Modal';

export function AftercarePage() {
  const { routine, toggleRoutine, showToast } = useStore();
  const [info, setInfo] = useState<{ step: AftercareStep; n: number } | null>(null);
  const toggle = (j: number) => {
    toggleRoutine(j);
    if (!routine[j] && routine.filter(Boolean).length === AFTERCARE.length - 1) showToast('¡Rutina completa! Tu piel te lo agradece.');
  };

  return (
    <>
      <h1 style={css('margin:0;font-size:38px;font-weight:700;letter-spacing:-0.02em')}>Cuidado post-maquillaje</h1>
      <p style={css('margin:6px 0 0;font-size:16px;color:#7A7789')}>Cuidá tu piel después de cada look.</p>
      <h2 style={css('margin:32px 0 0;font-size:20px;font-weight:700')}>Rutina sugerida para esta noche</h2>
      <div className="dm-content-grid" style={css('display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:20px;margin-top:16px')}>
        {AFTERCARE.map((r, j) => {
          const done = routine[j];
          return (
            <div key={r.title} style={css(`background:#FFFFFF;border:1.5px solid ${done ? '#B9AEFA' : '#EEEAF7'};border-radius:22px;padding:24px;display:flex;flex-direction:column;gap:14px;transition:border-color .3s`)}>
              <div style={css('display:flex;justify-content:space-between;align-items:center')}>
                <div style={css('width:42px;height:42px;border-radius:50%;background:#F1EEFF;color:#6C5EF0;font-size:18px;font-weight:700;display:flex;align-items:center;justify-content:center')}>{j + 1}</div>
                <img src={r.img} alt={r.product} style={css('width:70px;height:70px;object-fit:contain')} />
              </div>
              <div style={css('font-size:22px;font-weight:700')}>{r.title}</div>
              <div style={css('font-size:15.5px;color:#6F6C80;line-height:1.5;min-height:70px')}>{r.text}</div>
              <div style={css('display:flex;justify-content:space-between;align-items:center;gap:8px')}>
                <div style={css('font-size:13.5px;color:#8A8798')}>{r.product}</div>
                <button type="button" onClick={() => setInfo({ step: r, n: j + 1 })} className="hv-txt"
                  style={css('background:none;border:none;color:#7B6EF6;font-size:14.5px;font-weight:500;cursor:pointer;white-space:nowrap;padding:0')}>Ver cómo →</button>
              </div>
              <button type="button" onClick={() => toggle(j)} aria-pressed={done} className={done ? 'hv-primary' : 'hv-lav'}
                style={css(`height:46px;border-radius:14px;border:1.5px solid ${done ? '#7B6EF6' : '#DCD6F7'};background:${done ? '#7B6EF6' : '#FFFFFF'};color:${done ? '#FFFFFF' : '#6C5EF0'};font-size:15px;font-weight:600;cursor:pointer;display:flex;gap:8px;align-items:center;justify-content:center`)}>
                <Check size={18} strokeWidth={2.2} />{done ? 'Hecho' : 'Marcar como hecho'}
              </button>
            </div>
          );
        })}
      </div>
      <div style={css('margin-top:24px;background:#F3F0FF;border:1px solid #E6E1FA;border-radius:22px;padding:24px 28px')}>
        <div style={css('display:flex;gap:10px;align-items:center;flex-wrap:wrap')}>
          <div style={css('font-size:18px;font-weight:700;margin-right:6px')}>Adaptado a tu piel</div>
          {['Piel seca', 'Subtono cálido', 'Último look: base + ojos intensos'].map(t => <span key={t} style={css('background:#FFFFFF;border-radius:12px;padding:5px 12px;font-size:13.5px;color:#6C5EF0')}>{t}</span>)}
        </div>
        <div className="dm-content-grid" style={css('display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:24px;margin-top:18px;font-size:15.5px;line-height:1.5;color:#3D3A4E')}>
          <div>Usá agua tibia: el agua muy caliente reseca más la piel.</div>
          <div>Aplicá la crema con la piel apenas húmeda para retener la hidratación.</div>
          <div>Retirá la sombra de los ojos con el disco apoyado unos segundos, sin frotar.</div>
        </div>
      </div>

      <Modal open={!!info} onClose={() => setInfo(null)} width={640} labelledBy="care-title">
        {info && (
          <>
            <ModalHeader id="care-title" title={`${info.n}. ${info.step.title}`} sub={info.step.product} onClose={() => setInfo(null)} />
            <div style={css('display:grid;grid-template-columns:140px 1fr;gap:24px;margin-top:22px;align-items:start')}>
              <img src={info.step.img} alt={info.step.product} style={css('width:140px;height:160px;object-fit:contain;background:#FCFBFE;border:1px solid #EEEAF7;border-radius:18px')} />
              <ol style={css('margin:0;padding:0;list-style:none;display:flex;flex-direction:column;gap:12px')}>
                {info.step.how.map((h, k) => (
                  <li key={k} style={css('display:flex;gap:12px;align-items:flex-start;font-size:16px;line-height:1.45;color:#2D2A3C')}>
                    <span style={css('width:26px;height:26px;border-radius:50%;background:#F1EEFF;color:#6C5EF0;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0')}>{k + 1}</span>{h}
                  </li>
                ))}
              </ol>
            </div>
            <div style={css('margin-top:20px;background:#F3F0FF;border-radius:16px;padding:14px 16px;font-size:15px;color:#3D3A4E;line-height:1.5')}><b style={css('color:#6C5EF0')}>Consejo para tu piel: </b>{info.step.tip}</div>
            <div style={css('display:flex;justify-content:flex-end;gap:12px;margin-top:20px')}>
              <button type="button" onClick={() => setInfo(null)} style={css('height:50px;padding:0 20px;border:none;background:none;color:#6F6C80;font-size:16px;cursor:pointer')}>Cerrar</button>
              <button type="button" onClick={() => { if (!routine[info.n - 1]) toggle(info.n - 1); setInfo(null); }} className="hv-primary"
                style={css('height:50px;padding:0 24px;border-radius:14px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:16px;font-weight:600;cursor:pointer')}>
                {routine[info.n - 1] ? 'Listo' : 'Marcar como hecho'}
              </button>
            </div>
          </>
        )}
      </Modal>
    </>
  );
}

