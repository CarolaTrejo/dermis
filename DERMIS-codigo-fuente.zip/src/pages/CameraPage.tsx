import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Navigate, useNavigate, useParams } from 'react-router-dom';
import { css } from '../lib/css';
import { captureFrame } from '../lib/image';
import { useStore } from '../state/AppStore';
import { stepsFor } from '../data/steps';
import { useSessionClock } from '../state/useSessionClock';
import { CameraView } from '../camera/CameraView';
import type { CameraStatus } from '../camera/useCamera';
import { FaceGuide } from '../components/FaceGuide';
import { FeedbackBubble } from '../components/FeedbackBubble';
import { CameraTopBar, ReferencePreview } from '../components/CameraChrome';
import { Compare, Pause, Play } from '../components/Icons';
import { FACE_GUIDES, toCameraPx, zoneCenter } from '../data/faceGuides';
import { useFeedbackSimulation, zoneStatuses } from '../analysis/useFeedbackSimulation';
import { routes } from '../lib/routes';
import type { FeedbackKind, Mode } from '../data/types';

const KIND: Record<FeedbackKind, [string, string]> = { add: ['Falta producto', '#FFC27A'], blend: ['Difuminá', '#C9C0FF'], ok: ['Listo', '#FFFFFF'] };

/**
 * Cámara / feedback → responde "¿LO ESTOY HACIENDO BIEN?".
 * Imagen principal = webcam REAL (espejada) + overlay SVG SOLO del paso actual.
 * El feedback es una simulación guionada (ver useFeedbackSimulation).
 */
export function CameraPage({ mode }: { mode: Mode }) {
  const { step: stepId } = useParams();
  const navigate = useNavigate();
  const store = useStore();
  const { prefs } = store;
  const session = store.session(mode);
  const steps = stepsFor(mode);
  const i = steps.findIndex(s => s.id === stepId);
  const cur = steps[Math.max(0, i)];
  const guide = FACE_GUIDES[cur.guide];
  const brows = mode === 'brows';

  const [camStatus, setCamStatus] = useState<CameraStatus>('idle');
  const [paused, setPaused] = useState(false);
  const [compare, setCompare] = useState(false);
  const [comparing, setComparing] = useState(false);
  const [success, setSuccess] = useState(false);
  const video = useRef<HTMLVideoElement | null>(null);
  const onVideo = useCallback((v: HTMLVideoElement | null) => { video.current = v; }, []);
  const live = camStatus === 'live';

  const sim = useFeedbackSimulation({ running: live, paused, stepKey: cur.id });
  const cs = sim.index;
  useSessionClock(mode, session.active && !paused && i >= 0);

  // El paso de la URL pasa a ser el paso actual de la sesión
  useEffect(() => {
    if (i >= 0 && session.current !== i) store.setCurrent(mode, i);
    setPaused(false); setCompare(false); setSuccess(false);
  }, [i]); // eslint-disable-line react-hooks/exhaustive-deps

  // Al completarse, primero se ve la última indicación y luego la tarjeta de éxito
  useEffect(() => {
    if (sim.phase !== 'complete') { setSuccess(false); return; }
    const t = window.setTimeout(() => setSuccess(true), 900);
    return () => window.clearTimeout(t);
  }, [sim.phase]);

  const statuses = useMemo(() => zoneStatuses(cur, guide.zones.length, cs, j => !!guide.zones[j].keep), [cur, guide, cs]);
  const remaining = session.done.filter((d, j) => !d && j !== i).length;
  const nextIdx = (() => {
    const done = [...session.done]; done[i] = true;
    let n = done.findIndex((d, j) => !d && j > i);
    if (n < 0) n = done.findIndex(d => !d);
    return n;
  })();
  const complete = sim.phase === 'complete';
  const canAnalyze = live && !paused && !sim.analyzing && !complete && cs > 0;

  const completeStep = () => {
    if (!complete) return;
    if (video.current) {
      const shot = captureFrame(video.current, { width: 960, height: 600, mirrored: prefs.mirror, quality: 0.8 });
      if (shot) store.setResult(mode, shot);
    }
    const n = store.completeStep(mode, i);
    if (n < 0) { navigate(routes.result(mode)); return; }
    store.showToast(`${cur.name} completado · Ahora: ${steps[n].name}`);
    navigate(routes.camera(mode, steps[n].id), { replace: true });
  };

  const toggleCompare = () => {
    if (!compare) {
      setComparing(true);
      window.setTimeout(() => setComparing(false), 1100);
    }
    setCompare(c => !c);
  };

  // Atajos de teclado para la presentación: Espacio = analizar · P = pausar · C = comparar · Enter = completar
  const keys = useRef({ canAnalyze, complete, reanalyze: sim.reanalyze, completeStep, toggleCompare });
  keys.current = { canAnalyze, complete, reanalyze: sim.reanalyze, completeStep, toggleCompare };
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.target as HTMLElement)?.tagName === 'BUTTON' && (e.key === ' ' || e.key === 'Enter')) return;
      const k = keys.current;
      if (e.key === ' ' && k.canAnalyze) { e.preventDefault(); k.reanalyze(); }
      else if (e.key.toLowerCase() === 'p') setPaused(p => !p);
      else if (e.key.toLowerCase() === 'c') k.toggleCompare();
      else if (e.key === 'Enter' && k.complete) k.completeStep();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  if (i < 0) return <Navigate to={routes.session(mode)} replace />;
  if (!session.active) return <Navigate to={routes.module(mode)} replace />;

  // Burbujas de feedback (posiciones calculadas desde el centro de cada zona, en coordenadas de pantalla)
  const msgs = live && cs > 0 && !paused && !success && !sim.analyzing ? cur.m[cs - 1] : [];
  const used: Record<'l' | 'r', number | null> = { l: null, r: null };
  const bubbles = msgs.map((g, j) => {
    const [ax, ay] = toCameraPx(...zoneCenter(guide.zones[g.z]));
    let top = Math.max(150, Math.min(g.s === 'r' ? 480 : 620, ay - 44));
    const prev = used[g.s];
    if (prev != null && Math.abs(prev - top) < 130) top = prev + 140;
    used[g.s] = top;
    const left = g.s === 'r' ? 1090 : 80;
    const att: [number, number] = g.s === 'r' ? [1090, top + 40] : [350, top + 40];
    const [label, color] = KIND[g.k];
    return { key: `${cur.id}-${cs}-${j}`, ax, ay, att, left, top, color, label: g.l ?? label, text: g.t };
  });

  const status: [string, string] = !live ? ['Esperando cámara', '#C9C0FF']
    : paused ? ['Análisis pausado', '#C9C0FF']
      : comparing ? ['Comparando con tu referencia…', '#C9C0FF']
        : sim.analyzing ? [cur.scanLabel, '#C9C0FF']
          : ([[cur.scanLabel, '#C9C0FF'], ['Falta producto', '#FFC27A'], [brows ? 'Revisá esta zona' : 'Difuminá esta zona', '#C9C0FF'], ['Paso completado', '#7EE0B0']] as [string, string][])[cs];
  const continueLabel = nextIdx < 0 || remaining === 0
    ? (brows ? 'Ver mis cejas terminadas →' : 'Ver mi look terminado →')
    : `Continuar con ${steps[nextIdx].name} →`;
  const pill = `Paso ${i + 1} de ${steps.length} — ${cur.name}`;

  return (
    <div style={css('position:absolute;inset:0;background:#2A211C;overflow:hidden;color:#FFFFFF')}>
      <CameraView mirrored={prefs.mirror} onStatus={setCamStatus} onVideo={onVideo} frozen={false}
        fallbackAction={{ label: 'Volver a los pasos', onClick: () => navigate(routes.session(mode)) }}>
        {/* Overlay del paso actual (no se espeja: está en coordenadas de pantalla, igual que el reflejo) */}
        <FaceGuide key={cur.id} type={cur.guide} mode="live" statuses={statuses} showOval={prefs.showOval} ovalOpacity={0.3}
          label={`Guía de ${cur.name.toLowerCase()} sobre tu rostro`} style={{ animation: 'dmFade .5s ease-out' }} />
        {sim.analyzing && !paused && (
          <div style={css('position:absolute;left:0;right:0;top:0;height:160px;background:linear-gradient(to bottom,rgba(185,174,255,0),rgba(185,174,255,.22),rgba(185,174,255,0));animation:dmScan 2.6s linear infinite;pointer-events:none')} />
        )}
        <svg width={1440} height={900} viewBox="0 0 1440 900" aria-hidden="true" style={css('position:absolute;inset:0;pointer-events:none')}>
          {bubbles.map(b => (
            <g key={b.key} style={{ animation: 'dmFade .5s ease-out' }}>
              <line x1={b.ax} y1={b.ay} x2={b.att[0]} y2={b.att[1]} stroke={b.color} strokeWidth={1.5} strokeDasharray="3 5" strokeOpacity={0.9} />
              <circle cx={b.ax} cy={b.ay} r={5.5} fill={b.color} />
              <circle cx={b.ax} cy={b.ay} r={11} fill="none" stroke={b.color} strokeOpacity={0.5} />
              <circle cx={b.att[0]} cy={b.att[1]} r={3.5} fill={b.color} />
            </g>
          ))}
        </svg>
        {bubbles.map(b => <FeedbackBubble key={b.key} left={b.left} top={b.top} color={b.color} label={b.label} text={b.text} />)}
        {cs === 0 && !paused && (
          <div className="fade-in" style={css('position:absolute;left:50%;top:150px;transform:translateX(-50%);background:rgba(30,22,20,.4);backdrop-filter:blur(10px);border-radius:14px;padding:8px 16px;font-size:15px;pointer-events:none')}>
            Alineá tu rostro con la guía y aplicá el producto
          </div>
        )}
      </CameraView>

      <CameraTopBar onExit={() => navigate(routes.session(mode))} exitLabel="Salir de la cámara" topLabel="Feedback en tiempo real" pill={pill}
        status={(
          <div style={css('display:flex;gap:8px;align-items:center;background:rgba(30,22,20,.4);backdrop-filter:blur(10px);border-radius:14px;padding:6px 14px;font-size:14px')}>
            <span style={{ ...css('width:8px;height:8px;border-radius:50%;animation:dmPulse 1.2s infinite'), background: status[1] }} />{status[0]}
          </div>
        )} />

      <ReferencePreview src={session.ref} bottom={128} large={compare} onToggle={toggleCompare} />

      {paused && (
        <div className="fade-in" style={css('position:absolute;inset:0;bottom:104px;background:rgba(30,22,20,.55);backdrop-filter:blur(6px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:18px;z-index:2')}>
          <div style={css('font-size:32px;font-weight:600')}>Análisis pausado</div>
          <div style={css('font-size:17px;opacity:.85')}>La cámara sigue encendida. Tu progreso está guardado.</div>
          <button type="button" onClick={() => setPaused(false)} className="hv-primary"
            style={css('height:54px;padding:0 30px;border-radius:16px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:17px;font-weight:600;cursor:pointer')}>Reanudar</button>
        </div>
      )}

      {success && !paused && (
        <div role="dialog" aria-label={cur.success}
          style={css('position:absolute;left:50%;bottom:128px;width:560px;background:rgba(255,255,255,.96);color:#1D1B2C;border-radius:28px;padding:28px 32px;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;text-align:center;box-shadow:0 24px 60px rgba(0,0,0,.25);animation:dmPopCenter .45s ease-out;transform:translateX(-50%);z-index:6')}>
          <div style={css('width:56px;height:56px;border-radius:50%;background:#7B6EF6;display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 8px #F1EEFF')}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5" /></svg>
          </div>
          <div style={css('font-size:28px;font-weight:700;margin-top:18px')}>{cur.success}</div>
          <div style={css('font-size:16px;color:#6F6C80;margin-top:6px')}>{pill}</div>
          <button type="button" onClick={completeStep} autoFocus className="hv-primary"
            style={css('margin-top:22px;height:58px;width:100%;border-radius:18px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:18px;font-weight:600;cursor:pointer;box-shadow:0 10px 24px rgba(123,110,246,.3)')}>{continueLabel}</button>
          <button type="button" onClick={() => { store.completeStep(mode, i); navigate(routes.session(mode)); }} className="hv-txt"
            style={css('margin-top:10px;height:36px;border:none;background:none;color:#6F6C80;font-size:15px;cursor:pointer')}>Volver a los pasos</button>
        </div>
      )}

      {/* Barra inferior */}
      <div style={css('position:absolute;left:0;right:0;bottom:0;height:104px;background:linear-gradient(to top,rgba(32,22,18,.82),rgba(32,22,18,.55));backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);display:grid;grid-template-columns:1fr auto 1fr;align-items:center;padding:0 56px;z-index:4')}>
        <div style={css('font-size:13px;opacity:.55')}>Espacio: analizar · P: pausar · C: comparar</div>
        <div style={css('display:flex;align-items:center;gap:44px')}>
          <button type="button" onClick={() => setPaused(p => !p)} disabled={!live} aria-pressed={paused}
            style={css(`background:none;border:none;color:#FFFFFF;font-size:17px;cursor:pointer;display:flex;gap:10px;align-items:center;width:120px;justify-content:flex-end;opacity:${live ? 1 : 0.4}`)}>
            {paused ? <Play size={20} /> : <Pause />}{paused ? 'Reanudar' : 'Pausar'}
          </button>
          <div style={css('display:flex;flex-direction:column;align-items:center;gap:6px')}>
            <button type="button" onClick={sim.reanalyze} disabled={!canAnalyze} aria-label="Volver a analizar"
              style={css(`width:66px;height:66px;border-radius:50%;border:none;background:#7B6EF6;cursor:pointer;display:flex;align-items:center;justify-content:center;animation:${canAnalyze ? 'dmGlow 2.4s ease-in-out infinite' : 'none'};opacity:${live && !complete ? 1 : 0.5}`)}>
              {sim.analyzing && live && !paused
                ? <span style={css('width:26px;height:26px;border-radius:50%;border:3px solid rgba(255,255,255,.35);border-top-color:#FFFFFF;animation:dmSpin .8s linear infinite')} />
                : <span style={css('width:22px;height:22px;border-radius:5px;background:#FFFFFF')} />}
            </button>
            <div style={css('font-size:12px;opacity:.75')}>{sim.analyzing && live && !paused ? 'Analizando…' : 'Volver a analizar'}</div>
          </div>
          <button type="button" onClick={toggleCompare} aria-pressed={compare}
            style={css(`background:none;border:none;color:${compare ? '#B3AAFF' : '#FFFFFF'};font-size:17px;cursor:pointer;display:flex;gap:10px;align-items:center;width:120px`)}>
            <Compare size={20} />Comparar
          </button>
        </div>
        <button type="button" onClick={completeStep} disabled={!complete} title={complete ? undefined : 'Se habilita cuando el paso está completo'} className="hv-white"
          style={css(`justify-self:end;background:none;border:none;color:#B3AAFF;font-size:18px;font-weight:600;cursor:pointer;opacity:${complete ? 1 : 0.4}`)}>Completar paso →</button>
      </div>
    </div>
  );
}
