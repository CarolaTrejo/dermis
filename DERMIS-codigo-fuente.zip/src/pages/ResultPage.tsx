import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { css, clock } from '../lib/css';
import { todayLabel } from '../lib/image';
import { useStore } from '../state/AppStore';
import { stepsFor } from '../data/steps';
import { FaceGuide } from '../components/FaceGuide';
import { Check } from '../components/Icons';
import { ASSETS } from '../data/content';
import { routes } from '../lib/routes';
import type { Mode } from '../data/types';

/** Resultado final: tu referencia vs. tu resultado (captura real de tu cámara al completar el último paso). */
export function ResultPage({ mode }: { mode: Mode }) {
  const navigate = useNavigate();
  const store = useStore();
  const session = store.session(mode);
  const steps = stepsFor(mode);
  const result = store.results[mode];
  const brows = mode === 'brows';
  const [saved, setSaved] = useState(false);

  // Al llegar al resultado, la sesión deja de estar "en curso"
  useEffect(() => { if (session.active && session.done.every(Boolean)) store.endSession(mode); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const save = () => {
    if (saved) return;
    store.addLook({
      id: 'u' + Date.now(), kind: mode, img: result ?? session.ref, ref: session.ref, date: todayLabel(),
      name: session.refName || (brows ? 'Nuevo diseño' : 'Nuevo look'), fav: false, minutes: Math.max(1, Math.round(session.elapsed / 60)),
    });
    setSaved(true);
    store.showToast(brows ? 'Diseño de cejas guardado' : 'Look guardado en tu galería');
  };

  return (
    <div className="fade-in" style={css('position:absolute;inset:0;background:#F7F6F9;display:flex;flex-direction:column;align-items:center;padding-top:44px;box-sizing:border-box')}>
      <div className="pop-in" style={css('width:60px;height:60px;border-radius:50%;background:#7B6EF6;display:flex;align-items:center;justify-content:center;box-shadow:0 0 0 10px #ECE8FF;color:#fff')}><Check size={30} /></div>
      <h1 style={css('margin:22px 0 0;font-size:40px;font-weight:700;letter-spacing:-0.02em')}>{brows ? '¡Tus cejas están listas!' : '¡Tu look está listo!'}</h1>
      <div style={css('font-size:17px;color:#6F6C80;margin-top:6px')}>Completaste los {steps.length} pasos en {clock(session.elapsed)}.</div>
      <div style={css('display:flex;gap:28px;margin-top:30px')}>
        <div><div style={css('font-size:15px;color:#6F6C80;margin-bottom:10px')}>Tu referencia</div><img src={session.ref} alt="Tu referencia" style={css('width:340px;height:440px;object-fit:cover;border-radius:24px;display:block')} /></div>
        <div>
          <div style={css('font-size:15px;color:#6F6C80;margin-bottom:10px')}>Tu resultado</div>
          <div style={css('width:340px;height:440px;border-radius:24px;overflow:hidden;background:#D9D2CC;position:relative')}>
            {result
              ? <img src={result} alt="Tu resultado (captura de tu cámara)" style={css('width:100%;height:100%;object-fit:cover;display:block')} />
              : <FaceGuide viewBox={brows ? '500 60 490 620' : '428 0 635 770'} background={{ kind: 'illustration', href: ASSETS.illustrationFace }}
                applied={steps.map(s => s.guide)} label="Resultado ilustrativo" />}
          </div>
        </div>
      </div>
      <div style={css('display:flex;gap:14px;margin-top:30px')}>
        <button type="button" onClick={save} disabled={saved} className="hv-primary"
          style={css(`height:58px;padding:0 32px;border-radius:18px;border:none;background:${saved ? '#9C8FF8' : '#7B6EF6'};color:#FFFFFF;font-size:18px;font-weight:600;cursor:pointer;box-shadow:0 10px 24px rgba(123,110,246,.28)`)}>
          {saved ? 'Guardado ✓' : brows ? 'Guardar diseño' : 'Guardar look'}
        </button>
        {saved && (
          <button type="button" onClick={() => navigate(brows ? routes.looks + '?tab=Cejas' : routes.looks)} className="hv-secondary"
            style={css('height:58px;padding:0 24px;border-radius:18px;border:1.5px solid #B9AEFA;background:#F3F0FF;color:#6C5EF0;font-size:18px;font-weight:600;cursor:pointer')}>Ver en mis looks</button>
        )}
        {!brows && (
          <button type="button" onClick={() => navigate(routes.aftercare)} className="hv-secondary"
            style={css('height:58px;padding:0 28px;border-radius:18px;border:1.5px solid #B9AEFA;background:#F3F0FF;color:#6C5EF0;font-size:18px;font-weight:600;cursor:pointer')}>Cuidado post-maquillaje</button>
        )}
        <button type="button" onClick={() => navigate(brows ? routes.module('brows') : routes.home)} className="hv-txt"
          style={css('height:58px;padding:0 20px;border:none;background:none;color:#6F6C80;font-size:17px;cursor:pointer')}>{brows ? 'Volver a cejas' : 'Volver al inicio'}</button>
      </div>
    </div>
  );
}
