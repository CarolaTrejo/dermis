import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { css } from '../lib/css';
import { useStore } from '../state/AppStore';
import { ArrowLeft, Gallery, Trash } from '../components/Icons';
import { ImageUploader, type ImagePickerHandle } from '../components/ImageUploader';
import { CameraCapture } from '../camera/CameraCapture';
import { OUTFIT_LOOKS } from '../data/looks';
import { routes } from '../lib/routes';

type Stage = 'upload' | 'camera' | 'analyzing' | 'results';

/** Recomendación por outfit. ⚠️ El análisis de colores/estilo es simulado (sugerencias predefinidas). */
export function OutfitPage() {
  const navigate = useNavigate();
  const store = useStore();
  const picker = useRef<ImagePickerHandle>(null);
  const [stage, setStage] = useState<Stage>('upload');
  const [photo, setPhoto] = useState<string | null>(null);
  const [sel, setSel] = useState<number | null>(null);

  useEffect(() => {
    if (stage !== 'analyzing') return;
    const t = window.setTimeout(() => setStage('results'), 2000);
    return () => window.clearTimeout(t);
  }, [stage]);

  const use = (url: string) => { setPhoto(url); setSel(null); setStage('analyzing'); };
  const reset = () => { setPhoto(null); setSel(null); setStage('upload'); };

  return (
    <>
      <ImageUploader ref={picker} onPick={use} onError={store.showToast} />
      <button type="button" onClick={() => navigate(routes.module('makeup'))} className="hv-txt"
        style={css('background:none;border:none;color:#7B6EF6;font-size:15px;cursor:pointer;padding:0;display:flex;gap:6px;align-items:center')}><ArrowLeft />Maquillaje</button>
      <h1 style={css('margin:10px 0 0;font-size:38px;font-weight:700;letter-spacing:-0.02em')}>Recomendación por outfit</h1>
      <p style={css('margin:6px 0 0;font-size:16px;color:#7A7789')}>Subí una foto de tu outfit y elegí un look compatible con sus colores, su estilo y la ocasión.</p>
      <div style={css('display:grid;grid-template-columns:320px 1fr;gap:28px;margin-top:28px')}>
        <div style={css('display:flex;flex-direction:column;gap:16px')}>
          {stage === 'camera' ? (
            <div style={css('margin-top:-18px')}>
              <CameraCapture height={420} hint="Mostrá tu outfit completo" outW={480} outH={640} frameInset="30px 30px" onUse={use} />
            </div>
          ) : (
            <div style={css('position:relative;height:420px;border-radius:22px;overflow:hidden;border:1.5px dashed #D3CCF3;background:repeating-linear-gradient(45deg,#F4F1FC 0 10px,#FBFAFE 10px 20px);display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px')}>
              {photo ? <img src={photo} alt="Foto de tu outfit" className="fade-in" style={css('position:absolute;inset:0;width:100%;height:100%;object-fit:cover')} /> : (
                <button type="button" onClick={() => picker.current?.open()} style={css('display:flex;flex-direction:column;align-items:center;gap:12px;background:none;border:none;cursor:pointer;color:#6F6C80;font-size:16px')}>
                  <span style={css('width:54px;height:54px;border-radius:50%;background:#F1EEFF;display:flex;align-items:center;justify-content:center;color:#7B6EF6')}><Gallery size={24} /></span>
                  Subí una foto de tu outfit
                </button>
              )}
              {stage === 'analyzing' && <div style={css('position:absolute;left:0;right:0;top:0;height:140px;background:linear-gradient(to bottom,rgba(123,110,246,0),rgba(123,110,246,.22),rgba(123,110,246,0));animation:dmScan 2.2s linear infinite')} />}
              {photo && stage === 'results' && (
                <button type="button" onClick={reset} aria-label="Eliminar foto del outfit" className="hv-del"
                  style={css('position:absolute;top:12px;right:12px;width:38px;height:38px;border-radius:50%;border:none;background:rgba(255,255,255,.94);color:#6F6C80;cursor:pointer;display:flex;align-items:center;justify-content:center')}><Trash size={17} /></button>
              )}
            </div>
          )}
          {(stage === 'upload' || stage === 'camera') && (
            <div style={css('display:grid;grid-template-columns:1fr 1fr;gap:12px')}>
              <button type="button" onClick={() => picker.current?.open()} className="hv-lav" style={css('height:46px;border-radius:12px;border:1.5px solid #DCD6F7;background:#FFFFFF;color:#6C5EF0;font-size:15px;cursor:pointer')}>Desde galería</button>
              <button type="button" onClick={() => setStage(stage === 'camera' ? 'upload' : 'camera')} className="hv-lav" style={css('height:46px;border-radius:12px;border:1.5px solid #DCD6F7;background:#FFFFFF;color:#6C5EF0;font-size:15px;cursor:pointer')}>{stage === 'camera' ? 'Cerrar cámara' : 'Abrir cámara'}</button>
            </div>
          )}
          {stage === 'results' && (
            <div className="fade-in" style={css('background:#FFFFFF;border:1px solid #EEEAF7;border-radius:18px;padding:16px 18px;display:flex;flex-direction:column;gap:12px;font-size:14.5px')}>
              <div style={css('display:flex;justify-content:space-between;align-items:center')}><span style={css('color:#8A8798')}>Colores</span><span style={css('display:flex;gap:6px')}>{['#B9A6E8', '#C9CBD3', '#E3C2AE'].map(c => <span key={c} style={{ ...css('width:20px;height:20px;border-radius:50%'), background: c }} />)}</span></div>
              <div style={css('display:flex;justify-content:space-between')}><span style={css('color:#8A8798')}>Estilo</span><span>Romántico elegante</span></div>
              <div style={css('display:flex;justify-content:space-between')}><span style={css('color:#8A8798')}>Ocasión</span><span>Evento de noche</span></div>
              <button type="button" onClick={reset} className="hv-txt" style={css('align-self:flex-start;background:none;border:none;color:#7B6EF6;font-size:14.5px;cursor:pointer;padding:0')}>Probar con otra foto</button>
            </div>
          )}
        </div>
        <div>
          {(stage === 'upload' || stage === 'camera') && (
            <div style={css('height:420px;border-radius:22px;background:#FFFFFF;border:1px solid #EEEAF7;display:flex;flex-direction:column;justify-content:center;padding:0 48px;gap:22px')}>
              <div style={css('font-size:22px;font-weight:700')}>DERMIS analiza tu outfit</div>
              <div style={css('display:flex;flex-direction:column;gap:14px;font-size:16px;color:#4A475C')}>
                {['Colores dominantes de la ropa y los accesorios', 'Estilo del conjunto', 'Ocasión probable'].map((t, j) => (
                  <div key={t} style={css('display:flex;gap:12px;align-items:center')}><span style={css('width:30px;height:30px;border-radius:50%;background:#F1EEFF;color:#6C5EF0;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:14px')}>{j + 1}</span>{t}</div>
                ))}
              </div>
            </div>
          )}
          {stage === 'analyzing' && (
            <div role="status" style={css('height:420px;border-radius:22px;background:#FFFFFF;border:1px solid #EEEAF7;display:flex;align-items:center;justify-content:center;gap:14px;font-size:18px;color:#4A475C')}>
              <span style={css('width:22px;height:22px;border-radius:50%;border:2.5px solid #E1DBFB;border-top-color:#7B6EF6;animation:dmSpin .9s linear infinite')} />Analizando colores y estilo…
            </div>
          )}
          {stage === 'results' && (
            <div className="fade-in">
              <h2 style={css('margin:0;font-size:20px;font-weight:700')}>3 looks para este outfit</h2>
              <div style={css('display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:18px;margin-top:14px')}>
                {OUTFIT_LOOKS.map((o, j) => (
                  <button key={o.name} type="button" onClick={() => setSel(j)} aria-pressed={sel === j}
                    style={css(`text-align:left;background:#FFFFFF;border:2px solid ${sel === j ? '#7B6EF6' : '#EEEAF7'};border-radius:20px;padding:8px 8px 14px;cursor:pointer;box-shadow:${sel === j ? '0 10px 28px rgba(123,110,246,.22)' : 'none'}`)}>
                    <img src={o.img} alt="" style={css('width:100%;height:270px;object-fit:cover;border-radius:14px;display:block')} />
                    <div style={css('padding:10px 6px 0')}>
                      <div style={css('font-size:17px;font-weight:700;color:#1D1B2C')}>{o.name}</div>
                      <div style={css('font-size:14px;color:#6F6C80;margin-top:4px;line-height:1.45')}>{o.why}</div>
                    </div>
                  </button>
                ))}
              </div>
              <div style={css('display:flex;justify-content:flex-end;margin-top:18px')}>
                <button type="button" disabled={sel == null} className="hv-primary"
                  onClick={() => { if (sel == null) return; store.startSession('makeup', OUTFIT_LOOKS[sel].img, OUTFIT_LOOKS[sel].name); navigate(routes.scan('makeup')); }}
                  style={css(`height:54px;padding:0 28px;border-radius:16px;border:none;background:${sel == null ? '#C9C2F5' : '#7B6EF6'};color:#FFFFFF;font-size:17px;font-weight:600;cursor:pointer`)}>Recrear este look →</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
