import { useEffect, useState } from 'react';
import { Navigate, useNavigate, useParams } from 'react-router-dom';
import { css, clock } from '../lib/css';
import { useStore } from '../state/AppStore';
import { stepsFor } from '../data/steps';
import { useSessionClock } from '../state/useSessionClock';
import { FaceGuide } from '../components/FaceGuide';
import { ProgressBar } from '../components/ProgressBar';
import { FilterChips } from '../components/FilterChips';
import { RecommendedProductCard } from '../components/ProductCard';
import { ArrowLeft, Clock } from '../components/Icons';
import { BROW_TOOLS } from '../data/products';
import { ASSETS } from '../data/content';
import { routes } from '../lib/routes';
import type { Mode } from '../data/types';

/** "Paso a paso" → responde "¿CÓMO lo hago?": imagen, 4 miniaturas, explicación, consejo y productos. */
export function TutorialPage({ mode }: { mode: Mode }) {
  const { step: stepId } = useParams();
  const navigate = useNavigate();
  const store = useStore();
  const session = store.session(mode);
  const steps = stepsFor(mode);
  const i = steps.findIndex(s => s.id === stepId);
  const [phase, setPhase] = useState(0);
  const [filter, setFilter] = useState('Todos');
  const [preparing, setPreparing] = useState(true);
  useSessionClock(mode, session.active && i >= 0);

  useEffect(() => {
    setPhase(0); setFilter('Todos'); setPreparing(true);
    const t = window.setTimeout(() => setPreparing(false), 650);
    return () => window.clearTimeout(t);
  }, [stepId]);
  useEffect(() => {
    if (i >= 0 && session.current !== i) store.setCurrent(mode, i);
  }, [i]); // eslint-disable-line react-hooks/exhaustive-deps

  if (i < 0) return <Navigate to={routes.session(mode)} replace />;
  const cur = steps[i];
  const brows = mode === 'brows';
  const real = !!cur.realTutorial;
  const mainImg = phase === 0 ? ASSETS.tutMain : ASSETS.tut[phase];

  const chipLabels = brows ? ['Todos', 'Depilación', 'Relleno', 'Fijación'] : ['Todos', 'Mate', 'Satinado', 'Jugoso'];
  const cards = brows
    ? BROW_TOOLS.filter(t => filter === 'Todos' || t.cat === filter).map(t => ({
      key: t.id, img: t.img, tag: t.cat, brand: t.brand, name: t.name, price: t.price, fav: !!store.toolFav[t.id], onFav: () => store.toggleToolFav(t.id),
    }))
    : store.products.filter(p => (p.cat === cur.cat || (p.ref != null && (cur.tools ?? []).includes(p.ref))) && (filter === 'Todos' || p.fin === filter)).slice(0, 5).map(p => ({
      key: p.id, img: p.img, tag: p.fin ?? 'Herramienta', brand: p.brand, name: p.name, price: p.price ?? '—', fav: p.fav, onFav: () => store.toggleProductFav(p.id),
    }));

  const next = () => (phase === 3 ? navigate(routes.camera(mode, cur.id)) : setPhase(phase + 1));

  return (
    <div className="dm-scroll fade-in" style={css('position:absolute;inset:0;background:#F7F6F9;padding:26px 56px 40px;box-sizing:border-box;overflow-y:auto')}>
      <header style={css('display:grid;grid-template-columns:1fr 560px 1fr;align-items:center')}>
        <button type="button" onClick={() => navigate(routes.session(mode))} className="hv-txt"
          style={css('justify-self:start;background:none;border:none;cursor:pointer;display:flex;gap:16px;align-items:center;font-size:26px;color:#1D1B2C;padding:0')}><ArrowLeft size={26} />Paso a paso</button>
        <div style={css('text-align:center')}>
          <div style={css('font-size:17px;color:#7B6EF6;font-weight:500')}>Paso {i + 1} de {steps.length}</div>
          <ProgressBar value={((i + 1) / steps.length) * 100} label={`Paso ${i + 1} de ${steps.length}`} style={{ marginTop: 10 }} />
        </div>
        <div aria-label="Tiempo de la sesión" style={css('justify-self:end;height:42px;padding:0 18px;border-radius:21px;border:1.5px solid #DCD6F7;color:#6C5EF0;display:flex;gap:8px;align-items:center;font-size:15px;font-variant-numeric:tabular-nums')}><Clock size={17} />{clock(session.elapsed)}</div>
      </header>

      <div style={css('display:grid;grid-template-columns:620px 1fr;gap:56px;margin-top:22px')}>
        <div>
          <div style={css('height:380px;border-radius:24px;overflow:hidden;background:#D9D2CC;position:relative')}>
            {real
              ? <img key={mainImg} src={mainImg} alt={`${cur.tt}: ${cur.ph[phase]}`} className="fade-in" style={css('width:100%;height:100%;object-fit:cover;display:block')} />
              : <FaceGuide key={phase} type={cur.guide} mode="tutorial" phase={phase} viewBox={cur.vb} background={{ kind: 'illustration', href: ASSETS.illustrationFace }}
                label={`${cur.tt}: ${cur.ph[phase]}`} style={{ animation: 'dmFade .35s ease-out' }} />}
            <div style={css('position:absolute;left:16px;top:16px;background:rgba(255,255,255,.9);border-radius:12px;padding:6px 12px;font-size:14.5px;font-weight:600;color:#5A4CE0')}>{phase + 1}. {cur.ph[phase]}</div>
            {preparing && (
              <div role="status" style={css('position:absolute;inset:0;background:rgba(247,246,249,.82);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;gap:12px;font-size:17px;color:#4A475C;animation:dmFade .2s ease-out')}>
                <span style={css('width:20px;height:20px;border-radius:50%;border:2.5px solid #E1DBFB;border-top-color:#7B6EF6;animation:dmSpin .9s linear infinite')} />Preparando tu tutorial…
              </div>
            )}
          </div>
          <div role="tablist" aria-label="Fases del tutorial" style={css('display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-top:14px')}>
            {cur.ph.map((label, j) => (
              <button key={j} type="button" role="tab" aria-selected={phase === j} onClick={() => setPhase(j)}
                style={css('background:none;border:none;padding:0;cursor:pointer;text-align:left')}>
                <div style={css(`height:100px;border-radius:14px;overflow:hidden;border:2.5px solid ${phase === j ? '#7B6EF6' : 'transparent'};background:#D9D2CC;box-sizing:border-box;position:relative;transition:border-color .2s`)}>
                  {real
                    ? <img src={ASSETS.tut[j]} alt="" style={css('width:100%;height:100%;object-fit:cover;display:block')} />
                    : <FaceGuide type={cur.guide} mode="tutorial" phase={j} viewBox={cur.vb} background={{ kind: 'illustration', href: ASSETS.illustrationFace }} />}
                </div>
                <div style={css(`font-size:14px;margin-top:7px;color:${phase === j ? '#6C5EF0' : '#6F6C80'};font-weight:500`)}>{j + 1}. {label}</div>
              </button>
            ))}
          </div>
        </div>
        <div style={css('padding-top:18px;display:flex;flex-direction:column')}>
          <h1 style={css('margin:0;font-size:26px;font-weight:700')}>{cur.tt}</h1>
          <p style={css('font-size:19px;line-height:1.6;margin:10px 0 0;color:#2D2A3C;text-wrap:pretty')}>{cur.tx}</p>
          <h2 style={css('margin:34px 0 0;font-size:24px;font-weight:700')}>{brows ? 'Tip' : 'Consejo para tu piel'}</h2>
          <p style={css('font-size:19px;line-height:1.6;margin:10px 0 0;color:#2D2A3C;text-wrap:pretty')}>{cur.tip}</p>
          <div style={css('display:flex;gap:16px;margin-top:34px')}>
            <button type="button" onClick={() => setPhase(Math.max(0, phase - 1))} disabled={phase === 0} className="hv-secondary"
              style={css(`height:56px;width:200px;border-radius:16px;border:1.5px solid #B9AEFA;background:#F3F0FF;color:#6C5EF0;font-size:18px;font-weight:600;cursor:pointer;opacity:${phase === 0 ? 0.45 : 1}`)}>Anterior</button>
            <button type="button" onClick={next} className="hv-primary"
              style={css('height:56px;min-width:200px;padding:0 26px;border-radius:16px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:18px;font-weight:600;cursor:pointer;box-shadow:0 10px 24px rgba(123,110,246,.25)')}>
              {phase === 3 ? (brows ? 'Comenzar diseño' : 'Comenzar aplicación') : 'Siguiente'}
            </button>
          </div>
        </div>
      </div>

      <h2 style={css('margin:30px 0 0;font-size:22px;font-weight:600')}>{brows ? 'Herramientas que podrías utilizar' : 'Tus productos que podrías utilizar'}</h2>
      <div style={css('margin-top:14px')}>
        <FilterChips options={chipLabels} value={filter} onChange={setFilter} label="Filtrar productos" />
      </div>
      <div style={css('display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:16px;margin-top:16px;min-height:136px')}>
        {cards.map(({ key, ...c }) => <RecommendedProductCard key={key} {...c} />)}
        {cards.length === 0 && (
          <div style={css('grid-column:1/-1;padding:24px;border:1.5px dashed #E1DBF5;border-radius:18px;color:#8A8798;font-size:15px;display:flex;justify-content:space-between;align-items:center')}>
            No tenés productos con este acabado para este paso.
            <button type="button" onClick={() => navigate(routes.collection)} className="hv-txt" style={css('background:none;border:none;color:#7B6EF6;font-size:15px;cursor:pointer')}>Agregar a mi colección →</button>
          </div>
        )}
      </div>
    </div>
  );
}
