import { useState } from 'react';
import { css } from '../lib/css';
import { useStore } from '../state/AppStore';
import { ProductCard } from '../components/ProductCard';
import { FilterChips } from '../components/FilterChips';
import { Filter, Plus, Search } from '../components/Icons';
import { COLLECTION_CATEGORIES } from '../data/products';
import { AddProductModal } from '../modals/AddProductModal';

export function CollectionPage() {
  const { products, toggleProductFav } = useStore();
  const [cat, setCat] = useState('Todos');
  const [search, setSearch] = useState('');
  const [favOnly, setFavOnly] = useState(false);
  const [adding, setAdding] = useState(false);

  const q = search.trim().toLowerCase();
  const items = products.filter(p => (cat === 'Todos' || p.cat === cat) && (!favOnly || p.fav) && (!q || `${p.name} ${p.brand}`.toLowerCase().includes(q)));

  return (
    <>
      <div className="dm-page-heading" style={css('display:flex;justify-content:space-between;align-items:flex-start')}>
        <div>
          <h1 style={css('margin:0;font-size:38px;font-weight:700;letter-spacing:-0.02em')}>Tu colección</h1>
          <p style={css('margin:6px 0 0;font-size:16px;color:#7A7789')}>Todos tus productos en un solo lugar. DERMIS los prioriza en tus recomendaciones.</p>
        </div>
        <div style={css('display:flex;gap:12px')}>
          <button type="button" onClick={() => setFavOnly(!favOnly)} aria-pressed={favOnly} className={favOnly ? undefined : 'hv-lav'}
            style={css(`height:48px;padding:0 20px;border-radius:14px;border:1.5px solid ${favOnly ? '#B9AEFA' : '#E6E2F2'};background:${favOnly ? '#F3F0FF' : '#FFFFFF'};color:#1D1B2C;font-size:16px;cursor:pointer;display:flex;gap:8px;align-items:center`)}>
            <Filter />{favOnly ? 'Favoritos' : 'Filtrar'}
          </button>
          <button type="button" onClick={() => setAdding(true)} className="hv-primary"
            style={css('height:48px;padding:0 22px;border-radius:14px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:16px;font-weight:600;cursor:pointer;display:flex;gap:8px;align-items:center;box-shadow:0 8px 20px rgba(123,110,246,.25)')}>
            <Plus />Agregar producto
          </button>
        </div>
      </div>
      <FilterChips variant="tabs" label="Categorías" options={COLLECTION_CATEGORIES} value={cat} onChange={setCat} />
      <label style={css('display:flex;align-items:center;gap:10px;margin-top:18px;height:48px;padding:0 16px;border:1px solid #E6E2F2;border-radius:14px;background:#FFFFFF;color:#A3A0B2')}>
        <Search />
        <span className="sr-only">Buscar en tu colección</span>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar en tu colección…" type="search"
          style={css('flex:1;border:none;outline:none;font-size:15.5px;color:#1D1B2C;background:transparent')} />
      </label>
      <div className="dm-content-grid" style={css('display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:14px;margin-top:18px')}>
        {items.map(p => <ProductCard key={p.id} img={p.img} name={p.name} brand={p.brand} cat={p.cat} fav={p.fav} isNew={p.isNew} onFav={() => toggleProductFav(p.id)} />)}
        <button type="button" onClick={() => setAdding(true)} className="hv-lav"
          style={css('border:1.5px dashed #D3CCF3;border-radius:18px;background:#FCFBFF;min-height:250px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;color:#7B6EF6;font-size:15px;cursor:pointer')}>
          <div style={css('width:46px;height:46px;border-radius:50%;border:1.5px solid #B9AEFA;display:flex;align-items:center;justify-content:center')}><Plus size={20} /></div>
          Agregar producto
        </button>
      </div>
      {items.length === 0 && (
        <p style={css('font-size:15px;color:#8A8798;margin-top:14px')}>No hay productos {favOnly ? 'favoritos ' : ''}{cat !== 'Todos' ? `en ${cat} ` : ''}{q ? `que coincidan con “${search}”` : ''}.</p>
      )}
      <AddProductModal open={adding} onClose={() => setAdding(false)} onAdded={() => { setCat('Todos'); setSearch(''); setFavOnly(false); }} />
    </>
  );
}

