import { useState, type ReactNode } from 'react';
import { css } from '../lib/css';
import { Close, Settings, Info } from './Icons';
import { useStore } from '../state/AppStore';

/** Barra superior de las pantallas de cámara: cerrar · DERMIS · píldora de paso · ajustes. */
export function CameraTopBar({ onExit, exitLabel, topLabel, pill, status }: {
  onExit: () => void; exitLabel: string; topLabel: string; pill: string; status?: ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const { prefs, setPrefs } = useStore();
  return (
    <>
      <button type="button" onClick={onExit} aria-label={exitLabel} className="hv-glass"
        style={css('position:absolute;left:32px;top:24px;width:46px;height:46px;border-radius:50%;background:rgba(30,22,20,.3);backdrop-filter:blur(10px);border:none;color:#FFFFFF;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:5')}><Close size={20} /></button>
      <div style={css('position:absolute;left:0;right:0;top:22px;display:flex;flex-direction:column;align-items:center;gap:10px;pointer-events:none;z-index:4')}>
        <div style={css('display:flex;gap:12px;align-items:center;font-size:14px;color:rgba(255,255,255,.85);text-shadow:0 1px 4px rgba(0,0,0,.35)')}>{topLabel}<span style={css('font-size:20px;font-weight:700;letter-spacing:.08em;color:#9D92FF')}>DERMIS</span></div>
        <div style={css('background:#FFFFFF;color:#6C5EF0;border-radius:16px;padding:6px 16px;font-size:14.5px;font-weight:600')}>{pill}</div>
        {status}
      </div>
      <button type="button" onClick={() => setOpen(o => !o)} aria-label="Ajustes de cámara" aria-expanded={open} className="hv-glass"
        style={css('position:absolute;right:32px;top:24px;width:46px;height:46px;border-radius:50%;background:rgba(30,22,20,.3);backdrop-filter:blur(10px);border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:5')}><Settings /></button>
      {open && (
        <div role="dialog" aria-label="Ajustes de cámara" className="pop-in"
          style={css('position:absolute;right:32px;top:82px;width:300px;background:rgba(255,255,255,.97);color:#1D1B2C;border-radius:20px;padding:18px;box-shadow:0 20px 50px rgba(0,0,0,.3);z-index:20;display:flex;flex-direction:column;gap:12px')}>
          <Toggle label="Modo espejo" sub="Ver la cámara reflejada" on={prefs.mirror} onChange={v => setPrefs({ mirror: v })} />
          <Toggle label="Guía del rostro" sub="Óvalo para alinear tu cara" on={prefs.showOval} onChange={v => setPrefs({ showOval: v })} />
          <div style={css('display:flex;gap:8px;font-size:12.5px;color:#6F6C80;line-height:1.45;border-top:1px solid #EEEAF7;padding-top:12px')}>
            <span style={css('color:#7B6EF6;margin-top:1px')}><Info size={14} /></span>
            Prototipo: la cámara es real; las guías se ubican de forma proporcional y las indicaciones son simuladas.
          </div>
        </div>
      )}
    </>
  );
}

function Toggle({ label, sub, on, onChange }: { label: string; sub: string; on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button type="button" role="switch" aria-checked={on} onClick={() => onChange(!on)}
      style={css('display:flex;justify-content:space-between;align-items:center;gap:12px;background:none;border:none;padding:0;cursor:pointer;text-align:left;color:#1D1B2C')}>
      <span><span style={css('display:block;font-size:15px;font-weight:600')}>{label}</span><span style={css('font-size:13px;color:#8A8798')}>{sub}</span></span>
      <span style={css(`width:44px;height:26px;border-radius:13px;background:${on ? '#7B6EF6' : '#DCD8E8'};position:relative;flex-shrink:0;transition:background .2s`)}>
        <span style={css(`position:absolute;top:3px;left:${on ? 21 : 3}px;width:20px;height:20px;border-radius:50%;background:#FFFFFF;transition:left .2s;box-shadow:0 1px 3px rgba(0,0,0,.2)`)} />
      </span>
    </button>
  );
}

/** Miniatura "Tu referencia" (se agranda al comparar). */
export function ReferencePreview({ src, bottom, large, onToggle }: { src: string; bottom: number; large: boolean; onToggle?: () => void }) {
  return (
    <div style={{ ...css('position:absolute;right:32px;display:flex;flex-direction:column;align-items:flex-start;gap:8px;z-index:3'), bottom }}>
      <div style={css('font-size:14px;font-weight:600;text-shadow:0 1px 4px rgba(0,0,0,.4);color:#FFFFFF')}>Tu referencia</div>
      <button type="button" onClick={onToggle} disabled={!onToggle} aria-label={large ? 'Achicar referencia' : 'Comparar con tu referencia'}
        style={css('padding:0;border:none;background:none;cursor:pointer;border-radius:16px')}>
        <img src={src} alt="Imagen de referencia"
          style={{ ...css('object-fit:cover;border-radius:16px;border:2px solid #FFFFFF;box-shadow:0 8px 24px rgba(0,0,0,.25);transition:width .35s,height .35s;display:block'), width: large ? 300 : 96, height: large ? 400 : 128 }} />
      </button>
    </div>
  );
}
