import { useEffect, useState, type ReactNode } from 'react';
import { css } from '../lib/css';

/**
 * Lienzo fijo de 1440×900 (el artboard del diseño original) escalado para ocupar la ventana.
 * Mantiene las proporciones exactas del diseño entre 1280 y 1920 px y nunca se rompe al reducir la ventana.
 */
export function Stage({ children, dark }: { children: ReactNode; dark?: boolean }) {
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () => {
      const w = window.innerWidth, h = window.innerHeight;
      if (w && h) setScale(Math.min(w / 1440, h / 900));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div style={{ ...css('position:fixed;inset:0;overflow:hidden;transition:background .4s'), background: dark ? '#1E1714' : '#ECEAF2' }}>
      <div
        data-screen-label="DERMIS"
        style={{
          ...css('position:absolute;left:50%;top:50%;width:1440px;height:900px;transform-origin:center;overflow:hidden;background:#F8F8FA;box-shadow:0 20px 60px rgba(40,30,80,.12)'),
          transform: `translate(-50%,-50%) scale(${scale})`,
        }}
      >
        {children}
      </div>
    </div>
  );
}
