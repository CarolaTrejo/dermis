import { useEffect, useState, type ReactNode } from 'react';
import { css } from '../lib/css';
import { useLocation } from 'react-router-dom';

/**
 * Lienzo fijo de 1440×900 (el artboard del diseño original) escalado para ocupar la ventana.
 * Mantiene las proporciones exactas del diseño entre 1280 y 1920 px y nunca se rompe al reducir la ventana.
 */
export function Stage({ children, dark }: { children: ReactNode; dark?: boolean }) {
  const { pathname } = useLocation();
  const canvas = /\/(scan|session|tutorial|camera|result)(\/|$)/.test(pathname);
  const [scale, setScale] = useState(1);
  useEffect(() => {
    const fit = () => {
      const w = window.innerWidth, h = window.innerHeight;
      if (w && h) setScale(Math.min(w / 1440, h / 900));
    };
    fit();
    window.addEventListener('resize', fit);
    return () => window.removeEventListener('resize', fit);
  }, []);
  return (
    <div style={{ ...css('position:fixed;inset:0;overflow:hidden;transition:background .4s'), background: dark ? '#1E1714' : '#ECEAF2' }}>
      <div
        data-screen-label="DERMIS"
        style={{
          ...css('position:absolute;inset:0;overflow:hidden;background:#F8F8FA;transform-origin:top left'),
          width: canvas ? 1440 : '100%',
          height: canvas ? 900 : '100%',
          left: canvas ? '50%' : 0,
          top: canvas ? '50%' : 0,
          transformOrigin: canvas ? 'center' : undefined,
          transform: canvas ? `translate(-50%,-50%) scale(${scale})` : undefined,
        }}
      >
        {children}
      </div>
    </div>
  );
}
