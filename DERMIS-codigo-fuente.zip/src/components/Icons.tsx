/** Íconos SVG del diseño original (trazos idénticos). */
type P = { size?: number; color?: string; fill?: string; strokeWidth?: number };

const base = (size: number, sw: number, color = 'currentColor', fill = 'none') => ({
  width: size, height: size, viewBox: '0 0 24 24', fill, stroke: color, strokeWidth: sw, 'aria-hidden': true as const,
});

export const Sparkle = ({ size = 18 }: P) => <svg {...base(size, 1.8)} strokeLinejoin="round"><path d="M12 4l1.8 4.2L18 10l-4.2 1.8L12 16l-1.8-4.2L6 10l4.2-1.8z" /></svg>;
export const Arrow = ({ size = 18, strokeWidth = 2 }: P) => <svg {...base(size, strokeWidth)} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14M13 6l6 6-6 6" /></svg>;
export const ArrowLeft = ({ size = 16, strokeWidth = 2 }: P) => <svg {...base(size, strokeWidth)} strokeLinecap="round" strokeLinejoin="round"><path d="M19 12H5M11 6l-6 6 6 6" /></svg>;
export const Camera = ({ size = 18, strokeWidth = 1.8 }: P) => <svg {...base(size, strokeWidth)} strokeLinejoin="round"><path d="M4 8h3l2-2h6l2 2h3v11H4z" /><circle cx="12" cy="13" r="3.5" /></svg>;
export const Gallery = ({ size = 17 }: P) => <svg {...base(size, 1.8)}><rect x="4" y="5" width="16" height="14" rx="2" /><circle cx="9" cy="10" r="1.5" /><path d="M4 17l5-5 4 4 3-3 4 4" /></svg>;
export const Heart = ({ size = 18, fill = 'none' }: P) => <svg {...base(size, 1.8, 'currentColor', fill)} strokeLinejoin="round"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z" /></svg>;
export const Filter = ({ size = 18 }: P) => <svg {...base(size, 1.8)} strokeLinejoin="round"><path d="M4 5h16l-6 8v6l-4-2v-4z" /></svg>;
export const Plus = ({ size = 18 }: P) => <svg {...base(size, 2)} strokeLinecap="round"><path d="M12 5v14M5 12h14" /></svg>;
export const Search = ({ size = 18 }: P) => <svg {...base(size, 1.8)} strokeLinecap="round"><circle cx="11" cy="11" r="6" /><path d="M20 20l-4.5-4.5" /></svg>;
export const Check = ({ size = 16, strokeWidth = 2.6, color = 'currentColor' }: P) => <svg {...base(size, strokeWidth, color)} strokeLinecap="round" strokeLinejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5" /></svg>;
export const Close = ({ size = 18 }: P) => <svg {...base(size, 2)} strokeLinecap="round"><path d="M6 6l12 12M18 6L6 18" /></svg>;
export const Clock = ({ size = 18 }: P) => <svg {...base(size, 1.8)} strokeLinecap="round"><circle cx="12" cy="13" r="7" /><path d="M12 9v4l2 2M10 3h4" /></svg>;
export const Play = ({ size = 22 }: P) => <svg {...base(size, 1.8)} strokeLinejoin="round"><path d="M8 5l11 7-11 7z" /></svg>;
export const Pause = ({ size = 20 }: P) => <svg {...base(size, 1.8)} strokeLinecap="round"><path d="M9 6v12M15 6v12" /></svg>;
export const Compare = ({ size = 18 }: P) => <svg {...base(size, 1.8)}><path d="M12 3v18" /><rect x="4" y="6" width="5" height="12" rx="1" /><rect x="15" y="6" width="5" height="12" rx="1" strokeDasharray="2 2" /></svg>;
export const Trash = ({ size = 18 }: P) => <svg {...base(size, 1.8)} strokeLinecap="round" strokeLinejoin="round"><path d="M5 7h14M9 7V5h6v2M7 7l1 12h8l1-12" /></svg>;
export const Chevron = ({ size = 18, color = '#7B6EF6' }: P) => <svg {...base(size, 2, color)} strokeLinecap="round" strokeLinejoin="round"><path d="M9 6l6 6-6 6" /></svg>;
export const Settings = ({ size = 20 }: P) => <svg {...base(size, 1.8, '#FFFFFF')} strokeLinecap="round"><circle cx="12" cy="12" r="3" /><circle cx="12" cy="12" r="7.5" strokeDasharray="3 2.2" /></svg>;
export const CameraOff = ({ size = 26 }: P) => <svg {...base(size, 1.8)} strokeLinecap="round" strokeLinejoin="round"><path d="M4 8h3l2-2h6l2 2h3v11H4z" /><circle cx="12" cy="13" r="3.5" /><path d="M3 3l18 18" /></svg>;
export const Retry = ({ size = 18 }: P) => <svg {...base(size, 2)} strokeLinecap="round" strokeLinejoin="round"><path d="M4 12a8 8 0 0 1 14-5.3M20 4v5h-5M20 12a8 8 0 0 1-14 5.3M4 20v-5h5" /></svg>;
export const Pencil = ({ size = 22 }: P) => <svg {...base(size, 1.8)} strokeLinecap="round" strokeLinejoin="round"><path d="M4 20h4L19 9l-4-4L4 16z" /><path d="M13.5 6.5l4 4" /></svg>;
export const Info = ({ size = 14 }: P) => <svg {...base(size, 1.8)} strokeLinecap="round"><circle cx="12" cy="12" r="8.5" /><path d="M12 11v5M12 8h.01" /></svg>;
