import { css } from '../lib/css';

interface Props {
  options: string[];
  value: string;
  onChange: (v: string) => void;
  /** pill = chips redondeados (tutorial/looks) · tabs = pestañas subrayadas (colección) · small = chips de formulario */
  variant?: 'pill' | 'tabs' | 'small';
  label: string;
  activeBg?: string;
}

export function FilterChips({ options, value, onChange, variant = 'pill', label, activeBg = '#F1EEFF' }: Props) {
  if (variant === 'tabs') {
    return (
      <div role="tablist" aria-label={label} style={css('display:flex;gap:4px;margin-top:24px;border-bottom:1px solid #ECE9F4;overflow-x:auto;scrollbar-width:none')}>
        {options.map(o => {
          const on = o === value;
          return (
            <button key={o} type="button" role="tab" aria-selected={on} onClick={() => onChange(o)} className="hv-txt"
              style={css(`padding:10px 14px 12px;background:none;border:none;border-bottom:2.5px solid ${on ? '#7B6EF6' : 'transparent'};color:${on ? '#6C5EF0' : '#6F6C80'};font-size:15.5px;cursor:pointer;white-space:nowrap;margin-bottom:-1px`)}>
              {o}
            </button>
          );
        })}
      </div>
    );
  }
  const small = variant === 'small';
  return (
    <div role="group" aria-label={label} style={css(`display:flex;flex-wrap:wrap;gap:${small ? 8 : 10}px`)}>
      {options.map(o => {
        const on = o === value;
        return (
          <button key={o} type="button" aria-pressed={on} onClick={() => onChange(o)}
            style={css(`height:${small ? 34 : 38}px;padding:0 ${small ? 14 : 18}px;border-radius:${small ? 17 : 19}px;border:1.5px solid ${on ? '#B9AEFA' : '#E6E2F2'};background:${on ? activeBg : '#FFFFFF'};color:${on ? '#6C5EF0' : small ? '#6F6C80' : '#8A8798'};font-size:${small ? 14 : 14.5}px;cursor:pointer`)}>
            {o}
          </button>
        );
      })}
    </div>
  );
}
