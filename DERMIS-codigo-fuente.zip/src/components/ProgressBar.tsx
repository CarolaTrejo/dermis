import type { CSSProperties } from 'react';
import { css } from '../lib/css';

interface Props { value: number; height?: number; track?: string; fill?: string; label?: string; style?: CSSProperties }

/** Barra de progreso con transición suave. value: 0–100 */
export function ProgressBar({ value, height = 7, track = '#ECE8FA', fill = '#7B6EF6', label, style }: Props) {
  const v = Math.max(0, Math.min(100, value));
  return (
    <div role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(v)} aria-label={label}
      style={{ ...css(`height:${height}px;border-radius:${height}px;background:${track};overflow:hidden`), ...style }}>
      <div style={{ ...css(`height:100%;background:${fill};border-radius:${height}px;transition:width .6s cubic-bezier(.2,.8,.2,1)`), width: v + '%' }} />
    </div>
  );
}
