import { useEffect, useRef, type ReactNode } from 'react';
import { css } from '../lib/css';
import { Close } from './Icons';

interface Props {
  open: boolean;
  onClose: () => void;
  width?: number;
  labelledBy?: string;
  children: ReactNode;
}

/** Modal accesible: Escape y clic afuera cierran, foco inicial dentro del diálogo. */
export function Modal({ open, onClose, width = 820, labelledBy, children }: Props) {
  const box = useRef<HTMLDivElement>(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeRef.current(); };
    window.addEventListener('keydown', onKey);
    const t = window.setTimeout(() => box.current?.focus(), 30);
    return () => { window.removeEventListener('keydown', onKey); window.clearTimeout(t); prev?.focus?.(); };
  }, [open]);

  if (!open) return null;
  return (
    <div onClick={onClose} style={css('position:absolute;inset:0;background:rgba(29,27,44,.38);backdrop-filter:blur(4px);display:flex;align-items:center;justify-content:center;z-index:50;animation:dmFade .2s ease-out')}>
      <div ref={box} role="dialog" aria-modal="true" aria-labelledby={labelledBy} tabIndex={-1} onClick={e => e.stopPropagation()}
        style={{ ...css('background:#FFFFFF;border-radius:28px;padding:32px;box-sizing:border-box;box-shadow:0 30px 80px rgba(40,30,80,.25);animation:dmPop .3s ease-out;max-height:860px;overflow-y:auto'), width }}>
        {children}
      </div>
    </div>
  );
}

export function ModalHeader({ id, title, sub, onClose, right }: { id?: string; title: ReactNode; sub?: ReactNode; onClose: () => void; right?: ReactNode }) {
  return (
    <div style={css('display:flex;justify-content:space-between;align-items:flex-start;gap:16px')}>
      <div>
        <div id={id} style={css('font-size:26px;font-weight:700')}>{title}</div>
        {sub && <div style={css('font-size:15.5px;color:#7A7789;margin-top:4px')}>{sub}</div>}
      </div>
      <div style={css('display:flex;gap:12px;align-items:center')}>
        {right}
        <CloseButton onClick={onClose} />
      </div>
    </div>
  );
}

export function CloseButton({ onClick, label = 'Cerrar' }: { onClick: () => void; label?: string }) {
  return (
    <button type="button" onClick={onClick} aria-label={label} className="hv-soft"
      style={css('width:40px;height:40px;border-radius:50%;border:none;background:#F4F2F9;cursor:pointer;color:#4A475C;display:flex;align-items:center;justify-content:center;flex-shrink:0')}>
      <Close />
    </button>
  );
}
