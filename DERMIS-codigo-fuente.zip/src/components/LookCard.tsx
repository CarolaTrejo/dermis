import { css } from '../lib/css';
import { HeartButton } from './ProductCard';
import { Compare, Trash } from './Icons';

interface Props {
  img: string; refImg: string; date: string; name: string;
  badge: string; inProgress: boolean; fav?: boolean;
  onOpen: () => void; onFav?: () => void; onResume?: () => void; onRecreate?: () => void; onCompare?: () => void; onRemove: () => void;
}

/** Card de "Looks guardados": Ver · Recrear · Comparar · Favorito · Eliminar (o Retomar si está en curso). */
export function LookCard(p: Props) {
  return (
    <div className="pop-in" style={css('background:#FFFFFF;border:1px solid #EEEAF7;border-radius:22px;padding:10px 10px 14px')}>
      <div style={css('position:relative;height:280px;border-radius:16px;overflow:hidden')}>
        <button type="button" onClick={p.onOpen} aria-label={`${p.inProgress ? 'Retomar' : 'Ver'} ${p.name}`} style={css('position:absolute;inset:0;padding:0;border:none;background:none;cursor:pointer')}>
          <img src={p.img} alt="" className="hv-img" style={css('width:100%;height:100%;object-fit:cover;display:block')} />
        </button>
        <div style={css(`position:absolute;top:12px;left:12px;background:${p.inProgress ? '#7B6EF6' : 'rgba(255,255,255,.92)'};color:${p.inProgress ? '#FFFFFF' : '#4A475C'};font-size:12.5px;font-weight:600;border-radius:10px;padding:5px 10px;pointer-events:none`)}>{p.badge}</div>
        {p.onFav && <HeartButton variant="bubble" on={!!p.fav} onToggle={p.onFav} label={p.name} />}
        <div style={css('position:absolute;left:10px;bottom:10px;display:flex;flex-direction:column;align-items:center;gap:3px;pointer-events:none')}>
          <img src={p.refImg} alt="" style={css('width:52px;height:66px;object-fit:cover;border-radius:10px;border:2px solid #FFFFFF;box-shadow:0 4px 10px rgba(0,0,0,.18)')} />
          <span style={css('font-size:11px;color:#FFFFFF;font-weight:600;text-shadow:0 1px 4px rgba(0,0,0,.5)')}>Referencia</span>
        </div>
      </div>
      <div style={css('padding:12px 6px 0')}>
        <div style={css('font-size:13.5px;color:#8A8798')}>{p.date}</div>
        <div style={css('font-size:17px;font-weight:700;margin-top:2px')}>{p.name}</div>
        <div style={css('display:flex;gap:8px;margin-top:12px')}>
          {p.inProgress ? (
            <button type="button" onClick={p.onResume} className="hv-primary"
              style={css('flex:1;height:40px;border-radius:12px;border:none;background:#7B6EF6;color:#FFFFFF;font-size:14.5px;font-weight:600;cursor:pointer')}>Retomar →</button>
          ) : (
            <>
              <button type="button" onClick={p.onOpen} className="hv-lav"
                style={css('flex:1;height:40px;border-radius:12px;border:1.5px solid #DCD6F7;background:#FFFFFF;color:#6C5EF0;font-size:14.5px;cursor:pointer')}>Ver</button>
              <button type="button" onClick={p.onRecreate} className="hv-soft"
                style={css('flex:1;height:40px;border-radius:12px;border:none;background:#F1EEFF;color:#6C5EF0;font-size:14.5px;font-weight:600;cursor:pointer')}>Recrear</button>
              <button type="button" onClick={p.onCompare} title="Comparar resultado" aria-label={`Comparar ${p.name} con su referencia`} className="hv-txt"
                style={css('width:40px;height:40px;border-radius:12px;border:1.5px solid #ECE8F8;background:#FFFFFF;color:#6F6C80;cursor:pointer;display:flex;align-items:center;justify-content:center')}><Compare /></button>
            </>
          )}
          <button type="button" onClick={p.onRemove} title={p.inProgress ? 'Descartar sesión' : 'Eliminar'} aria-label={`${p.inProgress ? 'Descartar' : 'Eliminar'} ${p.name}`} className="hv-del"
            style={css('width:40px;height:40px;border-radius:12px;border:1.5px solid #ECE8F8;background:#FFFFFF;color:#6F6C80;cursor:pointer;display:flex;align-items:center;justify-content:center')}><Trash /></button>
        </div>
      </div>
    </div>
  );
}
