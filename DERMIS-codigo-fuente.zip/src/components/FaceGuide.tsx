import { useId, type CSSProperties, type ReactNode } from 'react';
import {
  CAMERA_VIEW, CAMERA_VIEWBOX, FACE_GUIDES, FACE_PATH, MIRROR_X,
  type Decor, type GuideDef, type GuideStyle, type GuideType, type Zone,
} from '../data/faceGuides';

/** Estado visual de cada zona durante el feedback. */
export type ZoneStatus = 'todo' | 'focus' | 'ok';

type Background =
  | { kind: 'none' }
  /** Fotografía ilustrativa (tutoriales / respaldo). Ocupa el espacio de rostro 1440×770. */
  | { kind: 'illustration'; href: string }
  /** Captura de la cámara de la persona (mismo encuadre que la cámara en vivo). */
  | { kind: 'snapshot'; href: string };

interface Props {
  /** Guía del paso actual. Solo se dibujan las zonas de ESTE tipo. */
  type?: GuideType;
  /** live = sobre la cámara · tutorial = fases ilustradas · preview = orientación */
  mode?: 'live' | 'tutorial' | 'preview';
  statuses?: ZoneStatus[];
  phase?: number;
  viewBox?: string;
  background?: Background;
  /** Óvalo guía para alinear el rostro. */
  showOval?: boolean;
  ovalOpacity?: number;
  /** Fases de la animación de "análisis" (0–5). */
  analysisPhase?: number;
  /** Guías aplicadas por completo (simulación del resultado final en la ilustración). */
  applied?: GuideType[];
  showDecor?: boolean;
  style?: CSSProperties;
  label?: string;
}

const NS = 'non-scaling-stroke' as const;

/**
 * FaceGuide — overlay SVG reutilizable (position:absolute; inset:0; 100% × 100%; pointer-events:none).
 * Usa viewBox + preserveAspectRatio "slice" para escalar exactamente igual que un <video object-fit:cover>.
 *
 *   <FaceGuide type="contour" />            → zonas de contorno sobre la cámara
 *   <FaceGuide type="blush" />              → solo rubor
 *   <FaceGuide showOval analysisPhase={2}/> → escaneo inicial
 */
export function FaceGuide({
  type, mode = 'live', statuses, phase = 0, viewBox = CAMERA_VIEWBOX, background = { kind: 'none' },
  showOval, ovalOpacity = 0.9, analysisPhase, applied, showDecor = true, style, label,
}: Props) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const id = (n: string) => `${uid}-${n}`;
  const ref = (n: string) => `url(#${id(n)})`;
  const guide = type ? FACE_GUIDES[type] : undefined;
  const kids: ReactNode[] = [];

  const shape = (z: Zone, p: Record<string, unknown>, key: string) =>
    z.e
      ? <ellipse key={key} cx={z.e[0]} cy={z.e[1]} rx={z.e[2]} ry={z.e[3]} transform={`rotate(${z.e[4]} ${z.e[0]} ${z.e[1]})`} {...p} />
      : <path key={key} d={z.d} {...p} />;
  const wrap = (z: Zone, key: string, children: ReactNode[]) =>
    <g key={key} transform={z.mir ? `matrix(-1 0 0 1 ${MIRROR_X} 0)` : undefined}>{children}</g>;

  // Fondo
  if (background.kind === 'illustration') {
    kids.push(<image key="bg" href={background.href} x={0} y={0} width={1440} height={770} preserveAspectRatio="none" />);
  } else if (background.kind === 'snapshot') {
    kids.push(<image key="bg" href={background.href} x={CAMERA_VIEW.x} y={CAMERA_VIEW.y} width={CAMERA_VIEW.w} height={CAMERA_VIEW.h} preserveAspectRatio="xMidYMid slice" />);
  }

  // Resultado simulado (solo sobre la ilustración final)
  (applied ?? []).forEach((t, ai) => {
    const g = FACE_GUIDES[t];
    if (!g.applies) return;
    kids.push(<g key={'ap' + ai}>{g.zones.filter(z => !z.rm && (!z.line || g.sty.fo > 0.2)).map((z, i) =>
      wrap(z, 'a' + i, [shape(z, { fill: g.sty.fill, fillOpacity: g.sty.fo * 0.8, stroke: 'none', filter: ref('soft'), style: { mixBlendMode: g.sty.blend ?? 'normal' } }, 'a')]))}</g>);
  });

  // Óvalo guía
  if (showOval) {
    kids.push(<path key="oval" d={FACE_PATH} fill="none" stroke="#FFFFFF" strokeWidth={2.6} strokeDasharray="0.1 10" strokeLinecap="round" vectorEffect={NS}
      style={{ opacity: ovalOpacity, transition: 'opacity .8s' }} />);
  }

  if (guide) {
    const complete = mode === 'live' && statuses?.every(s => s === 'ok');
    if (guide.decor && showDecor && !complete && !(mode === 'tutorial' && phase > 2)) {
      kids.push(<g key="dec" style={{ animation: 'dmFade .6s ease-out' }}>{decorEls(guide.decor, mode === 'live' ? 0.75 : 0.85, ref)}</g>);
    }
    guide.zones.forEach((z, i) => {
      if (mode === 'tutorial') kids.push(zoneTutorial(z, i, guide.sty, phase, shape, wrap, ref));
      else kids.push(zoneLive(z, i, mode === 'preview' ? 'todo' : (statuses?.[i] ?? 'todo'), guide, shape, wrap, ref, mode));
    });
  }

  if (analysisPhase != null) kids.push(<g key="an">{analysisEls(analysisPhase)}</g>);

  return (
    <svg viewBox={viewBox} preserveAspectRatio="xMidYMid slice" role={label ? 'img' : undefined} aria-label={label} aria-hidden={label ? undefined : true}
      style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', display: 'block', pointerEvents: 'none', ...style }}>
      <defs>
        <pattern id={id('hatch')} width={6} height={6} patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
          <line x1={0} y1={0} x2={0} y2={6} stroke="#fff" strokeWidth={1.6} strokeOpacity={0.9} />
        </pattern>
        <filter id={id('soft')} x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation={7} /></filter>
        {marker(id('ah'), '#fff')}
        {marker(id('ahO'), '#F6A55B')}
      </defs>
      {kids}
    </svg>
  );
}

function marker(mid: string, col: string) {
  return (
    <marker id={mid} viewBox="0 0 10 10" refX={7} refY={5} markerWidth={12} markerHeight={12} markerUnits="userSpaceOnUse" orient="auto">
      <path d="M1,1 L8,5 L1,9" fill="none" stroke={col} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" />
    </marker>
  );
}

type ShapeFn = (z: Zone, p: Record<string, unknown>, key: string) => ReactNode;
type WrapFn = (z: Zone, key: string, children: ReactNode[]) => ReactNode;
type RefFn = (n: string) => string;

/** Zona sobre la cámara en vivo / orientación. Nunca cubre la piel por completo: contorno punteado + relleno muy suave. */
function zoneLive(z: Zone, i: number, st: ZoneStatus, g: GuideDef, shape: ShapeFn, wrap: WrapFn, ref: RefFn, mode: string) {
  const ok = st === 'ok', focus = st === 'focus';
  const live = mode === 'live';
  const sty = g.sty;
  // Prep y base: las zonas son anclas invisibles (la guía son las flechas); solo aparecen al resaltarlas.
  if (g.ghostZones && !focus) return <g key={'z' + i} />;
  const kids: ReactNode[] = [];
  if (!z.line) {
    const fo = z.rm
      ? (ok ? 0.12 : (live ? 0.55 : 0.85))
      : (ok ? sty.fo * 0.25 : (focus ? Math.min(0.85, sty.fo * 1.4) : sty.fo * (live ? 0.45 : 1)));
    kids.push(shape(z, {
      fill: z.rm ? ref('hatch') : sty.fill, fillOpacity: fo, stroke: 'none',
      style: { mixBlendMode: z.rm ? 'normal' : (sty.blend ?? 'normal'), transition: 'fill-opacity .6s' },
    }, 'f'));
  }
  kids.push(shape(z, {
    fill: 'none', stroke: sty.stroke, strokeOpacity: ok ? 0.35 : 0.95, strokeWidth: focus ? 3 : (live ? 2.2 : 1.8),
    strokeDasharray: '6 6', strokeLinecap: 'round', vectorEffect: NS,
    style: { animation: focus ? 'dmPulse 1.4s ease-in-out infinite' : 'none', transition: 'stroke-opacity .6s' },
  }, 's'));
  return wrap(z, 'z' + i, kids);
}

/** Zona en el tutorial: fase 0 = puntos de aplicación · 1 = flechas de difuminado · 2–3 = resultado. */
function zoneTutorial(z: Zone, i: number, sty: GuideStyle, ph: number, shape: ShapeFn, wrap: WrapFn, ref: RefFn) {
  const c = z.e ? [z.e[0], z.e[1]] : (z.c ?? [745, 380]);
  const a = ((z.e ? z.e[4] : (z.ax ?? 0)) * Math.PI) / 180;
  const d = [Math.cos(a), Math.sin(a)];
  const L = z.e ? z.e[2] : (z.len ?? 40);
  const kids: ReactNode[] = [];
  if (ph <= 1) {
    if (!z.line && !z.rm) kids.push(shape(z, { fill: sty.fill, fillOpacity: ph === 0 ? sty.fo * 0.3 : sty.fo * 0.9, stroke: 'none', style: { mixBlendMode: sty.blend ?? 'normal' } }, 'f'));
    kids.push(shape(z, { fill: z.rm ? ref('hatch') : 'none', stroke: sty.stroke, strokeWidth: 1.8, strokeDasharray: '6 6', vectorEffect: NS, strokeOpacity: ph === 0 ? 1 : 0.6 }, 's'));
  }
  if (ph === 0 && !z.line) {
    [-0.5, 0, 0.5].forEach((t, j) => kids.push(
      <circle key={'d' + j} cx={c[0] + d[0] * L * t} cy={c[1] + d[1] * L * t} r={Math.max(4, L * 0.09)} fill={sty.dot} stroke="#fff" strokeWidth={1.2} vectorEffect={NS} />));
  }
  if (ph === 1 && !z.line) {
    const sx = Math.abs(c[0] - 745) < 8 ? 0 : (c[0] < 745 ? -1 : 1);
    const v = sx === 0 ? [0, -1] : (d[0] * sx >= 0 ? d : [-d[0], -d[1]]);
    kids.push(<line key="ar" x1={c[0]} y1={c[1]} x2={c[0] + v[0] * L * 1.15} y2={c[1] + v[1] * L * 1.15} stroke="#fff" strokeWidth={2} vectorEffect={NS} markerEnd={ref('ah')} strokeLinecap="round" />);
  }
  if (ph >= 2 && !z.rm && !z.line) kids.push(shape(z, { fill: sty.fill, fillOpacity: sty.fo * (ph === 2 ? 1 : 0.75), filter: ref('soft'), style: { mixBlendMode: sty.blend ?? 'normal' } }, 'b'));
  if (ph >= 2 && z.line && sty.fo > 0.2) kids.push(shape(z, { fill: sty.fill, fillOpacity: sty.fo * 0.8, filter: ref('soft'), style: { mixBlendMode: sty.blend ?? 'normal' } }, 'b'));
  return wrap(z, 't' + i, kids);
}

/** Guías auxiliares: flechas de distribución (prep/base), puntos de forma y peinado de cejas. */
function decorEls(kind: Decor, op: number, ref: RefFn): ReactNode[] {
  const L = (d: string, k: string, extra: Record<string, unknown> = {}) =>
    <path key={k} d={d} fill="none" stroke="#fff" strokeWidth={2} strokeLinecap="round" vectorEffect={NS} opacity={op} {...extra} />;
  const both = (fn: () => ReactNode[], k: string) => [
    <g key={k + 'a'}>{fn()}</g>,
    <g key={k + 'b'} transform={`matrix(-1 0 0 1 ${MIRROR_X} 0)`}>{fn()}</g>,
  ];
  if (kind === 'prep') {
    return [
      L('M698,122 C694,84 792,80 794,112', 'f', { markerEnd: ref('ah') }),
      ...both(() => [L('M572,452 C536,420 560,368 612,376', 'c', { markerEnd: ref('ah') })], 'c'),
      L('M714,668 C720,642 770,640 777,662', 'ch', { markerEnd: ref('ah') }),
    ];
  }
  if (kind === 'base') {
    const O = { stroke: '#F6A55B', strokeDasharray: '6 6', markerEnd: ref('ahO') };
    const side = [[700, 178, 640, 100], [655, 410, 548, 372], [660, 470, 560, 520], [700, 600, 640, 650]];
    return [
      L(FACE_PATH, 'o', { strokeDasharray: '7 7', stroke: '#F6A55B' }),
      ...both(() => side.map((a, j) => L(`M${a[0]},${a[1]} L${a[2]},${a[3]}`, 'a' + j, O)), 'b'),
      L('M745,175 L745,78', 'm1', O),
      L('M745,640 L745,698', 'm2', O),
    ];
  }
  if (kind === 'forma') {
    return both(() => [
      L('M705,425 L703,182', 'g1', { strokeDasharray: '2 6', strokeWidth: 1.5 }),
      L('M705,425 L612,152', 'g2', { strokeDasharray: '2 6', strokeWidth: 1.5 }),
      L('M705,425 L522,196', 'g3', { strokeDasharray: '2 6', strokeWidth: 1.5 }),
      ...[[702, 198], [612, 158], [527, 193]].map((p, j) => <circle key={'p' + j} cx={p[0]} cy={p[1]} r={5} fill="#fff" opacity={op} />),
    ], 'fm');
  }
  // fijación: trazos de peinado hacia arriba
  return both(() => [542, 562, 582, 602, 622, 642, 662, 682].map((x, j) => {
    const y = 160 + Math.pow(x - 612, 2) / 250 + 16;
    return L(`M${x},${y + 8} L${x + 5},${y - 12}`, 's' + j, { markerEnd: ref('ah'), strokeWidth: 1.6 });
  }), 'fj');
}

/** Animación de escaneo: pocos puntos de referencia y líneas de proporción (estética beauty-tech, no médica). */
function analysisEls(ph: number): ReactNode[] {
  const pts = [[570, 272], [682, 274], [808, 274], [920, 272], [612, 160], [878, 160], [745, 418], [702, 428], [788, 428], [655, 543], [835, 543], [745, 700], [548, 352], [942, 352], [745, 78]];
  const els: ReactNode[] = [];
  if (ph >= 2) pts.forEach((p, i) => els.push(<circle key={'p' + i} cx={p[0]} cy={p[1]} r={3.2} fill="#fff" style={{ opacity: 0, animation: `dmFade .5s ${i * 0.05}s forwards` }} />));
  if (ph >= 3) [190, 425, 700].forEach((y, i) => els.push(<line key={'l' + i} x1={520} x2={970} y1={y} y2={y} stroke="#fff" strokeWidth={1} strokeDasharray="2 6" vectorEffect={NS} style={{ opacity: 0, animation: `dmFade .8s ${i * 0.15}s forwards` }} />));
  if (ph >= 4) els.push(<line key="v" x1={745} x2={745} y1={60} y2={712} stroke="#fff" strokeWidth={1} strokeDasharray="2 6" vectorEffect={NS} style={{ opacity: 0, animation: 'dmFade .8s forwards' }} />);
  return els;
}
