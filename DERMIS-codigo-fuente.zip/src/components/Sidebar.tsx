import { useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { css } from '../lib/css';
import { Sparkle } from './Icons';
import { ASSETS } from '../data/content';
import { routes } from '../lib/routes';
import { ProfileModal } from '../modals/ProfileModal';

const NAV = [
  { label: 'Inicio', to: routes.home, match: (p: string) => p === '/' },
  { label: 'Maquillaje', to: routes.module('makeup'), match: (p: string) => p.startsWith('/makeup') },
  { label: 'Diseño de cejas', to: routes.module('brows'), match: (p: string) => p.startsWith('/brows') },
  { label: 'Mi colección', to: routes.collection, match: (p: string) => p.startsWith('/collection') },
  { label: 'Looks guardados', to: routes.looks, match: (p: string) => p.startsWith('/looks') },
  { label: 'Cuidado post-maquillaje', to: routes.aftercare, match: (p: string) => p.startsWith('/aftercare') },
];

/** Layout con sidebar (Inicio, Maquillaje, Cejas, Colección, Looks, Cuidado). */
export function SidebarLayout() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(false);

  return (
    <div className="dm-layout">
      <aside className="dm-sidebar" aria-label="Navegación principal" style={css('width:232px;flex-shrink:0;background:#FFFFFF;border-right:1px solid #F0EDF6;display:flex;flex-direction:column;padding-top:28px')}>
        <button type="button" onClick={() => navigate(routes.home)} aria-label="DERMIS, ir al inicio"
          style={css('display:flex;align-items:center;gap:12px;padding:0 24px;background:none;border:none;cursor:pointer;color:#1D1B2C;text-align:left')}>
          <div style={css('width:40px;height:40px;border-radius:50%;background:#F1EEFF;display:flex;align-items:center;justify-content:center;color:#7B6EF6')}><Sparkle /></div>
          <div style={css('font-size:24px;font-weight:700;letter-spacing:-0.01em')}>DERMIS</div>
        </button>
        <div className="dm-greeting" style={css('padding:30px 24px 22px')}>
          <div style={css('font-size:16px;font-weight:600')}>Hola, Sofía</div>
          <div style={css('font-size:13.5px;color:#7A7789;margin-top:2px')}>Tu asistente de maquillaje</div>
        </div>
        <nav className="dm-nav" style={css('display:flex;flex-direction:column;gap:4px;padding:0 14px')}>
          {NAV.map(n => {
            const on = n.match(pathname);
            return (
              <button key={n.label} type="button" onClick={() => navigate(n.to)} aria-current={on ? 'page' : undefined} className={on ? undefined : 'hv-nav'}
                style={css(`text-align:left;padding:11px 18px;border-radius:12px;border:none;font-size:16px;cursor:pointer;background:${on ? '#7B6EF6' : 'transparent'};color:${on ? '#FFFFFF' : '#6F6C80'};box-shadow:${on ? '0 6px 16px rgba(123,110,246,.28)' : 'none'};line-height:1.3`)}>
                {n.label}
              </button>
            );
          })}
        </nav>
        <div className="dm-profile" style={css('margin-top:auto;border-top:1px solid #F0EDF6;padding:18px 24px;display:flex;gap:12px;align-items:center')}>
          <img src={ASSETS.avatar} alt="Foto de perfil de Sofía" style={css('width:42px;height:42px;border-radius:50%;object-fit:cover')} />
          <div>
            <div style={css('font-size:16px;font-weight:600')}>Sofía</div>
            <button type="button" onClick={() => setProfile(true)} className="hv-txt"
              style={css('font-size:14px;color:#7B6EF6;background:none;border:none;padding:0;cursor:pointer')}>Ver perfil</button>
          </div>
        </div>
      </aside>

      <main className="dm-scroll dm-main" style={css('flex:1;min-width:0;height:100%;overflow-y:auto;padding:40px 48px 48px;box-sizing:border-box')}>
        <div key={pathname.split('/').slice(0, 2).join('/')} className="fade-in">
          <Outlet />
        </div>
      </main>
      <ProfileModal open={profile} onClose={() => setProfile(false)} />
    </div>
  );
}

