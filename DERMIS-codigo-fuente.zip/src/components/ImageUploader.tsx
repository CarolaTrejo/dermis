import { forwardRef, useImperativeHandle, useRef } from 'react';
import { fileToDataUrl } from '../lib/image';

export interface ImagePickerHandle { open: () => void }

interface Props {
  onPick: (dataUrl: string, file: File) => void;
  onError?: (msg: string) => void;
  maxSide?: number;
}

/**
 * Selector de imágenes real: <input type="file" accept="image/*"> oculto.
 * Se abre con ref.open() desde cualquier botón ("Desde galería", "Subir imagen", "Elegir referencia"…).
 * La imagen se procesa en el navegador (no se sube a ningún servidor).
 */
export const ImageUploader = forwardRef<ImagePickerHandle, Props>(function ImageUploader({ onPick, onError, maxSide = 900 }, ref) {
  const input = useRef<HTMLInputElement>(null);
  useImperativeHandle(ref, () => ({ open: () => input.current?.click() }), []);
  return (
    <input
      ref={input}
      type="file"
      accept="image/*"
      tabIndex={-1}
      aria-hidden="true"
      style={{ display: 'none' }}
      onChange={async e => {
        const file = e.target.files?.[0];
        e.target.value = ''; // permite elegir el mismo archivo otra vez
        if (!file) return;
        try {
          onPick(await fileToDataUrl(file, maxSide), file);
        } catch (err) {
          onError?.((err as Error).message);
        }
      }}
    />
  );
});
