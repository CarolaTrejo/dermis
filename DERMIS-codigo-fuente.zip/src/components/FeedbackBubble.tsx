import { css } from '../lib/css';

interface Props { left: number; top: number; color: string; label: string; text: string }

/** Burbuja de indicación sobre la cámara (vidrio esmerilado, del diseño original). */
export function FeedbackBubble({ left, top, color, label, text }: Props) {
  return (
    <div role="status" aria-live="polite"
      style={{ ...css('position:absolute;width:270px;box-sizing:border-box;background:rgba(36,26,28,.42);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-radius:20px;padding:14px 18px;animation:dmPop .45s ease-out;color:#FFFFFF'), left, top, border: `1.5px solid ${color}` }}>
      <div style={{ ...css('display:flex;gap:8px;align-items:center;font-size:13px;font-weight:600;letter-spacing:.04em'), color }}>
        <span style={{ ...css('width:8px;height:8px;border-radius:50%'), background: color }} />{label}
      </div>
      <div style={css('font-size:18px;line-height:1.35;margin-top:6px;font-weight:500')}>{text}</div>
    </div>
  );
}
