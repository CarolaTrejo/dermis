import { css } from '../lib/css';
import { Check } from './Icons';
import type { ProcessStep } from '../data/types';

interface Props {
  steps: ProcessStep[];
  current: number;
  done: boolean[];
  onSelect: (i: number) => void;
  compact?: boolean;
}

/** Lista de pasos con estados completed / current / pending (pantalla "Recreando tu look"). */
export function StepSidebar({ steps, current, done, onSelect, compact }: Props) {
  return (
    <ol aria-label="Pasos" style={css('display:flex;flex-direction:column;gap:10px;list-style:none;margin:0;padding:0')}>
      {steps.map((st, j) => {
        const isCur = j === current;
        const isDone = done[j] && !isCur;
        const state = isCur ? 'paso actual' : isDone ? 'completado' : 'pendiente';
        return (
          <li key={st.id}>
            <button type="button" onClick={() => onSelect(j)} aria-current={isCur ? 'step' : undefined} aria-label={`${j + 1}. ${st.name}, ${state}`} className="hv-step"
              style={css(`width:100%;display:flex;align-items:center;gap:14px;padding:10px 18px 10px 10px;border-radius:18px;border:1.5px solid ${isCur ? '#D6CCFB' : '#F2F0F6'};background:${isCur ? '#EEE9FF' : '#F2F0F6'};cursor:pointer;text-align:left;height:${compact ? 78 : 84}px;box-sizing:border-box`)}>
              <div style={css('width:54px;height:54px;border-radius:12px;background:#FFFFFF;overflow:hidden;flex-shrink:0')}><img src={st.img} alt="" style={css('width:100%;height:100%;object-fit:cover')} /></div>
              <div style={css('flex:1;min-width:0')}>
                <div style={css(`font-size:16.5px;color:${isCur || isDone ? '#6C5EF0' : '#1D1B2C'};font-weight:500`)}>{j + 1}. {st.name}</div>
                <div style={css('font-size:13.5px;color:#A3A0B2;margin-top:2px')}>{st.sub}</div>
              </div>
              {isDone && <div className="pop-in" style={css('width:28px;height:28px;border-radius:50%;background:#9C8FF8;display:flex;align-items:center;justify-content:center;color:#FFFFFF')}><Check /></div>}
              {isCur && <div style={css('width:28px;height:28px;display:flex;align-items:center;justify-content:center')}><div style={css('width:16px;height:16px;border-radius:50%;background:#9C8FF8')} /></div>}
              {!isCur && !isDone && <div style={css('width:26px;height:26px;border-radius:50%;border:1.5px solid #DDD9E8')} />}
            </button>
          </li>
        );
      })}
    </ol>
  );
}
