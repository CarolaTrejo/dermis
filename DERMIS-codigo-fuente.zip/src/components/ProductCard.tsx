import { css } from '../lib/css';
import { Heart } from './Icons';

export function HeartButton({ on, onToggle, label, variant = 'plain', size = 19 }: { on: boolean; onToggle: () => void; label: string; variant?: 'plain' | 'bubble'; size?: number }) {
  const bubble = variant === 'bubble';
  return (
    <button type="button" aria-pressed={on} aria-label={(on ? 'Quitar de favoritos: ' : 'Agregar a favoritos: ') + label}
      onClick={e => { e.stopPropagation(); onToggle(); }}
      style={css(bubble
        ? 'position:absolute;top:12px;right:12px;width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.92);border:none;display:flex;align-items:center;justify-content:center;cursor:pointer;color:#E36C8C'
        : `position:absolute;top:10px;right:10px;width:32px;height:32px;border-radius:50%;background:transparent;border:none;cursor:pointer;color:${on ? '#E5484D' : '#C9C5D6'};display:flex;align-items:center;justify-content:center`)}>
      <span style={{ display: 'flex', transform: on ? 'scale(1.08)' : 'none', transition: 'transform .2s' }}>
        <Heart size={bubble ? 18 : size} fill={on ? (bubble ? '#E36C8C' : '#E5484D') : 'none'} />
      </span>
    </button>
  );
}

interface CollectionCardProps {
  img: string | null; name: string; brand: string; cat: string; fav: boolean; isNew?: boolean; onFav: () => void;
}

/** Card de producto de "Mi colección". */
export function ProductCard({ img, name, brand, cat, fav, isNew, onFav }: CollectionCardProps) {
  return (
    <div className="pop-in" style={css(`position:relative;background:#FFFFFF;border:1px solid ${isNew ? '#B9AEFA' : '#EEEAF7'};border-radius:18px;padding:14px 16px 16px;display:flex;flex-direction:column`)}>
      {img
        ? <img src={img} alt={`${name} de ${brand}`} style={css('width:100%;height:120px;object-fit:contain;display:block')} />
        : <div style={css('height:120px;border-radius:12px;background:repeating-linear-gradient(45deg,#F4F1FC 0 8px,#FBFAFE 8px 16px);display:flex;align-items:center;justify-content:center;font-family:ui-monospace,monospace;font-size:11px;color:#9C97B5')}>foto del producto</div>}
      <HeartButton on={fav} onToggle={onFav} label={name} />
      {isNew && <div style={css('position:absolute;top:12px;left:12px;background:#7B6EF6;color:#FFFFFF;font-size:11.5px;font-weight:600;border-radius:8px;padding:3px 8px')}>Nuevo</div>}
      <div style={css('font-size:15px;font-weight:700;margin-top:12px;line-height:1.3')}>{name}</div>
      <div style={css('font-size:13.5px;color:#8A8798;margin-top:3px')}>{brand}</div>
      <div style={css('margin-top:auto;padding-top:12px;display:flex')}><span style={css('background:#F1EEFF;color:#6C5EF0;font-size:12.5px;border-radius:10px;padding:4px 10px')}>{cat}</span></div>
    </div>
  );
}

interface RecProps { img: string | null; tag: string; brand: string; name: string; price: string; fav: boolean; onFav: () => void }

/** Card horizontal de producto recomendado (tutorial). */
export function RecommendedProductCard({ img, tag, brand, name, price, fav, onFav }: RecProps) {
  return (
    <div className="pop-in" style={css('position:relative;background:#FFFFFF;border:1.5px solid #ECE8F6;border-radius:18px;padding:14px;display:flex;gap:14px;align-items:center')}>
      {img
        ? <img src={img} alt={`${name} de ${brand}`} style={css('width:76px;height:104px;object-fit:contain;flex-shrink:0')} />
        : <div style={css('width:76px;height:104px;flex-shrink:0;border-radius:10px;background:repeating-linear-gradient(45deg,#F4F1FC 0 6px,#FBFAFE 6px 12px)')} />}
      <div style={css('min-width:0;padding-right:14px')}>
        <span style={css('display:inline-block;background:#F1EEFF;color:#6C5EF0;font-size:12px;border-radius:9px;padding:3px 9px')}>{tag}</span>
        <div style={css('font-size:15px;font-weight:600;margin-top:8px')}>{brand}</div>
        <div style={css('font-size:13.5px;color:#8A8798;margin-top:2px;line-height:1.3')}>{name}</div>
        <div style={css('font-size:14px;color:#8A8798;margin-top:8px')}>{price}</div>
      </div>
      <HeartButton on={fav} onToggle={onFav} label={name} size={18} />
    </div>
  );
}
