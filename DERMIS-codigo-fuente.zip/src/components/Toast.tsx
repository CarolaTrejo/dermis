import { css } from '../lib/css';
import { useStore } from '../state/AppStore';

export function Toast() {
  const { toast } = useStore();
  if (!toast) return null;
  return (
    <div key={toast.id} role="status" aria-live="polite"
      style={css('position:absolute;left:50%;bottom:36px;transform:translateX(-50%);background:#1D1B2C;color:#FFFFFF;border-radius:16px;padding:14px 22px;font-size:15.5px;display:flex;gap:10px;align-items:center;box-shadow:0 12px 32px rgba(0,0,0,.25);animation:dmPopCenter .3s ease-out;z-index:80;white-space:nowrap')}>
      <span style={css('width:8px;height:8px;border-radius:50%;background:#9D92FF')} />{toast.msg}
    </div>
  );
}
