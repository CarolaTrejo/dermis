import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import basicSsl from '@vitejs/plugin-basic-ssl';

// La webcam (getUserMedia) solo funciona en contextos seguros: localhost, HTTPS o un archivo local abierto en Chrome/Edge.
//   npm run dev          → http://localhost:5173
//   npm run dev:https    → HTTPS autofirmado, accesible desde la red local
//   npm run build:single → dist-single/DERMIS.html: UN archivo con todo adentro, para enviar y abrir con doble clic

/** Incrusta el JS y el CSS dentro del HTML (las imágenes ya vienen como data URI). */
function inlineEverything(): Plugin {
  return {
    name: 'dermis-inline-single-file',
    enforce: 'post',
    generateBundle(_, bundle) {
      const html = bundle['index.html'];
      if (!html || html.type !== 'asset') return;
      let src = String(html.source);
      for (const [name, file] of Object.entries(bundle)) {
        if (file.type === 'chunk' && name.endsWith('.js')) {
          const code = file.code.replace(/<\/script/gi, '<\\/script');
          src = src.replace(new RegExp(`<script[^>]*src="[^"]*${escape(name)}"[^>]*></script>`), () => `<script type="module">${code}</script>`);
          delete bundle[name];
        } else if (file.type === 'asset' && name.endsWith('.css')) {
          src = src.replace(new RegExp(`<link[^>]*href="[^"]*${escape(name)}"[^>]*>`), () => `<style>${String(file.source)}</style>`);
          delete bundle[name];
        }
      }
      html.source = src;
      html.fileName = 'DERMIS.html';
    },
  };
}
const escape = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

export default defineConfig(({ mode }) => {
  const single = mode === 'single';
  return {
    base: './',
    publicDir: false,
    plugins: [react(), ...(mode === 'https' ? [basicSsl()] : []), ...(single ? [inlineEverything()] : [])],
    build: single
      ? { outDir: 'dist-single', assetsInlineLimit: () => true, cssCodeSplit: false, modulePreload: false, chunkSizeWarningLimit: 10000 }
      : { outDir: 'dist' },
    server: {
      port: 5173,
      host: mode === 'https' ? true : 'localhost',
    },
  };
});
